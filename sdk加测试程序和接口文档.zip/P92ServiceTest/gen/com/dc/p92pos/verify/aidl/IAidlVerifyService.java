/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/verify/aidl/IAidlVerifyService.aidl
 */
package com.dc.p92pos.verify.aidl;
public interface IAidlVerifyService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.verify.aidl.IAidlVerifyService
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.verify.aidl.IAidlVerifyService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.verify.aidl.IAidlVerifyService interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.verify.aidl.IAidlVerifyService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.verify.aidl.IAidlVerifyService))) {
return ((com.dc.p92pos.verify.aidl.IAidlVerifyService)iin);
}
return new com.dc.p92pos.verify.aidl.IAidlVerifyService.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getPackageUninstallVerify:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPackageUninstallVerify();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPackageVerify:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPackageVerify();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.verify.aidl.IAidlVerifyService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
    *   获取卸载应用的授权服务
    */
@Override public android.os.IBinder getPackageUninstallVerify() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPackageUninstallVerify, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
    *   获取安装包授权服务
    */
@Override public android.os.IBinder getPackageVerify() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPackageVerify, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getPackageUninstallVerify = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getPackageVerify = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
}
/**
    *   获取卸载应用的授权服务
    */
public android.os.IBinder getPackageUninstallVerify() throws android.os.RemoteException;
/**
    *   获取安装包授权服务
    */
public android.os.IBinder getPackageVerify() throws android.os.RemoteException;
}
