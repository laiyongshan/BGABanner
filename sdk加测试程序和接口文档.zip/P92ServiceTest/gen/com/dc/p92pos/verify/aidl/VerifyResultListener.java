/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/verify/aidl/VerifyResultListener.aidl
 */
package com.dc.p92pos.verify.aidl;
public interface VerifyResultListener extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.verify.aidl.VerifyResultListener
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.verify.aidl.VerifyResultListener";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.verify.aidl.VerifyResultListener interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.verify.aidl.VerifyResultListener asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.verify.aidl.VerifyResultListener))) {
return ((com.dc.p92pos.verify.aidl.VerifyResultListener)iin);
}
return new com.dc.p92pos.verify.aidl.VerifyResultListener.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onVerifySuccess:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
byte[] _arg1;
_arg1 = data.createByteArray();
this.onVerifySuccess(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onVeriryFail:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onVeriryFail(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.verify.aidl.VerifyResultListener
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
     *@param md5 验证通过的md5值
     *@param signData APP签名数据信息
     *
     */
@Override public void onVerifySuccess(byte[] md5, byte[] signData) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(md5);
_data.writeByteArray(signData);
mRemote.transact(Stub.TRANSACTION_onVerifySuccess, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     *@param errorId 错误码
     * 0x00:文件不存在
     * 0x01:文件格式错误
     * 0x02:网络错误
     * 0x03:校验失败
     */
@Override public void onVeriryFail(int errorId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(errorId);
mRemote.transact(Stub.TRANSACTION_onVeriryFail, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_onVerifySuccess = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onVeriryFail = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
}
/**
     *@param md5 验证通过的md5值
     *@param signData APP签名数据信息
     *
     */
public void onVerifySuccess(byte[] md5, byte[] signData) throws android.os.RemoteException;
/**
     *@param errorId 错误码
     * 0x00:文件不存在
     * 0x01:文件格式错误
     * 0x02:网络错误
     * 0x03:校验失败
     */
public void onVeriryFail(int errorId) throws android.os.RemoteException;
}
