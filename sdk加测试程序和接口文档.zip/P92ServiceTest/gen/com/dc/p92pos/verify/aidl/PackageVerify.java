/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/verify/aidl/PackageVerify.aidl
 */
package com.dc.p92pos.verify.aidl;
public interface PackageVerify extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.verify.aidl.PackageVerify
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.verify.aidl.PackageVerify";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.verify.aidl.PackageVerify interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.verify.aidl.PackageVerify asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.verify.aidl.PackageVerify))) {
return ((com.dc.p92pos.verify.aidl.PackageVerify)iin);
}
return new com.dc.p92pos.verify.aidl.PackageVerify.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_verify:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
com.dc.p92pos.verify.aidl.VerifyResultListener _arg2;
_arg2 = com.dc.p92pos.verify.aidl.VerifyResultListener.Stub.asInterface(data.readStrongBinder());
this.verify(_arg0, _arg1, _arg2);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.verify.aidl.PackageVerify
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
     *@ param packagePath 验签APK路径
     *@ param termSn 终端sn号
     *@ listener 验签APK结果监听
     *
     */
@Override public void verify(java.lang.String packagePath, java.lang.String termSn, com.dc.p92pos.verify.aidl.VerifyResultListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(packagePath);
_data.writeString(termSn);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_verify, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_verify = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
}
/**
     *@ param packagePath 验签APK路径
     *@ param termSn 终端sn号
     *@ listener 验签APK结果监听
     *
     */
public void verify(java.lang.String packagePath, java.lang.String termSn, com.dc.p92pos.verify.aidl.VerifyResultListener listener) throws android.os.RemoteException;
}
