/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/system/AidlSystem.aidl
 */
package com.dc.p92pos.aidl.system;
//系统设备

public interface AidlSystem extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.system.AidlSystem
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.system.AidlSystem";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.system.AidlSystem interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.system.AidlSystem asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.system.AidlSystem))) {
return ((com.dc.p92pos.aidl.system.AidlSystem)iin);
}
return new com.dc.p92pos.aidl.system.AidlSystem.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getSerialNo:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getSerialNo();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_installApp:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
com.dc.p92pos.aidl.system.InstallAppObserver _arg1;
_arg1 = com.dc.p92pos.aidl.system.InstallAppObserver.Stub.asInterface(data.readStrongBinder());
this.installApp(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_getKsn:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getKsn();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getDriverVersion:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getDriverVersion();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getHtfskVersion:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getHtfskVersion();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getCurSdkVersion:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getCurSdkVersion();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_updateSysTime:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
boolean _result = this.updateSysTime(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getStoragePath:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getStoragePath();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_update:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.update(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_getIMSI:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getIMSI();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getIMEI:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getIMEI();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getHardWireVersion:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getHardWireVersion();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getSecurityDriverVersion:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getSecurityDriverVersion();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getManufacture:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getManufacture();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getModel:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getModel();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getAndroidOsVersion:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getAndroidOsVersion();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getRomVersion:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getRomVersion();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getAndroidKernelVersion:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getAndroidKernelVersion();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_reboot:
{
data.enforceInterface(DESCRIPTOR);
this.reboot();
reply.writeNoException();
return true;
}
case TRANSACTION_getICCID:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getICCID();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_SetDeviceParams:
{
data.enforceInterface(DESCRIPTOR);
android.os.Bundle _arg0;
if ((0!=data.readInt())) {
_arg0 = android.os.Bundle.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
boolean _result = this.SetDeviceParams(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_SetPrinter:
{
data.enforceInterface(DESCRIPTOR);
android.os.Bundle _arg0;
if ((0!=data.readInt())) {
_arg0 = android.os.Bundle.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
boolean _result = this.SetPrinter(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_SetFont:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
byte[] _arg1;
_arg1 = data.createByteArray();
boolean _result = this.SetFont(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_verifyFont:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
byte[] _arg1;
_arg1 = data.createByteArray();
int _arg2;
_arg2 = data.readInt();
byte[] _arg3;
int _arg3_length = data.readInt();
if ((_arg3_length<0)) {
_arg3 = null;
}
else {
_arg3 = new byte[_arg3_length];
}
boolean _result = this.verifyFont(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
reply.writeByteArray(_arg3);
return true;
}
case TRANSACTION_restoreFactorySettings:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.restoreFactorySettings();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_restoreOSFactorySettings:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.restoreOSFactorySettings();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_SetEMVParams:
{
data.enforceInterface(DESCRIPTOR);
android.os.Bundle _arg0;
if ((0!=data.readInt())) {
_arg0 = android.os.Bundle.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
boolean _result = this.SetEMVParams(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_setQPassParams:
{
data.enforceInterface(DESCRIPTOR);
android.os.Bundle _arg0;
if ((0!=data.readInt())) {
_arg0 = android.os.Bundle.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
boolean _result = this.setQPassParams(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_clearQPassParams:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.clearQPassParams();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_SetPrintLogAndLeval:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _result = this.SetPrintLogAndLeval(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.system.AidlSystem
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
//获取终端序列号

@Override public java.lang.String getSerialNo() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getSerialNo, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//安装APP

@Override public void installApp(java.lang.String filePath, com.dc.p92pos.aidl.system.InstallAppObserver observer) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(filePath);
_data.writeStrongBinder((((observer!=null))?(observer.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_installApp, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//读取KSN号

@Override public java.lang.String getKsn() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getKsn, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//获取驱动版本信息

@Override public java.lang.String getDriverVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getDriverVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getHtfskVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getHtfskVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//获取当前接口版本信息

@Override public java.lang.String getCurSdkVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getCurSdkVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//更新系统时间

@Override public boolean updateSysTime(java.lang.String dateStr) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(dateStr);
mRemote.transact(Stub.TRANSACTION_updateSysTime, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//增加存储路径

@Override public java.lang.String getStoragePath() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getStoragePath, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//更新OS或驱动包

@Override public void update(int updateType) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(updateType);
mRemote.transact(Stub.TRANSACTION_update, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public java.lang.String getIMSI() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getIMSI, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getIMEI() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getIMEI, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getHardWireVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getHardWireVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getSecurityDriverVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getSecurityDriverVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getManufacture() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getManufacture, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getModel() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getModel, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getAndroidOsVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getAndroidOsVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getRomVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getRomVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String getAndroidKernelVersion() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getAndroidKernelVersion, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void reboot() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_reboot, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public java.lang.String getICCID() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getICCID, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 设置设备参数 */
@Override public boolean SetDeviceParams(android.os.Bundle bundle) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((bundle!=null)) {
_data.writeInt(1);
bundle.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_SetDeviceParams, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 设置打印机 */
@Override public boolean SetPrinter(android.os.Bundle bundle) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((bundle!=null)) {
_data.writeInt(1);
bundle.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_SetPrinter, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 设置字库 */
@Override public boolean SetFont(int type, byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(type);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_SetFont, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 验证字库 */
@Override public boolean verifyFont(int type, byte[] address, int len, byte[] info) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(type);
_data.writeByteArray(address);
_data.writeInt(len);
if ((info==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(info.length);
}
mRemote.transact(Stub.TRANSACTION_verifyFont, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
_reply.readByteArray(info);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 恢复出厂设置 */
@Override public boolean restoreFactorySettings() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_restoreFactorySettings, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 恢复OS出厂设置 */
@Override public boolean restoreOSFactorySettings() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_restoreOSFactorySettings, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 设置EMV参数 */
@Override public boolean SetEMVParams(android.os.Bundle bundle) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((bundle!=null)) {
_data.writeInt(1);
bundle.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_SetEMVParams, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 设置闪卡参数 */
@Override public boolean setQPassParams(android.os.Bundle bundle) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((bundle!=null)) {
_data.writeInt(1);
bundle.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_setQPassParams, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 清空闪卡数据 */
@Override public boolean clearQPassParams() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_clearQPassParams, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 设置是否打印log和log级别 */
@Override public boolean SetPrintLogAndLeval(int leval) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(leval);
mRemote.transact(Stub.TRANSACTION_SetPrintLogAndLeval, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getSerialNo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_installApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getKsn = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getDriverVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getHtfskVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_getCurSdkVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_updateSysTime = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_getStoragePath = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_update = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_getIMSI = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_getIMEI = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_getHardWireVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_getSecurityDriverVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_getManufacture = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_getModel = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_getAndroidOsVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_getRomVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_getAndroidKernelVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_reboot = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_getICCID = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_SetDeviceParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_SetPrinter = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_SetFont = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
static final int TRANSACTION_verifyFont = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
static final int TRANSACTION_restoreFactorySettings = (android.os.IBinder.FIRST_CALL_TRANSACTION + 24);
static final int TRANSACTION_restoreOSFactorySettings = (android.os.IBinder.FIRST_CALL_TRANSACTION + 25);
static final int TRANSACTION_SetEMVParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 26);
static final int TRANSACTION_setQPassParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 27);
static final int TRANSACTION_clearQPassParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 28);
static final int TRANSACTION_SetPrintLogAndLeval = (android.os.IBinder.FIRST_CALL_TRANSACTION + 29);
}
//获取终端序列号

public java.lang.String getSerialNo() throws android.os.RemoteException;
//安装APP

public void installApp(java.lang.String filePath, com.dc.p92pos.aidl.system.InstallAppObserver observer) throws android.os.RemoteException;
//读取KSN号

public java.lang.String getKsn() throws android.os.RemoteException;
//获取驱动版本信息

public java.lang.String getDriverVersion() throws android.os.RemoteException;
public java.lang.String getHtfskVersion() throws android.os.RemoteException;
//获取当前接口版本信息

public java.lang.String getCurSdkVersion() throws android.os.RemoteException;
//更新系统时间

public boolean updateSysTime(java.lang.String dateStr) throws android.os.RemoteException;
//增加存储路径

public java.lang.String getStoragePath() throws android.os.RemoteException;
//更新OS或驱动包

public void update(int updateType) throws android.os.RemoteException;
public java.lang.String getIMSI() throws android.os.RemoteException;
public java.lang.String getIMEI() throws android.os.RemoteException;
public java.lang.String getHardWireVersion() throws android.os.RemoteException;
public java.lang.String getSecurityDriverVersion() throws android.os.RemoteException;
public java.lang.String getManufacture() throws android.os.RemoteException;
public java.lang.String getModel() throws android.os.RemoteException;
public java.lang.String getAndroidOsVersion() throws android.os.RemoteException;
public java.lang.String getRomVersion() throws android.os.RemoteException;
public java.lang.String getAndroidKernelVersion() throws android.os.RemoteException;
public void reboot() throws android.os.RemoteException;
public java.lang.String getICCID() throws android.os.RemoteException;
/** 设置设备参数 */
public boolean SetDeviceParams(android.os.Bundle bundle) throws android.os.RemoteException;
/** 设置打印机 */
public boolean SetPrinter(android.os.Bundle bundle) throws android.os.RemoteException;
/** 设置字库 */
public boolean SetFont(int type, byte[] data) throws android.os.RemoteException;
/** 验证字库 */
public boolean verifyFont(int type, byte[] address, int len, byte[] info) throws android.os.RemoteException;
/** 恢复出厂设置 */
public boolean restoreFactorySettings() throws android.os.RemoteException;
/** 恢复OS出厂设置 */
public boolean restoreOSFactorySettings() throws android.os.RemoteException;
/** 设置EMV参数 */
public boolean SetEMVParams(android.os.Bundle bundle) throws android.os.RemoteException;
/** 设置闪卡参数 */
public boolean setQPassParams(android.os.Bundle bundle) throws android.os.RemoteException;
/** 清空闪卡数据 */
public boolean clearQPassParams() throws android.os.RemoteException;
/** 设置是否打印log和log级别 */
public boolean SetPrintLogAndLeval(int leval) throws android.os.RemoteException;
}
