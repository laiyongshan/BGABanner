/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/rfcard/AidlRFCard.aidl
 */
package com.dc.p92pos.aidl.rfcard;
//非接卡设备

public interface AidlRFCard extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.rfcard.AidlRFCard
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.rfcard.AidlRFCard";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.rfcard.AidlRFCard interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.rfcard.AidlRFCard asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.rfcard.AidlRFCard))) {
return ((com.dc.p92pos.aidl.rfcard.AidlRFCard)iin);
}
return new com.dc.p92pos.aidl.rfcard.AidlRFCard.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_open:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.open();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_close:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.close();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_reset:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
byte[] _result = this.reset(_arg0);
reply.writeNoException();
reply.writeByteArray(_result);
return true;
}
case TRANSACTION_isExist:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.isExist();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_apduComm:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
byte[] _result = this.apduComm(_arg0);
reply.writeNoException();
reply.writeByteArray(_result);
return true;
}
case TRANSACTION_halt:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.halt();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getCardType:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getCardType();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_auth:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
byte _arg1;
_arg1 = data.readByte();
byte[] _arg2;
_arg2 = data.createByteArray();
byte[] _arg3;
_arg3 = data.createByteArray();
int _result = this.auth(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_readBlock:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
byte[] _arg1;
int _arg1_length = data.readInt();
if ((_arg1_length<0)) {
_arg1 = null;
}
else {
_arg1 = new byte[_arg1_length];
}
int _result = this.readBlock(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
reply.writeByteArray(_arg1);
return true;
}
case TRANSACTION_writeBlock:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
byte[] _arg1;
_arg1 = data.createByteArray();
int _result = this.writeBlock(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_addValue:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
byte[] _arg1;
_arg1 = data.createByteArray();
int _result = this.addValue(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_reduceValue:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
byte[] _arg1;
_arg1 = data.createByteArray();
int _result = this.reduceValue(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.rfcard.AidlRFCard
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/** 打开设备*/
@Override public boolean open() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_open, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 关闭设备*/
@Override public boolean close() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_close, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 复位卡片*/
@Override public byte[] reset(int cardType) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
byte[] _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(cardType);
mRemote.transact(Stub.TRANSACTION_reset, _data, _reply, 0);
_reply.readException();
_result = _reply.createByteArray();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 卡片是否在位*/
@Override public boolean isExist() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_isExist, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 发送Apdu指令*/
@Override public byte[] apduComm(byte[] apdu) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
byte[] _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(apdu);
mRemote.transact(Stub.TRANSACTION_apduComm, _data, _reply, 0);
_reply.readException();
_result = _reply.createByteArray();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 断开*/
@Override public int halt() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_halt, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取卡类型 */
@Override public int getCardType() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getCardType, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//以下接口只针对M1卡有效
/** 认证  */
@Override public int auth(int type, byte blockaddr, byte[] keydata, byte[] resetRes) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(type);
_data.writeByte(blockaddr);
_data.writeByteArray(keydata);
_data.writeByteArray(resetRes);
mRemote.transact(Stub.TRANSACTION_auth, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 读数据 */
@Override public int readBlock(byte blockaddr, byte[] blockdata) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(blockaddr);
if ((blockdata==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(blockdata.length);
}
mRemote.transact(Stub.TRANSACTION_readBlock, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
_reply.readByteArray(blockdata);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 写数据 */
@Override public int writeBlock(byte blockaddr, byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(blockaddr);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_writeBlock, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 加值 */
@Override public int addValue(byte blockaddr, byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(blockaddr);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_addValue, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 减值 */
@Override public int reduceValue(byte blockaddr, byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(blockaddr);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_reduceValue, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_open = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_close = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_reset = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_isExist = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_apduComm = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_halt = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_getCardType = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_auth = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_readBlock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_writeBlock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_addValue = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_reduceValue = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
}
/** 打开设备*/
public boolean open() throws android.os.RemoteException;
/** 关闭设备*/
public boolean close() throws android.os.RemoteException;
/** 复位卡片*/
public byte[] reset(int cardType) throws android.os.RemoteException;
/** 卡片是否在位*/
public boolean isExist() throws android.os.RemoteException;
/** 发送Apdu指令*/
public byte[] apduComm(byte[] apdu) throws android.os.RemoteException;
/** 断开*/
public int halt() throws android.os.RemoteException;
/** 获取卡类型 */
public int getCardType() throws android.os.RemoteException;
//以下接口只针对M1卡有效
/** 认证  */
public int auth(int type, byte blockaddr, byte[] keydata, byte[] resetRes) throws android.os.RemoteException;
/** 读数据 */
public int readBlock(byte blockaddr, byte[] blockdata) throws android.os.RemoteException;
/** 写数据 */
public int writeBlock(byte blockaddr, byte[] data) throws android.os.RemoteException;
/** 加值 */
public int addValue(byte blockaddr, byte[] data) throws android.os.RemoteException;
/** 减值 */
public int reduceValue(byte blockaddr, byte[] data) throws android.os.RemoteException;
}
