/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/AidlDeviceService.aidl
 */
package com.dc.p92pos.aidl;
public interface AidlDeviceService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.AidlDeviceService
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.AidlDeviceService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.AidlDeviceService interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.AidlDeviceService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.AidlDeviceService))) {
return ((com.dc.p92pos.aidl.AidlDeviceService)iin);
}
return new com.dc.p92pos.aidl.AidlDeviceService.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getSystemService:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getSystemService();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getMagCardReader:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getMagCardReader();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPinPad:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
android.os.IBinder _result = this.getPinPad(_arg0);
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getKeyboard:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getKeyboard();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getInsertCardReader:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getInsertCardReader();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getRFIDReader:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getRFIDReader();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPSAMReader:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
android.os.IBinder _result = this.getPSAMReader(_arg0);
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getSerialPort:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
android.os.IBinder _result = this.getSerialPort(_arg0);
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPrinter:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPrinter();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getEMVL2:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getEMVL2();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getTools:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getTools();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getGuardProcess:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getGuardProcess();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getLed:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getLed();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getLedAndBeep:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getLedAndBeep();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getShellMonitor:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getShellMonitor();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPosTradeInfo:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPosTradeInfo();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getDcPhotograph:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getDcPhotograph();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPosUserInfo:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPosUserInfo();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPosCommunicationParamInfo:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPosCommunicationParamInfo();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPosTerminalParamInfo:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPosTerminalParamInfo();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPosTradeParamInfo:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPosTradeParamInfo();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPosRFParamInfo:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPosRFParamInfo();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPosTerminalStatus:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPosTerminalStatus();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getPosBinParams:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getPosBinParams();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
case TRANSACTION_getSetting:
{
data.enforceInterface(DESCRIPTOR);
android.os.IBinder _result = this.getSetting();
reply.writeNoException();
reply.writeStrongBinder(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.AidlDeviceService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/** 获取系统服务接口  */
@Override public android.os.IBinder getSystemService() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getSystemService, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取磁条卡设备操作实例  */
@Override public android.os.IBinder getMagCardReader() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getMagCardReader, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取密码键盘操作实例  */
@Override public android.os.IBinder getPinPad(int devid) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(devid);
mRemote.transact(Stub.TRANSACTION_getPinPad, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//参数标识内置外置密码键盘
/** 获取数字键盘操作实例  */
@Override public android.os.IBinder getKeyboard() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getKeyboard, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 接触式IC卡设备实例  */
@Override public android.os.IBinder getInsertCardReader() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getInsertCardReader, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 非接触式IC卡设备实例  */
@Override public android.os.IBinder getRFIDReader() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getRFIDReader, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PSAM卡设备操作实例 */
@Override public android.os.IBinder getPSAMReader(int devid) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(devid);
mRemote.transact(Stub.TRANSACTION_getPSAMReader, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取串口操作实例  */
@Override public android.os.IBinder getSerialPort(int port) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(port);
mRemote.transact(Stub.TRANSACTION_getSerialPort, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取打印机操作实例  */
@Override public android.os.IBinder getPrinter() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPrinter, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取EMV操作实例  */
@Override public android.os.IBinder getEMVL2() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getEMVL2, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取Tools操作实例  */
@Override public android.os.IBinder getTools() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getTools, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取GuardProcess操作实例  */
@Override public android.os.IBinder getGuardProcess() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getGuardProcess, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取Led操作实例  */
@Override public android.os.IBinder getLed() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getLed, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取蜂鸣器和Led实例*/
@Override public android.os.IBinder getLedAndBeep() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getLedAndBeep, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取ShellMonitor操作实例  */
@Override public android.os.IBinder getShellMonitor() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getShellMonitor, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PosTradeInfo操作实例  */
@Override public android.os.IBinder getPosTradeInfo() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPosTradeInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取扫码接口*/
@Override public android.os.IBinder getDcPhotograph() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getDcPhotograph, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PosUserInfo操作实例  */
@Override public android.os.IBinder getPosUserInfo() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPosUserInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PosCommunicationParamInfo操作实例  */
@Override public android.os.IBinder getPosCommunicationParamInfo() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPosCommunicationParamInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PosTerminalParamInfo操作实例  */
@Override public android.os.IBinder getPosTerminalParamInfo() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPosTerminalParamInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PosTradeParamInfo操作实例  */
@Override public android.os.IBinder getPosTradeParamInfo() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPosTradeParamInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PosRFParamInfo操作实例  */
@Override public android.os.IBinder getPosRFParamInfo() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPosRFParamInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PosTerminalStatus操作实例  */
@Override public android.os.IBinder getPosTerminalStatus() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPosTerminalStatus, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取PosBinParams操作实例  */
@Override public android.os.IBinder getPosBinParams() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPosBinParams, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取Setting操作实例  */
@Override public android.os.IBinder getSetting() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
android.os.IBinder _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getSetting, _data, _reply, 0);
_reply.readException();
_result = _reply.readStrongBinder();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getSystemService = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getMagCardReader = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getPinPad = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getKeyboard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getInsertCardReader = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_getRFIDReader = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_getPSAMReader = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_getSerialPort = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_getPrinter = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_getEMVL2 = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_getTools = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_getGuardProcess = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_getLed = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_getLedAndBeep = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_getShellMonitor = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_getPosTradeInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_getDcPhotograph = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_getPosUserInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_getPosCommunicationParamInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_getPosTerminalParamInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_getPosTradeParamInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_getPosRFParamInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_getPosTerminalStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
static final int TRANSACTION_getPosBinParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
static final int TRANSACTION_getSetting = (android.os.IBinder.FIRST_CALL_TRANSACTION + 24);
}
/** 获取系统服务接口  */
public android.os.IBinder getSystemService() throws android.os.RemoteException;
/** 获取磁条卡设备操作实例  */
public android.os.IBinder getMagCardReader() throws android.os.RemoteException;
/** 获取密码键盘操作实例  */
public android.os.IBinder getPinPad(int devid) throws android.os.RemoteException;
//参数标识内置外置密码键盘
/** 获取数字键盘操作实例  */
public android.os.IBinder getKeyboard() throws android.os.RemoteException;
/** 接触式IC卡设备实例  */
public android.os.IBinder getInsertCardReader() throws android.os.RemoteException;
/** 非接触式IC卡设备实例  */
public android.os.IBinder getRFIDReader() throws android.os.RemoteException;
/** 获取PSAM卡设备操作实例 */
public android.os.IBinder getPSAMReader(int devid) throws android.os.RemoteException;
/** 获取串口操作实例  */
public android.os.IBinder getSerialPort(int port) throws android.os.RemoteException;
/** 获取打印机操作实例  */
public android.os.IBinder getPrinter() throws android.os.RemoteException;
/** 获取EMV操作实例  */
public android.os.IBinder getEMVL2() throws android.os.RemoteException;
/** 获取Tools操作实例  */
public android.os.IBinder getTools() throws android.os.RemoteException;
/** 获取GuardProcess操作实例  */
public android.os.IBinder getGuardProcess() throws android.os.RemoteException;
/** 获取Led操作实例  */
public android.os.IBinder getLed() throws android.os.RemoteException;
/** 获取蜂鸣器和Led实例*/
public android.os.IBinder getLedAndBeep() throws android.os.RemoteException;
/** 获取ShellMonitor操作实例  */
public android.os.IBinder getShellMonitor() throws android.os.RemoteException;
/** 获取PosTradeInfo操作实例  */
public android.os.IBinder getPosTradeInfo() throws android.os.RemoteException;
/** 获取扫码接口*/
public android.os.IBinder getDcPhotograph() throws android.os.RemoteException;
/** 获取PosUserInfo操作实例  */
public android.os.IBinder getPosUserInfo() throws android.os.RemoteException;
/** 获取PosCommunicationParamInfo操作实例  */
public android.os.IBinder getPosCommunicationParamInfo() throws android.os.RemoteException;
/** 获取PosTerminalParamInfo操作实例  */
public android.os.IBinder getPosTerminalParamInfo() throws android.os.RemoteException;
/** 获取PosTradeParamInfo操作实例  */
public android.os.IBinder getPosTradeParamInfo() throws android.os.RemoteException;
/** 获取PosRFParamInfo操作实例  */
public android.os.IBinder getPosRFParamInfo() throws android.os.RemoteException;
/** 获取PosTerminalStatus操作实例  */
public android.os.IBinder getPosTerminalStatus() throws android.os.RemoteException;
/** 获取PosBinParams操作实例  */
public android.os.IBinder getPosBinParams() throws android.os.RemoteException;
/** 获取Setting操作实例  */
public android.os.IBinder getSetting() throws android.os.RemoteException;
}
