/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/magcard/EncryptMagCardListener.aidl
 */
package com.dc.p92pos.aidl.magcard;
public interface EncryptMagCardListener extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.magcard.EncryptMagCardListener
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.magcard.EncryptMagCardListener";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.magcard.EncryptMagCardListener interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.magcard.EncryptMagCardListener asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.magcard.EncryptMagCardListener))) {
return ((com.dc.p92pos.aidl.magcard.EncryptMagCardListener)iin);
}
return new com.dc.p92pos.aidl.magcard.EncryptMagCardListener.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onTimeout:
{
data.enforceInterface(DESCRIPTOR);
this.onTimeout();
reply.writeNoException();
return true;
}
case TRANSACTION_onError:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onError(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onCanceled:
{
data.enforceInterface(DESCRIPTOR);
this.onCanceled();
reply.writeNoException();
return true;
}
case TRANSACTION_onSuccess:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String[] _arg0;
_arg0 = data.createStringArray();
this.onSuccess(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onGetTrackFail:
{
data.enforceInterface(DESCRIPTOR);
this.onGetTrackFail();
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.magcard.EncryptMagCardListener
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/** 超时*/
@Override public void onTimeout() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onTimeout, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 设备模块错误*/
@Override public void onError(int errorCode) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(errorCode);
mRemote.transact(Stub.TRANSACTION_onError, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 被取消*/
@Override public void onCanceled() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onCanceled, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 刷卡成功，返回加密的刷卡数据 */
@Override public void onSuccess(java.lang.String[] trackData) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStringArray(trackData);
mRemote.transact(Stub.TRANSACTION_onSuccess, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 刷卡失败，读取磁道失败*/
@Override public void onGetTrackFail() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onGetTrackFail, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_onTimeout = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onError = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onCanceled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_onSuccess = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_onGetTrackFail = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
}
/** 超时*/
public void onTimeout() throws android.os.RemoteException;
/** 设备模块错误*/
public void onError(int errorCode) throws android.os.RemoteException;
/** 被取消*/
public void onCanceled() throws android.os.RemoteException;
/** 刷卡成功，返回加密的刷卡数据 */
public void onSuccess(java.lang.String[] trackData) throws android.os.RemoteException;
/** 刷卡失败，读取磁道失败*/
public void onGetTrackFail() throws android.os.RemoteException;
}
