/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/pinpad/AidlPinpad.aidl
 */
package com.dc.p92pos.aidl.pinpad;
public interface AidlPinpad extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.pinpad.AidlPinpad
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.pinpad.AidlPinpad";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.pinpad.AidlPinpad interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.pinpad.AidlPinpad asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.pinpad.AidlPinpad))) {
return ((com.dc.p92pos.aidl.pinpad.AidlPinpad)iin);
}
return new com.dc.p92pos.aidl.pinpad.AidlPinpad.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getPin:
{
data.enforceInterface(DESCRIPTOR);
android.os.Bundle _arg0;
if ((0!=data.readInt())) {
_arg0 = android.os.Bundle.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
com.dc.p92pos.aidl.pinpad.GetPinListener _arg1;
_arg1 = com.dc.p92pos.aidl.pinpad.GetPinListener.Stub.asInterface(data.readStrongBinder());
this.getPin(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_stopGetPin:
{
data.enforceInterface(DESCRIPTOR);
this.stopGetPin();
reply.writeNoException();
return true;
}
case TRANSACTION_confirmGetPin:
{
data.enforceInterface(DESCRIPTOR);
this.confirmGetPin();
reply.writeNoException();
return true;
}
case TRANSACTION_loadMainkey:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
byte[] _arg1;
_arg1 = data.createByteArray();
byte[] _arg2;
_arg2 = data.createByteArray();
boolean _result = this.loadMainkey(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_loadWorkKey:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
byte[] _arg3;
_arg3 = data.createByteArray();
byte[] _arg4;
_arg4 = data.createByteArray();
boolean _result = this.loadWorkKey(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_getMac:
{
data.enforceInterface(DESCRIPTOR);
android.os.Bundle _arg0;
if ((0!=data.readInt())) {
_arg0 = android.os.Bundle.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
byte[] _arg1;
int _arg1_length = data.readInt();
if ((_arg1_length<0)) {
_arg1 = null;
}
else {
_arg1 = new byte[_arg1_length];
}
int _result = this.getMac(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
reply.writeByteArray(_arg1);
return true;
}
case TRANSACTION_encryptByTdk:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
byte _arg1;
_arg1 = data.readByte();
byte[] _arg2;
_arg2 = data.createByteArray();
byte[] _arg3;
_arg3 = data.createByteArray();
byte[] _arg4;
int _arg4_length = data.readInt();
if ((_arg4_length<0)) {
_arg4 = null;
}
else {
_arg4 = new byte[_arg4_length];
}
int _result = this.encryptByTdk(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeInt(_result);
reply.writeByteArray(_arg4);
return true;
}
case TRANSACTION_getRandom:
{
data.enforceInterface(DESCRIPTOR);
byte[] _result = this.getRandom();
reply.writeNoException();
reply.writeByteArray(_result);
return true;
}
case TRANSACTION_display:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
boolean _result = this.display(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_loadTEK:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
byte[] _arg1;
_arg1 = data.createByteArray();
byte[] _arg2;
_arg2 = data.createByteArray();
boolean _result = this.loadTEK(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_loadTWK:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
byte[] _arg3;
_arg3 = data.createByteArray();
byte[] _arg4;
_arg4 = data.createByteArray();
boolean _result = this.loadTWK(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_loadEncryptMainkey:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
byte[] _arg3;
_arg3 = data.createByteArray();
byte[] _arg4;
_arg4 = data.createByteArray();
boolean _result = this.loadEncryptMainkey(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_clearMainkey:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _result = this.clearMainkey(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.pinpad.AidlPinpad
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/** 输入PIN接口 */
@Override public void getPin(android.os.Bundle param, com.dc.p92pos.aidl.pinpad.GetPinListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((param!=null)) {
_data.writeInt(1);
param.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_getPin, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 取消输入PIN */
@Override public void stopGetPin() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_stopGetPin, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 确认PIN输入，lcd模拟确认键 */
@Override public void confirmGetPin() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_confirmGetPin, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 下装主密钥 */
@Override public boolean loadMainkey(int keyID, byte[] key, byte[] checkvalue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(keyID);
_data.writeByteArray(key);
_data.writeByteArray(checkvalue);
mRemote.transact(Stub.TRANSACTION_loadMainkey, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 下装工作密钥 */
@Override public boolean loadWorkKey(int keyType, int masterKeyId, int wkeyid, byte[] keyvalue, byte[] checkvalue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(keyType);
_data.writeInt(masterKeyId);
_data.writeInt(wkeyid);
_data.writeByteArray(keyvalue);
_data.writeByteArray(checkvalue);
mRemote.transact(Stub.TRANSACTION_loadWorkKey, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 计算MAC */
@Override public int getMac(android.os.Bundle param, byte[] mac) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((param!=null)) {
_data.writeInt(1);
param.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
if ((mac==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(mac.length);
}
mRemote.transact(Stub.TRANSACTION_getMac, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
_reply.readByteArray(mac);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** TDK加密 */
@Override public int encryptByTdk(int keyindex, byte mode, byte[] random, byte[] data, byte[] encryptdata) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(keyindex);
_data.writeByte(mode);
_data.writeByteArray(random);
_data.writeByteArray(data);
if ((encryptdata==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(encryptdata.length);
}
mRemote.transact(Stub.TRANSACTION_encryptByTdk, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
_reply.readByteArray(encryptdata);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 获取随机数 */
@Override public byte[] getRandom() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
byte[] _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getRandom, _data, _reply, 0);
_reply.readException();
_result = _reply.createByteArray();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 密码键盘LED显示信息(外置)*/
@Override public boolean display(java.lang.String line1, java.lang.String line2) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(line1);
_data.writeString(line2);
mRemote.transact(Stub.TRANSACTION_display, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 下装TEK */
@Override public boolean loadTEK(int keyID, byte[] key, byte[] checkvalue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(keyID);
_data.writeByteArray(key);
_data.writeByteArray(checkvalue);
mRemote.transact(Stub.TRANSACTION_loadTEK, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**下装TEK加密过的TWK*/
@Override public boolean loadTWK(int keyType, int tekkeyid, int wkeyid, byte[] keyvalue, byte[] checkvalue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(keyType);
_data.writeInt(tekkeyid);
_data.writeInt(wkeyid);
_data.writeByteArray(keyvalue);
_data.writeByteArray(checkvalue);
mRemote.transact(Stub.TRANSACTION_loadTWK, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/** 下装TEK加密后的主密钥*/
@Override public boolean loadEncryptMainkey(int tekkeyid, int keyID, int customID, byte[] key, byte[] checkvalue) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(tekkeyid);
_data.writeInt(keyID);
_data.writeInt(customID);
_data.writeByteArray(key);
_data.writeByteArray(checkvalue);
mRemote.transact(Stub.TRANSACTION_loadEncryptMainkey, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**清除主密钥  keyindex主密钥索引*/
@Override public boolean clearMainkey(int keyindex) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(keyindex);
mRemote.transact(Stub.TRANSACTION_clearMainkey, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getPin = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_stopGetPin = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_confirmGetPin = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_loadMainkey = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_loadWorkKey = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_getMac = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_encryptByTdk = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_getRandom = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_display = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_loadTEK = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_loadTWK = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_loadEncryptMainkey = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_clearMainkey = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
}
/** 输入PIN接口 */
public void getPin(android.os.Bundle param, com.dc.p92pos.aidl.pinpad.GetPinListener listener) throws android.os.RemoteException;
/** 取消输入PIN */
public void stopGetPin() throws android.os.RemoteException;
/** 确认PIN输入，lcd模拟确认键 */
public void confirmGetPin() throws android.os.RemoteException;
/** 下装主密钥 */
public boolean loadMainkey(int keyID, byte[] key, byte[] checkvalue) throws android.os.RemoteException;
/** 下装工作密钥 */
public boolean loadWorkKey(int keyType, int masterKeyId, int wkeyid, byte[] keyvalue, byte[] checkvalue) throws android.os.RemoteException;
/** 计算MAC */
public int getMac(android.os.Bundle param, byte[] mac) throws android.os.RemoteException;
/** TDK加密 */
public int encryptByTdk(int keyindex, byte mode, byte[] random, byte[] data, byte[] encryptdata) throws android.os.RemoteException;
/** 获取随机数 */
public byte[] getRandom() throws android.os.RemoteException;
/** 密码键盘LED显示信息(外置)*/
public boolean display(java.lang.String line1, java.lang.String line2) throws android.os.RemoteException;
/** 下装TEK */
public boolean loadTEK(int keyID, byte[] key, byte[] checkvalue) throws android.os.RemoteException;
/**下装TEK加密过的TWK*/
public boolean loadTWK(int keyType, int tekkeyid, int wkeyid, byte[] keyvalue, byte[] checkvalue) throws android.os.RemoteException;
/** 下装TEK加密后的主密钥*/
public boolean loadEncryptMainkey(int tekkeyid, int keyID, int customID, byte[] key, byte[] checkvalue) throws android.os.RemoteException;
/**清除主密钥  keyindex主密钥索引*/
public boolean clearMainkey(int keyindex) throws android.os.RemoteException;
}
