/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/emv/AidlCheckCardListener.aidl
 */
package com.dc.p92pos.aidl.emv;
public interface AidlCheckCardListener extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.emv.AidlCheckCardListener
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.emv.AidlCheckCardListener";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.emv.AidlCheckCardListener interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.emv.AidlCheckCardListener asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.emv.AidlCheckCardListener))) {
return ((com.dc.p92pos.aidl.emv.AidlCheckCardListener)iin);
}
return new com.dc.p92pos.aidl.emv.AidlCheckCardListener.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onFindMagCard:
{
data.enforceInterface(DESCRIPTOR);
com.dc.p92pos.aidl.magcard.TrackData _arg0;
if ((0!=data.readInt())) {
_arg0 = com.dc.p92pos.aidl.magcard.TrackData.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.onFindMagCard(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onSwipeCardFail:
{
data.enforceInterface(DESCRIPTOR);
this.onSwipeCardFail();
reply.writeNoException();
return true;
}
case TRANSACTION_onFindICCard:
{
data.enforceInterface(DESCRIPTOR);
this.onFindICCard();
reply.writeNoException();
return true;
}
case TRANSACTION_onFindRFCard:
{
data.enforceInterface(DESCRIPTOR);
this.onFindRFCard();
reply.writeNoException();
return true;
}
case TRANSACTION_onTimeout:
{
data.enforceInterface(DESCRIPTOR);
this.onTimeout();
reply.writeNoException();
return true;
}
case TRANSACTION_onCanceled:
{
data.enforceInterface(DESCRIPTOR);
this.onCanceled();
reply.writeNoException();
return true;
}
case TRANSACTION_onError:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onError(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.emv.AidlCheckCardListener
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void onFindMagCard(com.dc.p92pos.aidl.magcard.TrackData data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((data!=null)) {
_data.writeInt(1);
data.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onFindMagCard, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//检测到磁条卡

@Override public void onSwipeCardFail() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onSwipeCardFail, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//刷卡失败

@Override public void onFindICCard() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onFindICCard, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//检测到接触式IC卡

@Override public void onFindRFCard() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onFindRFCard, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//检测到RF卡

@Override public void onTimeout() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onTimeout, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//检测超时

@Override public void onCanceled() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onCanceled, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
//被取消

@Override public void onError(int errCode) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(errCode);
mRemote.transact(Stub.TRANSACTION_onError, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_onFindMagCard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onSwipeCardFail = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onFindICCard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_onFindRFCard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_onTimeout = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_onCanceled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_onError = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
}
public void onFindMagCard(com.dc.p92pos.aidl.magcard.TrackData data) throws android.os.RemoteException;
//检测到磁条卡

public void onSwipeCardFail() throws android.os.RemoteException;
//刷卡失败

public void onFindICCard() throws android.os.RemoteException;
//检测到接触式IC卡

public void onFindRFCard() throws android.os.RemoteException;
//检测到RF卡

public void onTimeout() throws android.os.RemoteException;
//检测超时

public void onCanceled() throws android.os.RemoteException;
//被取消

public void onError(int errCode) throws android.os.RemoteException;
}
