/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/emv/AidlPboc.aidl
 */
package com.dc.p92pos.aidl.emv;
public interface AidlPboc extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.emv.AidlPboc
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.emv.AidlPboc";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.emv.AidlPboc interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.emv.AidlPboc asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.emv.AidlPboc))) {
return ((com.dc.p92pos.aidl.emv.AidlPboc)iin);
}
return new com.dc.p92pos.aidl.emv.AidlPboc.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_checkCard:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
boolean _arg1;
_arg1 = (0!=data.readInt());
boolean _arg2;
_arg2 = (0!=data.readInt());
int _arg3;
_arg3 = data.readInt();
int _arg4;
_arg4 = data.readInt();
byte _arg5;
_arg5 = data.readByte();
byte _arg6;
_arg6 = data.readByte();
com.dc.p92pos.aidl.emv.EmvTradeData _arg7;
if ((0!=data.readInt())) {
_arg7 = com.dc.p92pos.aidl.emv.EmvTradeData.CREATOR.createFromParcel(data);
}
else {
_arg7 = null;
}
com.dc.p92pos.aidl.emv.AidlCheckCardListener _arg8;
_arg8 = com.dc.p92pos.aidl.emv.AidlCheckCardListener.Stub.asInterface(data.readStrongBinder());
com.dc.p92pos.aidl.emv.AidlPbocStartListener _arg9;
_arg9 = com.dc.p92pos.aidl.emv.AidlPbocStartListener.Stub.asInterface(data.readStrongBinder());
this.checkCard(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8, _arg9);
reply.writeNoException();
return true;
}
case TRANSACTION_cancelCheckCard:
{
data.enforceInterface(DESCRIPTOR);
this.cancelCheckCard();
reply.writeNoException();
return true;
}
case TRANSACTION_isExist:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.isExist();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_processPBOC:
{
data.enforceInterface(DESCRIPTOR);
com.dc.p92pos.aidl.emv.EmvTradeData _arg0;
if ((0!=data.readInt())) {
_arg0 = com.dc.p92pos.aidl.emv.EmvTradeData.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
com.dc.p92pos.aidl.emv.AidlPbocStartListener _arg1;
_arg1 = com.dc.p92pos.aidl.emv.AidlPbocStartListener.Stub.asInterface(data.readStrongBinder());
this.processPBOC(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_endPBOC:
{
data.enforceInterface(DESCRIPTOR);
this.endPBOC();
reply.writeNoException();
return true;
}
case TRANSACTION_abortPBOC:
{
data.enforceInterface(DESCRIPTOR);
this.abortPBOC();
reply.writeNoException();
return true;
}
case TRANSACTION_clearKernelICTradeLog:
{
data.enforceInterface(DESCRIPTOR);
boolean _result = this.clearKernelICTradeLog();
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_readKernelData:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String[] _arg0;
_arg0 = data.createStringArray();
byte[] _arg1;
int _arg1_length = data.readInt();
if ((_arg1_length<0)) {
_arg1 = null;
}
else {
_arg1 = new byte[_arg1_length];
}
int _result = this.readKernelData(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
reply.writeByteArray(_arg1);
return true;
}
case TRANSACTION_readKernelDataEnc:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String[] _arg0;
_arg0 = data.createStringArray();
byte[] _arg1;
int _arg1_length = data.readInt();
if ((_arg1_length<0)) {
_arg1 = null;
}
else {
_arg1 = new byte[_arg1_length];
}
int _arg2;
_arg2 = data.readInt();
int _result = this.readKernelDataEnc(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
reply.writeByteArray(_arg1);
return true;
}
case TRANSACTION_setTlv:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
byte[] _arg1;
_arg1 = data.createByteArray();
this.setTlv(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_parseTLV:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _result = this.parseTLV(_arg0, _arg1);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_parseTLV2:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String[] _arg0;
_arg0 = data.createStringArray();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _result = this.parseTLV2(_arg0, _arg1);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_importAmount:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
boolean _result = this.importAmount(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_importAidSelectRes:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _result = this.importAidSelectRes(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_importPin:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
boolean _result = this.importPin(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_importUserAuthRes:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
boolean _result = this.importUserAuthRes(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_importMsgConfirmRes:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
boolean _result = this.importMsgConfirmRes(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_importECashTipConfirmRes:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
boolean _result = this.importECashTipConfirmRes(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_importOnlineResp:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
boolean _result = this.importOnlineResp(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_updateAID:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
boolean _result = this.updateAID(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_updateCAPK:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
boolean _result = this.updateCAPK(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_updateBIN:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
boolean _result = this.updateBIN(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_importConfirmCardInfoRes:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
boolean _result = this.importConfirmCardInfoRes(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
case TRANSACTION_importCheckCardRes:
{
data.enforceInterface(DESCRIPTOR);
boolean _arg0;
_arg0 = (0!=data.readInt());
boolean _result = this.importCheckCardRes(_arg0);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.emv.AidlPboc
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void checkCard(boolean supportMag, boolean supportIC, boolean supportRF, int indexKey, int timeout, byte orderType, byte shuaIc, com.dc.p92pos.aidl.emv.EmvTradeData tradeData, com.dc.p92pos.aidl.emv.AidlCheckCardListener checkcardlistener, com.dc.p92pos.aidl.emv.AidlPbocStartListener pboclistener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((supportMag)?(1):(0)));
_data.writeInt(((supportIC)?(1):(0)));
_data.writeInt(((supportRF)?(1):(0)));
_data.writeInt(indexKey);
_data.writeInt(timeout);
_data.writeByte(orderType);
_data.writeByte(shuaIc);
if ((tradeData!=null)) {
_data.writeInt(1);
tradeData.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeStrongBinder((((checkcardlistener!=null))?(checkcardlistener.asBinder()):(null)));
_data.writeStrongBinder((((pboclistener!=null))?(pboclistener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_checkCard, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void cancelCheckCard() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_cancelCheckCard, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public boolean isExist() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_isExist, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void processPBOC(com.dc.p92pos.aidl.emv.EmvTradeData tradeData, com.dc.p92pos.aidl.emv.AidlPbocStartListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((tradeData!=null)) {
_data.writeInt(1);
tradeData.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_processPBOC, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void endPBOC() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_endPBOC, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void abortPBOC() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_abortPBOC, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public boolean clearKernelICTradeLog() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_clearKernelICTradeLog, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int readKernelData(java.lang.String[] taglist, byte[] buffer) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStringArray(taglist);
if ((buffer==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(buffer.length);
}
mRemote.transact(Stub.TRANSACTION_readKernelData, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
_reply.readByteArray(buffer);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int readKernelDataEnc(java.lang.String[] taglist, byte[] buffer, int indexKey) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStringArray(taglist);
if ((buffer==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(buffer.length);
}
_data.writeInt(indexKey);
mRemote.transact(Stub.TRANSACTION_readKernelDataEnc, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
_reply.readByteArray(buffer);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void setTlv(java.lang.String tag, byte[] value) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(tag);
_data.writeByteArray(value);
mRemote.transact(Stub.TRANSACTION_setTlv, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public java.lang.String parseTLV(java.lang.String tag, java.lang.String tlvlist) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(tag);
_data.writeString(tlvlist);
mRemote.transact(Stub.TRANSACTION_parseTLV, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String parseTLV2(java.lang.String[] tags, java.lang.String tlvlist) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStringArray(tags);
_data.writeString(tlvlist);
mRemote.transact(Stub.TRANSACTION_parseTLV2, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importAmount(java.lang.String amt) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(amt);
mRemote.transact(Stub.TRANSACTION_importAmount, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importAidSelectRes(int index) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(index);
mRemote.transact(Stub.TRANSACTION_importAidSelectRes, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importPin(int type, java.lang.String pin) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(type);
_data.writeString(pin);
mRemote.transact(Stub.TRANSACTION_importPin, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importUserAuthRes(boolean res) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((res)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_importUserAuthRes, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importMsgConfirmRes(boolean confirm) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((confirm)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_importMsgConfirmRes, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importECashTipConfirmRes(boolean confirm) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((confirm)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_importECashTipConfirmRes, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importOnlineResp(boolean onlineRes, java.lang.String respCode, java.lang.String icc55) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((onlineRes)?(1):(0)));
_data.writeString(respCode);
_data.writeString(icc55);
mRemote.transact(Stub.TRANSACTION_importOnlineResp, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean updateAID(int optflag, java.lang.String aid) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(optflag);
_data.writeString(aid);
mRemote.transact(Stub.TRANSACTION_updateAID, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean updateCAPK(int optflag, java.lang.String capk) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(optflag);
_data.writeString(capk);
mRemote.transact(Stub.TRANSACTION_updateCAPK, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean updateBIN(int optflag, java.lang.String capk) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(optflag);
_data.writeString(capk);
mRemote.transact(Stub.TRANSACTION_updateBIN, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importConfirmCardInfoRes(boolean res) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((res)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_importConfirmCardInfoRes, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public boolean importCheckCardRes(boolean res) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(((res)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_importCheckCardRes, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_checkCard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_cancelCheckCard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_isExist = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_processPBOC = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_endPBOC = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_abortPBOC = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_clearKernelICTradeLog = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_readKernelData = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_readKernelDataEnc = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_setTlv = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_parseTLV = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_parseTLV2 = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_importAmount = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_importAidSelectRes = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_importPin = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_importUserAuthRes = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_importMsgConfirmRes = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_importECashTipConfirmRes = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_importOnlineResp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_updateAID = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_updateCAPK = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_updateBIN = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_importConfirmCardInfoRes = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
static final int TRANSACTION_importCheckCardRes = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
}
public void checkCard(boolean supportMag, boolean supportIC, boolean supportRF, int indexKey, int timeout, byte orderType, byte shuaIc, com.dc.p92pos.aidl.emv.EmvTradeData tradeData, com.dc.p92pos.aidl.emv.AidlCheckCardListener checkcardlistener, com.dc.p92pos.aidl.emv.AidlPbocStartListener pboclistener) throws android.os.RemoteException;
public void cancelCheckCard() throws android.os.RemoteException;
public boolean isExist() throws android.os.RemoteException;
public void processPBOC(com.dc.p92pos.aidl.emv.EmvTradeData tradeData, com.dc.p92pos.aidl.emv.AidlPbocStartListener listener) throws android.os.RemoteException;
public void endPBOC() throws android.os.RemoteException;
public void abortPBOC() throws android.os.RemoteException;
public boolean clearKernelICTradeLog() throws android.os.RemoteException;
public int readKernelData(java.lang.String[] taglist, byte[] buffer) throws android.os.RemoteException;
public int readKernelDataEnc(java.lang.String[] taglist, byte[] buffer, int indexKey) throws android.os.RemoteException;
public void setTlv(java.lang.String tag, byte[] value) throws android.os.RemoteException;
public java.lang.String parseTLV(java.lang.String tag, java.lang.String tlvlist) throws android.os.RemoteException;
public java.lang.String parseTLV2(java.lang.String[] tags, java.lang.String tlvlist) throws android.os.RemoteException;
public boolean importAmount(java.lang.String amt) throws android.os.RemoteException;
public boolean importAidSelectRes(int index) throws android.os.RemoteException;
public boolean importPin(int type, java.lang.String pin) throws android.os.RemoteException;
public boolean importUserAuthRes(boolean res) throws android.os.RemoteException;
public boolean importMsgConfirmRes(boolean confirm) throws android.os.RemoteException;
public boolean importECashTipConfirmRes(boolean confirm) throws android.os.RemoteException;
public boolean importOnlineResp(boolean onlineRes, java.lang.String respCode, java.lang.String icc55) throws android.os.RemoteException;
public boolean updateAID(int optflag, java.lang.String aid) throws android.os.RemoteException;
public boolean updateCAPK(int optflag, java.lang.String capk) throws android.os.RemoteException;
public boolean updateBIN(int optflag, java.lang.String capk) throws android.os.RemoteException;
public boolean importConfirmCardInfoRes(boolean res) throws android.os.RemoteException;
public boolean importCheckCardRes(boolean res) throws android.os.RemoteException;
}
