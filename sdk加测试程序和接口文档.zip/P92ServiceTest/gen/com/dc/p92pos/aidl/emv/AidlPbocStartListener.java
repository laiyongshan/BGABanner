/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/emv/AidlPbocStartListener.aidl
 */
package com.dc.p92pos.aidl.emv;
//PBOC监听器

public interface AidlPbocStartListener extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.emv.AidlPbocStartListener
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.emv.AidlPbocStartListener";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.emv.AidlPbocStartListener interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.emv.AidlPbocStartListener asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.emv.AidlPbocStartListener))) {
return ((com.dc.p92pos.aidl.emv.AidlPbocStartListener)iin);
}
return new com.dc.p92pos.aidl.emv.AidlPbocStartListener.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_requestImportAmount:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.requestImportAmount(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_requestTipsConfirm:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.requestTipsConfirm(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_requestAidSelect:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String[] _arg1;
_arg1 = data.createStringArray();
this.requestAidSelect(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_requestEcashTipsConfirm:
{
data.enforceInterface(DESCRIPTOR);
this.requestEcashTipsConfirm();
reply.writeNoException();
return true;
}
case TRANSACTION_onConfirmCardInfo:
{
data.enforceInterface(DESCRIPTOR);
com.dc.p92pos.aidl.emv.CardInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.dc.p92pos.aidl.emv.CardInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.onConfirmCardInfo(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_requestImportPin:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
boolean _arg1;
_arg1 = (0!=data.readInt());
java.lang.String _arg2;
_arg2 = data.readString();
this.requestImportPin(_arg0, _arg1, _arg2);
reply.writeNoException();
return true;
}
case TRANSACTION_requestUserAuth:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _arg1;
_arg1 = data.readString();
this.requestUserAuth(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onRequestOnline:
{
data.enforceInterface(DESCRIPTOR);
this.onRequestOnline();
reply.writeNoException();
return true;
}
case TRANSACTION_onReadCardOffLineBalance:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
this.onReadCardOffLineBalance(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
return true;
}
case TRANSACTION_onReadCardTradeLog:
{
data.enforceInterface(DESCRIPTOR);
com.dc.p92pos.aidl.emv.PCardTradeLog[] _arg0;
_arg0 = data.createTypedArray(com.dc.p92pos.aidl.emv.PCardTradeLog.CREATOR);
this.onReadCardTradeLog(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onReadCardLoadLog:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
com.dc.p92pos.aidl.emv.PCardLoadLog[] _arg2;
_arg2 = data.createTypedArray(com.dc.p92pos.aidl.emv.PCardLoadLog.CREATOR);
this.onReadCardLoadLog(_arg0, _arg1, _arg2);
reply.writeNoException();
return true;
}
case TRANSACTION_onCheckCard:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onCheckCard(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onTradeResult:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onTradeResult(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onError:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onError(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.emv.AidlPbocStartListener
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**请求输入金额*/
@Override public void requestImportAmount(int type) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(type);
mRemote.transact(Stub.TRANSACTION_requestImportAmount, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**请求提示信息*/
@Override public void requestTipsConfirm(java.lang.String msg) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(msg);
mRemote.transact(Stub.TRANSACTION_requestTipsConfirm, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**请求多应用选择*/
@Override public void requestAidSelect(int times, java.lang.String[] aids) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(times);
_data.writeStringArray(aids);
mRemote.transact(Stub.TRANSACTION_requestAidSelect, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**请求确认是否使用电子现金*/
@Override public void requestEcashTipsConfirm() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_requestEcashTipsConfirm, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**请求确认卡信息*/
@Override public void onConfirmCardInfo(com.dc.p92pos.aidl.emv.CardInfo cardInfo) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((cardInfo!=null)) {
_data.writeInt(1);
cardInfo.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onConfirmCardInfo, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 请求导入PIN */
@Override public void requestImportPin(int type, boolean lasttimeFlag, java.lang.String amt) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(type);
_data.writeInt(((lasttimeFlag)?(1):(0)));
_data.writeString(amt);
mRemote.transact(Stub.TRANSACTION_requestImportPin, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/** 请求身份认证 */
@Override public void requestUserAuth(int certype, java.lang.String certnumber) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(certype);
_data.writeString(certnumber);
mRemote.transact(Stub.TRANSACTION_requestUserAuth, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**请求联机*/
@Override public void onRequestOnline() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onRequestOnline, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**返回读取卡片脱机余额结果*/
@Override public void onReadCardOffLineBalance(java.lang.String moneyCode, java.lang.String balance, java.lang.String secondMoneyCode, java.lang.String secondBalance) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(moneyCode);
_data.writeString(balance);
_data.writeString(secondMoneyCode);
_data.writeString(secondBalance);
mRemote.transact(Stub.TRANSACTION_onReadCardOffLineBalance, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**返回读取卡片交易日志结果*/
@Override public void onReadCardTradeLog(com.dc.p92pos.aidl.emv.PCardTradeLog[] log) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeTypedArray(log, 0);
mRemote.transact(Stub.TRANSACTION_onReadCardTradeLog, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**返回读取卡片圈存日志结果*/
@Override public void onReadCardLoadLog(java.lang.String atc, java.lang.String checkCode, com.dc.p92pos.aidl.emv.PCardLoadLog[] logs) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(atc);
_data.writeString(checkCode);
_data.writeTypedArray(logs, 0);
mRemote.transact(Stub.TRANSACTION_onReadCardLoadLog, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**请求检卡*/
@Override public void onCheckCard(int type) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(type);
mRemote.transact(Stub.TRANSACTION_onCheckCard, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**交易结果
	批准: 0x01
	拒绝: 0x02
	终止: 0x03
	FALLBACK: 0x04
	采用其他界面: 0x05
	其他：0x06
	*/
@Override public void onTradeResult(int result) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(result);
mRemote.transact(Stub.TRANSACTION_onTradeResult, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**出错*/
@Override public void onError(int erroCode) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(erroCode);
mRemote.transact(Stub.TRANSACTION_onError, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_requestImportAmount = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_requestTipsConfirm = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_requestAidSelect = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_requestEcashTipsConfirm = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_onConfirmCardInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_requestImportPin = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_requestUserAuth = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_onRequestOnline = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_onReadCardOffLineBalance = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_onReadCardTradeLog = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_onReadCardLoadLog = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_onCheckCard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_onTradeResult = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_onError = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
}
/**请求输入金额*/
public void requestImportAmount(int type) throws android.os.RemoteException;
/**请求提示信息*/
public void requestTipsConfirm(java.lang.String msg) throws android.os.RemoteException;
/**请求多应用选择*/
public void requestAidSelect(int times, java.lang.String[] aids) throws android.os.RemoteException;
/**请求确认是否使用电子现金*/
public void requestEcashTipsConfirm() throws android.os.RemoteException;
/**请求确认卡信息*/
public void onConfirmCardInfo(com.dc.p92pos.aidl.emv.CardInfo cardInfo) throws android.os.RemoteException;
/** 请求导入PIN */
public void requestImportPin(int type, boolean lasttimeFlag, java.lang.String amt) throws android.os.RemoteException;
/** 请求身份认证 */
public void requestUserAuth(int certype, java.lang.String certnumber) throws android.os.RemoteException;
/**请求联机*/
public void onRequestOnline() throws android.os.RemoteException;
/**返回读取卡片脱机余额结果*/
public void onReadCardOffLineBalance(java.lang.String moneyCode, java.lang.String balance, java.lang.String secondMoneyCode, java.lang.String secondBalance) throws android.os.RemoteException;
/**返回读取卡片交易日志结果*/
public void onReadCardTradeLog(com.dc.p92pos.aidl.emv.PCardTradeLog[] log) throws android.os.RemoteException;
/**返回读取卡片圈存日志结果*/
public void onReadCardLoadLog(java.lang.String atc, java.lang.String checkCode, com.dc.p92pos.aidl.emv.PCardLoadLog[] logs) throws android.os.RemoteException;
/**请求检卡*/
public void onCheckCard(int type) throws android.os.RemoteException;
/**交易结果
	批准: 0x01
	拒绝: 0x02
	终止: 0x03
	FALLBACK: 0x04
	采用其他界面: 0x05
	其他：0x06
	*/
public void onTradeResult(int result) throws android.os.RemoteException;
/**出错*/
public void onError(int erroCode) throws android.os.RemoteException;
}
