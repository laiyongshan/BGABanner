/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/keyboard/AidlKeyboard.aidl
 */
package com.dc.p92pos.aidl.keyboard;
public interface AidlKeyboard extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.keyboard.AidlKeyboard
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.keyboard.AidlKeyboard";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.keyboard.AidlKeyboard interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.keyboard.AidlKeyboard asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.keyboard.AidlKeyboard))) {
return ((com.dc.p92pos.aidl.keyboard.AidlKeyboard)iin);
}
return new com.dc.p92pos.aidl.keyboard.AidlKeyboard.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_display:
{
data.enforceInterface(DESCRIPTOR);
android.os.Bundle _arg0;
if ((0!=data.readInt())) {
_arg0 = android.os.Bundle.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
com.dc.p92pos.aidl.keyboard.GetKeyboardListener _arg1;
_arg1 = com.dc.p92pos.aidl.keyboard.GetKeyboardListener.Stub.asInterface(data.readStrongBinder());
boolean _result = this.display(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(((_result)?(1):(0)));
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.keyboard.AidlKeyboard
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/** 密码键盘LED显示信息(内置)*/
@Override public boolean display(android.os.Bundle param, com.dc.p92pos.aidl.keyboard.GetKeyboardListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((param!=null)) {
_data.writeInt(1);
param.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_display, _data, _reply, 0);
_reply.readException();
_result = (0!=_reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_display = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
}
/** 密码键盘LED显示信息(内置)*/
public boolean display(android.os.Bundle param, com.dc.p92pos.aidl.keyboard.GetKeyboardListener listener) throws android.os.RemoteException;
}
