/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/db/AidlPosTradeInfo.aidl
 */
package com.dc.p92pos.aidl.db;
public interface AidlPosTradeInfo extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.db.AidlPosTradeInfo
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.db.AidlPosTradeInfo";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.db.AidlPosTradeInfo interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.db.AidlPosTradeInfo asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.db.AidlPosTradeInfo))) {
return ((com.dc.p92pos.aidl.db.AidlPosTradeInfo)iin);
}
return new com.dc.p92pos.aidl.db.AidlPosTradeInfo.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onSaveTradeInfo:
{
data.enforceInterface(DESCRIPTOR);
com.dc.p92pos.aidl.db.TradeInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.dc.p92pos.aidl.db.TradeInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
int _result = this.onSaveTradeInfo(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onDeleteTradeInfo:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.onDeleteTradeInfo(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onDeleteTradeInfoByTradeNo:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _result = this.onDeleteTradeInfoByTradeNo(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onDeleteShanKaTradeInfoByCardNo:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
int _arg2;
_arg2 = data.readInt();
int _result = this.onDeleteShanKaTradeInfoByCardNo(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onFindAllTradeInfo:
{
data.enforceInterface(DESCRIPTOR);
java.util.List<com.dc.p92pos.aidl.db.TradeInfo> _result = this.onFindAllTradeInfo();
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_onFindTradeInfoById:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
com.dc.p92pos.aidl.db.TradeInfo _result = this.onFindTradeInfoById(_arg0);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_onFindTradeInfoByTradeNo:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
com.dc.p92pos.aidl.db.TradeInfo _result = this.onFindTradeInfoByTradeNo(_arg0);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_onSelectTradeTotal:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.onSelectTradeTotal();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_onChangeOrderStatusByTradeNo:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _result = this.onChangeOrderStatusByTradeNo(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onFindTradeInfoByRetrievalReferenceNumber:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
com.dc.p92pos.aidl.db.TradeInfo _result = this.onFindTradeInfoByRetrievalReferenceNumber(_arg0);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_onFindTradeInfoByAuthResponse:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
com.dc.p92pos.aidl.db.TradeInfo _result = this.onFindTradeInfoByAuthResponse(_arg0);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_onUpdateByTradeNo:
{
data.enforceInterface(DESCRIPTOR);
com.dc.p92pos.aidl.db.TradeInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.dc.p92pos.aidl.db.TradeInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
java.lang.String _arg1;
_arg1 = data.readString();
int _result = this.onUpdateByTradeNo(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onFindTradeInfoByFlag:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
com.dc.p92pos.aidl.db.TradeInfo _result = this.onFindTradeInfoByFlag(_arg0);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_onFindTradeInfoBySql:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.util.List<com.dc.p92pos.aidl.db.TradeInfo> _result = this.onFindTradeInfoBySql(_arg0);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_onStatisticsTradeInfoBySql:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.util.List<android.os.Bundle> _result = this.onStatisticsTradeInfoBySql(_arg0);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_onFindAllTradeInfoByDomain_60_2:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.util.List<com.dc.p92pos.aidl.db.TradeInfo> _result = this.onFindAllTradeInfoByDomain_60_2(_arg0);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_onChangeUploadStatusByTradeNo:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _result = this.onChangeUploadStatusByTradeNo(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onSelectTradeItemByTradeKind:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.util.List<com.dc.p92pos.aidl.db.TradeInfo> _result = this.onSelectTradeItemByTradeKind(_arg0);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_onUpdateById:
{
data.enforceInterface(DESCRIPTOR);
com.dc.p92pos.aidl.db.TradeInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.dc.p92pos.aidl.db.TradeInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
int _result = this.onUpdateById(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.db.AidlPosTradeInfo
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public int onSaveTradeInfo(com.dc.p92pos.aidl.db.TradeInfo data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((data!=null)) {
_data.writeInt(1);
data.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onSaveTradeInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//新增

@Override public int onDeleteTradeInfo(int id) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(id);
mRemote.transact(Stub.TRANSACTION_onDeleteTradeInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//删除

@Override public int onDeleteTradeInfoByTradeNo(java.lang.String tradeNo) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(tradeNo);
mRemote.transact(Stub.TRANSACTION_onDeleteTradeInfoByTradeNo, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//删除

@Override public int onDeleteShanKaTradeInfoByCardNo(java.lang.String tradeNo, java.lang.String cardNo, int tradeKind) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(tradeNo);
_data.writeString(cardNo);
_data.writeInt(tradeKind);
mRemote.transact(Stub.TRANSACTION_onDeleteShanKaTradeInfoByCardNo, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//删除

@Override public java.util.List<com.dc.p92pos.aidl.db.TradeInfo> onFindAllTradeInfo() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.dc.p92pos.aidl.db.TradeInfo> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onFindAllTradeInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.dc.p92pos.aidl.db.TradeInfo.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//查询所有用户

@Override public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoById(int id) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.dc.p92pos.aidl.db.TradeInfo _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(id);
mRemote.transact(Stub.TRANSACTION_onFindTradeInfoById, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = com.dc.p92pos.aidl.db.TradeInfo.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据ID查询用户数据

@Override public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoByTradeNo(java.lang.String tradeNo) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.dc.p92pos.aidl.db.TradeInfo _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(tradeNo);
mRemote.transact(Stub.TRANSACTION_onFindTradeInfoByTradeNo, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = com.dc.p92pos.aidl.db.TradeInfo.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据流水号、凭证号查询用户数据

@Override public java.lang.String onSelectTradeTotal() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onSelectTradeTotal, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//查询交易总数和总金额

@Override public int onChangeOrderStatusByTradeNo(java.lang.String tradeNo, int revoke) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(tradeNo);
_data.writeInt(revoke);
mRemote.transact(Stub.TRANSACTION_onChangeOrderStatusByTradeNo, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据流水号、凭证号更改订单状态，是否撤销

@Override public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoByRetrievalReferenceNumber(java.lang.String retrievalReferenceNumber) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.dc.p92pos.aidl.db.TradeInfo _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(retrievalReferenceNumber);
mRemote.transact(Stub.TRANSACTION_onFindTradeInfoByRetrievalReferenceNumber, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = com.dc.p92pos.aidl.db.TradeInfo.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据检索参考号查询用户数据

@Override public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoByAuthResponse(java.lang.String authResponse) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.dc.p92pos.aidl.db.TradeInfo _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(authResponse);
mRemote.transact(Stub.TRANSACTION_onFindTradeInfoByAuthResponse, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = com.dc.p92pos.aidl.db.TradeInfo.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据授权标识应答码查询用户数据

@Override public int onUpdateByTradeNo(com.dc.p92pos.aidl.db.TradeInfo tradeInfo, java.lang.String domain_11) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((tradeInfo!=null)) {
_data.writeInt(1);
tradeInfo.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeString(domain_11);
mRemote.transact(Stub.TRANSACTION_onUpdateByTradeNo, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据流水号、凭证号更改订单

@Override public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoByFlag(int flag) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.dc.p92pos.aidl.db.TradeInfo _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(flag);
mRemote.transact(Stub.TRANSACTION_onFindTradeInfoByFlag, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = com.dc.p92pos.aidl.db.TradeInfo.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
// flag 1-第一条 2-最后一条

@Override public java.util.List<com.dc.p92pos.aidl.db.TradeInfo> onFindTradeInfoBySql(java.lang.String sql) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.dc.p92pos.aidl.db.TradeInfo> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(sql);
mRemote.transact(Stub.TRANSACTION_onFindTradeInfoBySql, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.dc.p92pos.aidl.db.TradeInfo.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
// sql

@Override public java.util.List<android.os.Bundle> onStatisticsTradeInfoBySql(java.lang.String sql) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.os.Bundle> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(sql);
mRemote.transact(Stub.TRANSACTION_onStatisticsTradeInfoBySql, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.os.Bundle.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
// sql

@Override public java.util.List<com.dc.p92pos.aidl.db.TradeInfo> onFindAllTradeInfoByDomain_60_2(java.lang.String domain_60_2) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.dc.p92pos.aidl.db.TradeInfo> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(domain_60_2);
mRemote.transact(Stub.TRANSACTION_onFindAllTradeInfoByDomain_60_2, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.dc.p92pos.aidl.db.TradeInfo.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//查询改批次号下的所有交易明细

@Override public int onChangeUploadStatusByTradeNo(java.lang.String tradeNo, int isUpload) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(tradeNo);
_data.writeInt(isUpload);
mRemote.transact(Stub.TRANSACTION_onChangeUploadStatusByTradeNo, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据流水号、凭证号更改订单状态，是否在批结算时已上送

@Override public java.util.List<com.dc.p92pos.aidl.db.TradeInfo> onSelectTradeItemByTradeKind(int tradeKind) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.dc.p92pos.aidl.db.TradeInfo> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(tradeKind);
mRemote.transact(Stub.TRANSACTION_onSelectTradeItemByTradeKind, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.dc.p92pos.aidl.db.TradeInfo.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据上送值查询交易明细

@Override public int onUpdateById(com.dc.p92pos.aidl.db.TradeInfo tradeInfo) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((tradeInfo!=null)) {
_data.writeInt(1);
tradeInfo.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onUpdateById, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_onSaveTradeInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onDeleteTradeInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onDeleteTradeInfoByTradeNo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_onDeleteShanKaTradeInfoByCardNo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_onFindAllTradeInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_onFindTradeInfoById = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_onFindTradeInfoByTradeNo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_onSelectTradeTotal = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_onChangeOrderStatusByTradeNo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_onFindTradeInfoByRetrievalReferenceNumber = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_onFindTradeInfoByAuthResponse = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_onUpdateByTradeNo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_onFindTradeInfoByFlag = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_onFindTradeInfoBySql = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_onStatisticsTradeInfoBySql = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_onFindAllTradeInfoByDomain_60_2 = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_onChangeUploadStatusByTradeNo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_onSelectTradeItemByTradeKind = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_onUpdateById = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
}
public int onSaveTradeInfo(com.dc.p92pos.aidl.db.TradeInfo data) throws android.os.RemoteException;
//新增

public int onDeleteTradeInfo(int id) throws android.os.RemoteException;
//删除

public int onDeleteTradeInfoByTradeNo(java.lang.String tradeNo) throws android.os.RemoteException;
//删除

public int onDeleteShanKaTradeInfoByCardNo(java.lang.String tradeNo, java.lang.String cardNo, int tradeKind) throws android.os.RemoteException;
//删除

public java.util.List<com.dc.p92pos.aidl.db.TradeInfo> onFindAllTradeInfo() throws android.os.RemoteException;
//查询所有用户

public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoById(int id) throws android.os.RemoteException;
//根据ID查询用户数据

public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoByTradeNo(java.lang.String tradeNo) throws android.os.RemoteException;
//根据流水号、凭证号查询用户数据

public java.lang.String onSelectTradeTotal() throws android.os.RemoteException;
//查询交易总数和总金额

public int onChangeOrderStatusByTradeNo(java.lang.String tradeNo, int revoke) throws android.os.RemoteException;
//根据流水号、凭证号更改订单状态，是否撤销

public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoByRetrievalReferenceNumber(java.lang.String retrievalReferenceNumber) throws android.os.RemoteException;
//根据检索参考号查询用户数据

public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoByAuthResponse(java.lang.String authResponse) throws android.os.RemoteException;
//根据授权标识应答码查询用户数据

public int onUpdateByTradeNo(com.dc.p92pos.aidl.db.TradeInfo tradeInfo, java.lang.String domain_11) throws android.os.RemoteException;
//根据流水号、凭证号更改订单

public com.dc.p92pos.aidl.db.TradeInfo onFindTradeInfoByFlag(int flag) throws android.os.RemoteException;
// flag 1-第一条 2-最后一条

public java.util.List<com.dc.p92pos.aidl.db.TradeInfo> onFindTradeInfoBySql(java.lang.String sql) throws android.os.RemoteException;
// sql

public java.util.List<android.os.Bundle> onStatisticsTradeInfoBySql(java.lang.String sql) throws android.os.RemoteException;
// sql

public java.util.List<com.dc.p92pos.aidl.db.TradeInfo> onFindAllTradeInfoByDomain_60_2(java.lang.String domain_60_2) throws android.os.RemoteException;
//查询改批次号下的所有交易明细

public int onChangeUploadStatusByTradeNo(java.lang.String tradeNo, int isUpload) throws android.os.RemoteException;
//根据流水号、凭证号更改订单状态，是否在批结算时已上送

public java.util.List<com.dc.p92pos.aidl.db.TradeInfo> onSelectTradeItemByTradeKind(int tradeKind) throws android.os.RemoteException;
//根据上送值查询交易明细

public int onUpdateById(com.dc.p92pos.aidl.db.TradeInfo tradeInfo) throws android.os.RemoteException;
}
