/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/db/AidlPosBinParams.aidl
 */
package com.dc.p92pos.aidl.db;
public interface AidlPosBinParams extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.db.AidlPosBinParams
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.db.AidlPosBinParams";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.db.AidlPosBinParams interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.db.AidlPosBinParams asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.db.AidlPosBinParams))) {
return ((com.dc.p92pos.aidl.db.AidlPosBinParams)iin);
}
return new com.dc.p92pos.aidl.db.AidlPosBinParams.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_AfinalOrmDbCreate:
{
data.enforceInterface(DESCRIPTOR);
java.util.List<com.dc.p92pos.aidl.db.BinParams> _arg0;
_arg0 = data.createTypedArrayList(com.dc.p92pos.aidl.db.BinParams.CREATOR);
int _result = this.AfinalOrmDbCreate(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onFindAllBinParams:
{
data.enforceInterface(DESCRIPTOR);
java.util.List<com.dc.p92pos.aidl.db.BinParams> _result = this.onFindAllBinParams();
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_onFindBinParamsByParam:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _result = this.onFindBinParamsByParam(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_onDeleteBinParams:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.onDeleteBinParams();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.db.AidlPosBinParams
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public int AfinalOrmDbCreate(java.util.List<com.dc.p92pos.aidl.db.BinParams> data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeTypedList(data);
mRemote.transact(Stub.TRANSACTION_AfinalOrmDbCreate, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//新增

@Override public java.util.List<com.dc.p92pos.aidl.db.BinParams> onFindAllBinParams() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.dc.p92pos.aidl.db.BinParams> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onFindAllBinParams, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.dc.p92pos.aidl.db.BinParams.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//查询所有黑名单

@Override public int onFindBinParamsByParam(java.lang.String type, java.lang.String len, java.lang.String bin) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(type);
_data.writeString(len);
_data.writeString(bin);
mRemote.transact(Stub.TRANSACTION_onFindBinParamsByParam, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//根据参数查询

@Override public int onDeleteBinParams() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onDeleteBinParams, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_AfinalOrmDbCreate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onFindAllBinParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onFindBinParamsByParam = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_onDeleteBinParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
}
public int AfinalOrmDbCreate(java.util.List<com.dc.p92pos.aidl.db.BinParams> data) throws android.os.RemoteException;
//新增

public java.util.List<com.dc.p92pos.aidl.db.BinParams> onFindAllBinParams() throws android.os.RemoteException;
//查询所有黑名单

public int onFindBinParamsByParam(java.lang.String type, java.lang.String len, java.lang.String bin) throws android.os.RemoteException;
//根据参数查询

public int onDeleteBinParams() throws android.os.RemoteException;
}
