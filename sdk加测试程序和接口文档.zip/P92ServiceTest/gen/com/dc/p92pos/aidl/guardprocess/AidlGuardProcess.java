/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /Users/Leo/Music/P92SystemTool/P92ServiceTest/src/com/dc/p92pos/aidl/guardprocess/AidlGuardProcess.aidl
 */
package com.dc.p92pos.aidl.guardprocess;
//检测工具

public interface AidlGuardProcess extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.dc.p92pos.aidl.guardprocess.AidlGuardProcess
{
private static final java.lang.String DESCRIPTOR = "com.dc.p92pos.aidl.guardprocess.AidlGuardProcess";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.dc.p92pos.aidl.guardprocess.AidlGuardProcess interface,
 * generating a proxy if needed.
 */
public static com.dc.p92pos.aidl.guardprocess.AidlGuardProcess asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.dc.p92pos.aidl.guardprocess.AidlGuardProcess))) {
return ((com.dc.p92pos.aidl.guardprocess.AidlGuardProcess)iin);
}
return new com.dc.p92pos.aidl.guardprocess.AidlGuardProcess.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getPrinterState:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getPrinterState();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_DCDeviceTurnOnTamper:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
com.dc.p92pos.aidl.guardprocess.AidlGuardProcessListener _arg1;
_arg1 = com.dc.p92pos.aidl.guardprocess.AidlGuardProcessListener.Stub.asInterface(data.readStrongBinder());
this.DCDeviceTurnOnTamper(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_DCDeviceQueryTamper:
{
data.enforceInterface(DESCRIPTOR);
com.dc.p92pos.aidl.guardprocess.AidlGuardProcessListener _arg0;
_arg0 = com.dc.p92pos.aidl.guardprocess.AidlGuardProcessListener.Stub.asInterface(data.readStrongBinder());
this.DCDeviceQueryTamper(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_restDeviceTamper:
{
data.enforceInterface(DESCRIPTOR);
this.restDeviceTamper();
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.dc.p92pos.aidl.guardprocess.AidlGuardProcess
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/** 获取打印机状态 */
@Override public int getPrinterState() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getPrinterState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**打开安全监测TAMPER*/
@Override public void DCDeviceTurnOnTamper(byte status, com.dc.p92pos.aidl.guardprocess.AidlGuardProcessListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(status);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_DCDeviceTurnOnTamper, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**查询安全TAMPER状态*/
@Override public void DCDeviceQueryTamper(com.dc.p92pos.aidl.guardprocess.AidlGuardProcessListener listener) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((listener!=null))?(listener.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_DCDeviceQueryTamper, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/***TAMPER启用被触发，重置设备*/
@Override public void restDeviceTamper() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_restDeviceTamper, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_getPrinterState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_DCDeviceTurnOnTamper = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_DCDeviceQueryTamper = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_restDeviceTamper = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
}
/** 获取打印机状态 */
public int getPrinterState() throws android.os.RemoteException;
/**打开安全监测TAMPER*/
public void DCDeviceTurnOnTamper(byte status, com.dc.p92pos.aidl.guardprocess.AidlGuardProcessListener listener) throws android.os.RemoteException;
/**查询安全TAMPER状态*/
public void DCDeviceQueryTamper(com.dc.p92pos.aidl.guardprocess.AidlGuardProcessListener listener) throws android.os.RemoteException;
/***TAMPER启用被触发，重置设备*/
public void restDeviceTamper() throws android.os.RemoteException;
}
