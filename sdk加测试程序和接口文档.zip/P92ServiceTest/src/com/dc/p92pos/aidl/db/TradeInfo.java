package com.dc.p92pos.aidl.db;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 卡数据bean
 * 
 * @author 
 * 
 */
public class TradeInfo implements Parcelable, Cloneable {
	
	private int id = 0;
	//0: 消息类型
	private String domain_0 = "";
	//2: 主账号
	private String domain_2 = "";
	//3: 交易处理码
	private String domain_3 = "";
	//4：交易金额
	private String domain_4 = "";
	//11：受卡方系统跟踪号---流水号
	private String domain_11 = "";
	//12： 受卡方所在地时间  hhmmss
	private String domain_12 = "";
	//13： 受卡方所在地日期  MMDD
	private String domain_13 = "";
	//14：卡有效期
	private String domain_14 = "";
	//15：清算日期
	private String domain_15 = "";
	//22：服务点输入方式码
	private String domain_22 = "";
	//23：卡片序列号
	private String domain_23 = "";
	//25：服务点条件码
	private String domain_25 = "";
	//26：服务点pin获取码
	private String domain_26 = "";
	//32：受理机构标识码
	private String domain_32 = "";
	//35：2磁道数据
	private String domain_35 = "";
	//36：3磁道数据
	private String domain_36 = "";
	//37：检索参考号
	private String domain_37 = "";
	//38：授权标识应答码
	private String domain_38 = "";
	//38：授权标识应答码(后台返回)
	private String domain_38_2 = "";
	//39：应答码
	private String domain_39 = "";
	//41：受卡机终端标识码
	private String domain_41 = "";
	//42：受卡机标识码
	private String domain_42 = "";
	//44：附加响应数据
	private String domain_44 = "";
	//48：附加数据-私有
	private String domain_48 = "";
	//49：交易货币代码
	private String domain_49 = "";
	//52：个人标示码数据
	private String domain_52 = "";
	//53：安全控制信息
	private String domain_53 = "";
	//54：余额
	private String domain_54 = "";
	//55：IC 卡数据域
	private String domain_55 = "";
	//备份打印数据
	private String domain_55_2 = "";
	//58：PBOC电子钱包的标准交易信息
	private String domain_58 = "";
	//60：自定义域
	private String domain_60 = "";
	//60.1：自定义域--消息类型码  N2
	private String domain_60_1 = "";
	//60.2：自定义域--批次号 N6
	private String domain_60_2 = "";
	//60.3：自定义域--网络管理信息码 N3
	private String domain_60_3 = "";
	//60.4：自定义域--终端读取能力 N1
	private String domain_60_4 = "6";
	//60.5：自定义域--基于PBOC借记贷记标准的IC卡条件代码 N1
	private String domain_60_5 = "0";
	//60.6：自定义域--支持部分扣款和返回余额标志 N1
	private String domain_60_6 = "";
	//60.7：自定义域--账户类型 N3
	private String domain_60_7 = "";
	//61：原始数据域
	private String domain_61 = "";
	//61.1：原始数据域--原交易批次号 N6
	private String domain_61_1 = "";
	//61.2：原始数据域--原交易pos流水号 N6
	private String domain_61_2 = "";
	//61.3：原始数据域--原交易日期 N4
	private String domain_61_3 = "";
	//61.4：原始数据域--原交易授权方式 N2
	private String domain_61_4 = "";
	//61.5：原始数据域--原交易授权机构代码 N11
	private String domain_61_5 = "";
	//62：自定义域
	private String domain_62 = "";
	//保存应答码
	private String domain_62_2 = "";
	//63：自定义域
	private String domain_63 = "";
	//64：报文鉴别码
	private String domain_64 = "";

	//交易时间
	private String tradeTime = "";
	//操作员
	private String operator = "";
	//交易类型
	private int tradeType = 0;
	//应用密文类型  0-正常 1-交易被拒 2-ARPC错误
	private int pwdType = 0;
	//是否撤销 0：消费  2：该笔交易已经调整过 3：该笔交易已经撤销
	private int revoke = 0;
	//发送次数
	private int sendNum = 0;
	//上送序列
	private int uploadSerialNo = 0;
	
	//0：联机 1：脱机 2：离线消费 3：发卡行脚本 4：冲正 5：离线消费失败 6：闪卡 7:上送失败 8:上送被拒
	private int tradeKind = 0;
	public enum TradeKind {
		Online,
		tuoji,
		lixian,
		Script,
		Correct,
		lixianFail,
		shanka,
		uploadFail,
		uploadRefuse
	}
	
	//上送状态 0：未上传 1：已上送 2：批上送 3：结算调整 
	private int status = 0;
	public enum TradeStatus {
		UnUpload,
		Uploaded,
		BatchUploaded,
		SettleAdjust
	}
	
	//卡类型 -1:默认 0:磁条卡 1：IC卡 2:非接卡 3:手输卡号 4:无卡 5:手机预约消费
	private int cardType = -1;
	public enum CardType {
		MagCard,
		ICCard,
		RFCard,
		ShouShuCard,
		NoCard,
		YuYueCard
	}
	
	public TradeInfo(){}
	
	public TradeInfo(Parcel source) {
		id = source.readInt();
		domain_0 = source.readString();
		domain_2 = source.readString();
		domain_3 = source.readString();
		domain_4 = source.readString();
		domain_11 = source.readString();
		domain_12 = source.readString();
		domain_13 = source.readString();
		domain_14 = source.readString();
		domain_15 = source.readString();
		domain_22 = source.readString();
		domain_23 = source.readString();
		domain_25 = source.readString();
		domain_26 = source.readString();
		domain_32 = source.readString();
		domain_35 = source.readString();
		domain_36 = source.readString();
		domain_37 = source.readString();
		domain_38 = source.readString();
		domain_38_2 = source.readString();
		domain_39 = source.readString();
		domain_41 = source.readString();
		domain_42 = source.readString();
		domain_44 = source.readString();
		domain_48 = source.readString();
		domain_49 = source.readString();
		domain_52 = source.readString();
		domain_53 = source.readString();
		domain_54 = source.readString();
		domain_55 = source.readString();
		domain_55_2 = source.readString();
		domain_58 = source.readString();
		domain_60 = source.readString();
		domain_60_1 = source.readString();
		domain_60_2 = source.readString();
		domain_60_3 = source.readString();
		domain_60_4 = source.readString();
		domain_60_5 = source.readString();
		domain_60_6 = source.readString();
		domain_60_7 = source.readString();
		domain_61 = source.readString();
		domain_61_1 = source.readString();
		domain_61_2 = source.readString();
		domain_61_3 = source.readString();
		domain_61_4 = source.readString();
		domain_61_5 = source.readString();
		domain_62 = source.readString();
		domain_62_2 = source.readString();
		domain_63 = source.readString();
		domain_64 = source.readString();
		
		tradeTime = source.readString();
		operator = source.readString();
		cardType = Integer.parseInt(source.readString());
		tradeType = Integer.parseInt(source.readString());
		revoke = Integer.parseInt(source.readString());
		status = Integer.parseInt(source.readString());
		pwdType = Integer.parseInt(source.readString());
		tradeKind = Integer.parseInt(source.readString());
	}
	
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(domain_0);
		dest.writeString(domain_2);
		dest.writeString(domain_3);
		dest.writeString(domain_4);
		dest.writeString(domain_11);
		dest.writeString(domain_12);
		dest.writeString(domain_13);
		dest.writeString(domain_14);
		dest.writeString(domain_15);
		dest.writeString(domain_22);
		dest.writeString(domain_23);
		dest.writeString(domain_25);
		dest.writeString(domain_26);
		dest.writeString(domain_32);
		dest.writeString(domain_35);
		dest.writeString(domain_36);
		dest.writeString(domain_37);
		dest.writeString(domain_38);
		dest.writeString(domain_38_2);
		dest.writeString(domain_39);
		dest.writeString(domain_41);
		dest.writeString(domain_42);
		dest.writeString(domain_44);
		dest.writeString(domain_48);
		dest.writeString(domain_49);
		dest.writeString(domain_52);
		dest.writeString(domain_53);
		dest.writeString(domain_54);
		dest.writeString(domain_55);
		dest.writeString(domain_55_2);
		dest.writeString(domain_58);
		dest.writeString(domain_60);
		dest.writeString(domain_60_1);
		dest.writeString(domain_60_2);
		dest.writeString(domain_60_3);
		dest.writeString(domain_60_4);
		dest.writeString(domain_60_5);
		dest.writeString(domain_60_6);
		dest.writeString(domain_60_7);
		dest.writeString(domain_61);
		dest.writeString(domain_61_1);
		dest.writeString(domain_61_2);
		dest.writeString(domain_61_3);
		dest.writeString(domain_61_4);
		dest.writeString(domain_61_5);
		dest.writeString(domain_62);
		dest.writeString(domain_62_2);
		dest.writeString(domain_63);
		dest.writeString(domain_64);
		
		dest.writeString(tradeTime);
		dest.writeString(operator);
		dest.writeString(""+cardType);
		dest.writeString(""+tradeType);
		dest.writeString(""+revoke);
		dest.writeString(""+status);
		dest.writeString(""+pwdType);
		dest.writeString(""+tradeKind);
	}

	public static final Parcelable.Creator<TradeInfo> CREATOR = new Creator<TradeInfo>() {

		@Override
		public TradeInfo createFromParcel(Parcel source) {
			TradeInfo cardno = new TradeInfo(source);
			return cardno;
		}

		@Override
		public TradeInfo[] newArray(int size) {
			return new TradeInfo[size];
		}
	};
	
	@Override
	public int describeContents() {
		return 0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDomain_0() {
		return domain_0;
	}

	public void setDomain_0(String domain_0) {
		this.domain_0 = domain_0;
	}
	
	public String getDomain_2() {
		return domain_2;
	}

	public void setDomain_2(String domain_2) {
		this.domain_2 = domain_2;
	}

	public String getDomain_3() {
		return domain_3;
	}

	public void setDomain_3(String domain_3) {
		this.domain_3 = domain_3;
	}

	public String getDomain_4() {
		return domain_4;
	}

	public void setDomain_4(String domain_4) {
		this.domain_4 = domain_4;
	}

	public String getDomain_11() {
		return domain_11;
	}

	public void setDomain_11(String domain_11) {
		this.domain_11 = domain_11;
	}

	public String getDomain_12() {
		return domain_12;
	}

	public void setDomain_12(String domain_12) {
		this.domain_12 = domain_12;
	}

	public String getDomain_13() {
		return domain_13;
	}

	public void setDomain_13(String domain_13) {
		this.domain_13 = domain_13;
	}

	public String getDomain_14() {
		return domain_14;
	}

	public void setDomain_14(String domain_14) {
		this.domain_14 = domain_14;
	}

	public String getDomain_15() {
		return domain_15;
	}

	public void setDomain_15(String domain_15) {
		this.domain_15 = domain_15;
	}

	public String getDomain_22() {
		return domain_22;
	}

	public void setDomain_22(String domain_22) {
		this.domain_22 = domain_22;
	}

	public String getDomain_23() {
		return domain_23;
	}

	public void setDomain_23(String domain_23) {
		this.domain_23 = domain_23;
	}

	public String getDomain_25() {
		return domain_25;
	}

	public void setDomain_25(String domain_25) {
		this.domain_25 = domain_25;
	}

	public String getDomain_26() {
		return domain_26;
	}

	public void setDomain_26(String domain_26) {
		this.domain_26 = domain_26;
	}

	public String getDomain_32() {
		return domain_32;
	}

	public void setDomain_32(String domain_32) {
		this.domain_32 = domain_32;
	}

	public String getDomain_35() {
		return domain_35;
	}

	public void setDomain_35(String domain_35) {
		this.domain_35 = domain_35;
	}

	public String getDomain_36() {
		return domain_36;
	}

	public void setDomain_36(String domain_36) {
		this.domain_36 = domain_36;
	}

	public String getDomain_37() {
		return domain_37;
	}

	public void setDomain_37(String domain_37) {
		this.domain_37 = domain_37;
	}

	public String getDomain_38() {
		return domain_38;
	}

	public void setDomain_38(String domain_38) {
		this.domain_38 = domain_38;
	}

	public String getDomain_38_2() {
		return domain_38_2;
	}

	public void setDomain_38_2(String domain_38_2) {
		this.domain_38_2 = domain_38_2;
	}

	public String getDomain_39() {
		return domain_39;
	}

	public void setDomain_39(String domain_39) {
		this.domain_39 = domain_39;
	}

	public String getDomain_41() {
		return domain_41;
	}

	public void setDomain_41(String domain_41) {
		this.domain_41 = domain_41;
	}

	public String getDomain_42() {
		return domain_42;
	}

	public void setDomain_42(String domain_42) {
		this.domain_42 = domain_42;
	}

	public String getDomain_44() {
		return domain_44;
	}

	public void setDomain_44(String domain_44) {
		this.domain_44 = domain_44;
	}

	public String getDomain_48() {
		return domain_48;
	}

	public void setDomain_48(String domain_48) {
		this.domain_48 = domain_48;
	}

	public String getDomain_49() {
		return domain_49;
	}

	public void setDomain_49(String domain_49) {
		this.domain_49 = domain_49;
	}

	public String getDomain_52() {
		return domain_52;
	}

	public void setDomain_52(String domain_52) {
		this.domain_52 = domain_52;
	}

	public String getDomain_53() {
		return domain_53;
	}

	public void setDomain_53(String domain_53) {
		this.domain_53 = domain_53;
	}

	public String getDomain_54() {
		return domain_54;
	}

	public void setDomain_54(String domain_54) {
		this.domain_54 = domain_54;
	}

	public String getDomain_55() {
		return domain_55;
	}

	public void setDomain_55(String domain_55) {
		this.domain_55 = domain_55;
	}

	public String getDomain_58() {
		return domain_58;
	}

	public void setDomain_58(String domain_58) {
		this.domain_58 = domain_58;
	}

	public String getDomain_60() {
		return domain_60;
	}

	public void setDomain_60(String domain_60) {
		this.domain_60 = domain_60;
	}

	public String getDomain_60_1() {
		return domain_60_1;
	}

	public void setDomain_60_1(String domain_60_1) {
		this.domain_60_1 = domain_60_1;
	}

	public String getDomain_60_2() {
		return domain_60_2;
	}

	public void setDomain_60_2(String domain_60_2) {
		this.domain_60_2 = domain_60_2;
	}

	public String getDomain_60_3() {
		return domain_60_3;
	}

	public void setDomain_60_3(String domain_60_3) {
		this.domain_60_3 = domain_60_3;
	}

	public String getDomain_60_4() {
		return domain_60_4;
	}

	public void setDomain_60_4(String domain_60_4) {
		this.domain_60_4 = domain_60_4;
	}

	public String getDomain_60_5() {
		return domain_60_5;
	}

	public void setDomain_60_5(String domain_60_5) {
		this.domain_60_5 = domain_60_5;
	}

	public String getDomain_60_6() {
		return domain_60_6;
	}

	public void setDomain_60_6(String domain_60_6) {
		this.domain_60_6 = domain_60_6;
	}

	public String getDomain_60_7() {
		return domain_60_7;
	}

	public void setDomain_60_7(String domain_60_7) {
		this.domain_60_7 = domain_60_7;
	}

	public String getDomain_61() {
		return domain_61;
	}

	public void setDomain_61(String domain_61) {
		this.domain_61 = domain_61;
	}

	public String getDomain_61_1() {
		return domain_61_1;
	}

	public void setDomain_61_1(String domain_61_1) {
		this.domain_61_1 = domain_61_1;
	}

	public String getDomain_61_2() {
		return domain_61_2;
	}

	public void setDomain_61_2(String domain_61_2) {
		this.domain_61_2 = domain_61_2;
	}

	public String getDomain_61_3() {
		return domain_61_3;
	}

	public void setDomain_61_3(String domain_61_3) {
		this.domain_61_3 = domain_61_3;
	}

	public String getDomain_61_4() {
		return domain_61_4;
	}

	public void setDomain_61_4(String domain_61_4) {
		this.domain_61_4 = domain_61_4;
	}

	public String getDomain_61_5() {
		return domain_61_5;
	}

	public void setDomain_61_5(String domain_61_5) {
		this.domain_61_5 = domain_61_5;
	}

	public String getDomain_62() {
		return domain_62;
	}

	public void setDomain_62(String domain_62) {
		this.domain_62 = domain_62;
	}
	public String getDomain_63() {
		return domain_63;
	}
	public void setDomain_63(String domain_63) {
		this.domain_63 = domain_63;
	}
	public String getDomain_64() {
		return domain_64;
	}
	public void setDomain_64(String domain_64) {
		this.domain_64 = domain_64;
	}
	public int getCardType() {
		return cardType;
	}
	public void setCardType(int cardType) {
		this.cardType = cardType;
	}
	public int getTradeType() {
		return tradeType;
	}
	public void setTradeType(int tradeType) {
		this.tradeType = tradeType;
	}
	public String getTradeTime() {
		return tradeTime;
	}
	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}
	public int getRevoke() {
		return revoke;
	}
	public void setRevoke(int revoke) {
		this.revoke = revoke;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getDomain_55_2() {
		return domain_55_2;
	}

	public void setDomain_55_2(String domain_55_2) {
		this.domain_55_2 = domain_55_2;
	}
	
	public Object clone() {
		TradeInfo info = null;
        try {
        	info = (TradeInfo) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return info;
    }
	public String getDomain_62_2(){
		return domain_62_2;
	}
	public void setDomain_62_2(String domain_62_2) {
		this.domain_62_2 = domain_62_2;
	}

	public int getPwdType() {
		return pwdType;
	}

	public void setPwdType(int pwdType) {
		this.pwdType = pwdType;
	}

	public int getTradeKind() {
		return tradeKind;
	}

	public void setTradeKind(int tradeKind) {
		this.tradeKind = tradeKind;
	}

	public int getSendNum() {
		return sendNum;
	}

	public void setSendNum(int sendNum) {
		this.sendNum = sendNum;
	}

	public int getUploadSerialNo() {
		return uploadSerialNo;
	}

	public void setUploadSerialNo(int uploadSerialNo) {
		this.uploadSerialNo = uploadSerialNo;
	}
}