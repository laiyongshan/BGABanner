package com.dc.p92pos.aidl.db;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 卡数据bean
 * 
 * @author dynamicode
 * 
 */
public class UserInfo implements Parcelable {

	private String name = "";
	private String password = "";
	private int userAttr;        //用户类型，0-系统操作员 1-主管操作员 2-普通操作员
	
	public UserInfo(Parcel source) {
		this.name = source.readString();
		this.password = source.readString();
		this.userAttr = source.readInt();
	}
	
	public UserInfo(String name, String password){
		this.name = name;
		this.password = password;
	}
	
	public UserInfo(String name, String password, int userAttr){
		this.name = name;
		this.password = password;
		this.userAttr = userAttr;
	}
	
	public static Parcelable.Creator<UserInfo> getCreator() {
		return CREATOR;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.name);
		dest.writeString(this.password);
		dest.writeInt(this.userAttr);
	}
	
	public static final Parcelable.Creator<UserInfo> CREATOR = new Creator<UserInfo>() {
		@Override
		public UserInfo createFromParcel(Parcel source) {
			UserInfo userInfo = new UserInfo(source);
			return userInfo;
		}

		@Override
		public UserInfo[] newArray(int size) {
			return new UserInfo[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getUserAttr() {
		return userAttr;
	}

	public void setUserAttr(int userAttr) {
		this.userAttr = userAttr;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
