package com.dc.p92pos.aidl.db;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 通信类
 * 
 * @author dynamicode
 * 默认值设置  1-是 0-否   1-新 0-旧
 */
public class CommunicationParamInfo implements Parcelable {

	private String tpdu = "6005010000";     //TPDU
	private String zdyylx = "60";     		//POS终端应用类型
	private String sfybh = "1";				//是否预拨号
	private String jycssj = "60";			//交易超时时间
	private String jycbcs = "3";			//交易重拨次数
	
	private String wxhm = "";				//外线号码    管理电话号码
	private String zxjyhm_1 = "";			//中心交易号码1
	private String zxjyhm_2 = "";			//中心交易号码2
	private String zxjyhm_3 = "";			//中心交易号码3
	
	private String gprs_jrhm = "";			//GPRS接入号码
	private String gprs_japn_1_mc = "";		//GPRSAPN1名称
	private String gprs_zj_1_ipdz = "";		//GPRS主机1IP地址
	private String gprs_zj_1_dk = "";		//GPRS主机1端口
	private String gprs_zj_2_ipdz = "";		//GPRS主机2IP地址
	private String gprs_zj_2_dk = "";		//GPRS主机2端口
	private String gprs_yhmsz = "0";		//GPRS用户名设置
	private String gprs_yhm = "";			//GPRS用户名
	private String gprs_mm = "";			//GPRS密码
	
	private String cdma_jrhm = "";			//CDMA接入号码
	private String cdma_zj_1_ipdz = "";		//CDMA主机1IP地址
	private String cdma_zj_1_dk = "";		//CDMA主机1端口
	private String cdma_zj_2_ipdz = "";		//CDMA主机2IP地址
	private String cdma_zj_2_dk = "";		//CDMA主机2端口
	private String cdma_yjm = "";			//CDMA用户名
	private String cdma_mm = "";			//CDMA密码
	
	private String bjipdz = "";				//本机IP地址
	private String zwym = "";				//子网掩码
	private String wg = "";					//网关
	private String ytw_zj_1_ipdz = "100.100.100.116";	//以太网主机1IP地址
	private String ytw_zj_1_dk = "6908";			//以太网主机1端口
	private String ytw_zj_2_ipdz = "";				//以太网主机2IP地址
	private String ytw_zj_2_dk = "";				//以太网主机2端口
	
	private String posbtl = "";        	//pos拨通率
	
	private String jpzt = "1";          //键盘状态
	private String mmjpzt = "1";        //密码键盘状态
	private String tkqzt = "1";         //读卡器状态
	private String dyjzt = "1";         //打印机状态
	private String xsqzt = "1";         //显示器状态
	
	public CommunicationParamInfo(){}
	
	public CommunicationParamInfo(Parcel source) {
		this.tpdu = source.readString();
		this.zdyylx = source.readString();
		this.sfybh = source.readString();
		this.jycssj = source.readString();
		this.jycbcs = source.readString();
		
		this.wxhm = source.readString();
		this.zxjyhm_1 = source.readString();
		this.zxjyhm_2 = source.readString();
		this.zxjyhm_3 = source.readString();
		
		this.gprs_jrhm = source.readString();
		this.gprs_japn_1_mc = source.readString();
		this.gprs_zj_1_ipdz = source.readString();
		this.gprs_zj_1_dk = source.readString();
		this.gprs_zj_2_ipdz = source.readString();
		this.gprs_zj_2_dk = source.readString();
		this.gprs_yhmsz = source.readString();
		this.gprs_yhm = source.readString();
		this.gprs_mm = source.readString();
		
		this.cdma_jrhm = source.readString();
		this.cdma_zj_1_ipdz = source.readString();
		this.cdma_zj_1_dk = source.readString();
		this.cdma_zj_2_ipdz = source.readString();
		this.cdma_zj_2_dk = source.readString();
		this.cdma_yjm = source.readString();
		this.cdma_mm = source.readString();
		
		this.bjipdz = source.readString();
		this.zwym = source.readString();
		this.wg = source.readString();
		this.ytw_zj_1_ipdz = source.readString();
		this.ytw_zj_1_dk = source.readString();
		this.ytw_zj_2_ipdz = source.readString();
		this.ytw_zj_2_dk = source.readString();
		
		this.posbtl = source.readString();
		this.jpzt = source.readString();
		this.mmjpzt = source.readString();
		this.tkqzt = source.readString();
		this.dyjzt = source.readString();
		this.xsqzt = source.readString();
	}
	
	public static Parcelable.Creator<CommunicationParamInfo> getCreator() {
		return CREATOR;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.tpdu);
		dest.writeString(this.zdyylx);
		dest.writeString(this.sfybh);
		dest.writeString(this.jycssj);
		dest.writeString(this.jycbcs);

		dest.writeString(this.wxhm);
		dest.writeString(this.zxjyhm_1);
		dest.writeString(this.zxjyhm_2);
		dest.writeString(this.zxjyhm_3);

		dest.writeString(this.gprs_jrhm);
		dest.writeString(this.gprs_japn_1_mc);
		dest.writeString(this.gprs_zj_1_ipdz);
		dest.writeString(this.gprs_zj_1_dk);
		dest.writeString(this.gprs_zj_2_ipdz);
		dest.writeString(this.gprs_zj_2_dk);
		dest.writeString(this.gprs_yhmsz);
		dest.writeString(this.gprs_yhm);
		dest.writeString(this.gprs_mm);

		dest.writeString(this.cdma_jrhm);
		dest.writeString(this.cdma_zj_1_ipdz);
		dest.writeString(this.cdma_zj_1_dk);
		dest.writeString(this.cdma_zj_2_ipdz);
		dest.writeString(this.cdma_zj_2_dk);
		dest.writeString(this.cdma_yjm);
		dest.writeString(this.cdma_mm);

		dest.writeString(this.bjipdz);
		dest.writeString(this.zwym);
		dest.writeString(this.wg);
		dest.writeString(this.ytw_zj_1_ipdz);
		dest.writeString(this.ytw_zj_1_dk);
		dest.writeString(this.ytw_zj_2_ipdz);
		dest.writeString(this.ytw_zj_2_dk);

		dest.writeString(this.posbtl);
		dest.writeString(this.jpzt);
		dest.writeString(this.mmjpzt);
		dest.writeString(this.tkqzt);
		dest.writeString(this.dyjzt);
		dest.writeString(this.xsqzt);
	}
	
	public static final Parcelable.Creator<CommunicationParamInfo> CREATOR = new Creator<CommunicationParamInfo>() {
		@Override
		public CommunicationParamInfo createFromParcel(Parcel source) {
			CommunicationParamInfo userInfo = new CommunicationParamInfo(source);
			return userInfo;
		}

		@Override
		public CommunicationParamInfo[] newArray(int size) {
			return new CommunicationParamInfo[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}

	public String getTpdu() {
		return tpdu;
	}

	public void setTpdu(String tpdu) {
		this.tpdu = tpdu;
	}

	public String getZdyylx() {
		return zdyylx;
	}

	public void setZdyylx(String zdyylx) {
		this.zdyylx = zdyylx;
	}

	public String getSfybh() {
		return sfybh;
	}

	public void setSfybh(String sfybh) {
		this.sfybh = sfybh;
	}

	public String getJycssj() {
		return jycssj;
	}

	public void setJycssj(String jycssj) {
		this.jycssj = jycssj;
	}

	public String getJycbcs() {
		return jycbcs;
	}

	public void setJycbcs(String jycbcs) {
		this.jycbcs = jycbcs;
	}

	public String getWxhm() {
		return wxhm;
	}

	public void setWxhm(String wxhm) {
		this.wxhm = wxhm;
	}

	public String getZxjyhm_1() {
		return zxjyhm_1;
	}

	public void setZxjyhm_1(String zxjyhm_1) {
		this.zxjyhm_1 = zxjyhm_1;
	}

	public String getZxjyhm_2() {
		return zxjyhm_2;
	}

	public void setZxjyhm_2(String zxjyhm_2) {
		this.zxjyhm_2 = zxjyhm_2;
	}

	public String getZxjyhm_3() {
		return zxjyhm_3;
	}

	public void setZxjyhm_3(String zxjyhm_3) {
		this.zxjyhm_3 = zxjyhm_3;
	}

	public String getGprs_jrhm() {
		return gprs_jrhm;
	}

	public void setGprs_jrhm(String gprs_jrhm) {
		this.gprs_jrhm = gprs_jrhm;
	}

	public String getGprs_japn_1_mc() {
		return gprs_japn_1_mc;
	}

	public void setGprs_japn_1_mc(String gprs_japn_1_mc) {
		this.gprs_japn_1_mc = gprs_japn_1_mc;
	}

	public String getGprs_zj_1_ipdz() {
		return gprs_zj_1_ipdz;
	}

	public void setGprs_zj_1_ipdz(String gprs_zj_1_ipdz) {
		this.gprs_zj_1_ipdz = gprs_zj_1_ipdz;
	}

	public String getGprs_zj_1_dk() {
		return gprs_zj_1_dk;
	}

	public void setGprs_zj_1_dk(String gprs_zj_1_dk) {
		this.gprs_zj_1_dk = gprs_zj_1_dk;
	}

	public String getGprs_zj_2_ipdz() {
		return gprs_zj_2_ipdz;
	}

	public void setGprs_zj_2_ipdz(String gprs_zj_2_ipdz) {
		this.gprs_zj_2_ipdz = gprs_zj_2_ipdz;
	}

	public String getGprs_zj_2_dk() {
		return gprs_zj_2_dk;
	}

	public void setGprs_zj_2_dk(String gprs_zj_2_dk) {
		this.gprs_zj_2_dk = gprs_zj_2_dk;
	}

	public String getGprs_yhmsz() {
		return gprs_yhmsz;
	}

	public void setGprs_yhmsz(String gprs_yhmsz) {
		this.gprs_yhmsz = gprs_yhmsz;
	}

	public String getGprs_yhm() {
		return gprs_yhm;
	}

	public void setGprs_yhm(String gprs_yhm) {
		this.gprs_yhm = gprs_yhm;
	}

	public String getGprs_mm() {
		return gprs_mm;
	}

	public void setGprs_mm(String gprs_mm) {
		this.gprs_mm = gprs_mm;
	}

	public String getCdma_jrhm() {
		return cdma_jrhm;
	}

	public void setCdma_jrhm(String cdma_jrhm) {
		this.cdma_jrhm = cdma_jrhm;
	}

	public String getCdma_zj_1_ipdz() {
		return cdma_zj_1_ipdz;
	}

	public void setCdma_zj_1_ipdz(String cdma_zj_1_ipdz) {
		this.cdma_zj_1_ipdz = cdma_zj_1_ipdz;
	}

	public String getCdma_zj_1_dk() {
		return cdma_zj_1_dk;
	}

	public void setCdma_zj_1_dk(String cdma_zj_1_dk) {
		this.cdma_zj_1_dk = cdma_zj_1_dk;
	}

	public String getCdma_zj_2_ipdz() {
		return cdma_zj_2_ipdz;
	}

	public void setCdma_zj_2_ipdz(String cdma_zj_2_ipdz) {
		this.cdma_zj_2_ipdz = cdma_zj_2_ipdz;
	}

	public String getCdma_zj_2_dk() {
		return cdma_zj_2_dk;
	}

	public void setCdma_zj_2_dk(String cdma_zj_2_dk) {
		this.cdma_zj_2_dk = cdma_zj_2_dk;
	}

	public String getCdma_yjm() {
		return cdma_yjm;
	}

	public void setCdma_yjm(String cdma_yjm) {
		this.cdma_yjm = cdma_yjm;
	}

	public String getCdma_mm() {
		return cdma_mm;
	}

	public void setCdma_mm(String cdma_mm) {
		this.cdma_mm = cdma_mm;
	}

	public String getBjipdz() {
		return bjipdz;
	}

	public void setBjipdz(String bjipdz) {
		this.bjipdz = bjipdz;
	}

	public String getZwym() {
		return zwym;
	}

	public void setZwym(String zwym) {
		this.zwym = zwym;
	}

	public String getWg() {
		return wg;
	}

	public void setWg(String wg) {
		this.wg = wg;
	}

	public String getYtw_zj_1_ipdz() {
		return ytw_zj_1_ipdz;
	}

	public void setYtw_zj_1_ipdz(String ytw_zj_1_ipdz) {
		this.ytw_zj_1_ipdz = ytw_zj_1_ipdz;
	}

	public String getYtw_zj_1_dk() {
		return ytw_zj_1_dk;
	}

	public void setYtw_zj_1_dk(String ytw_zj_1_dk) {
		this.ytw_zj_1_dk = ytw_zj_1_dk;
	}

	public String getYtw_zj_2_ipdz() {
		return ytw_zj_2_ipdz;
	}

	public void setYtw_zj_2_ipdz(String ytw_zj_2_ipdz) {
		this.ytw_zj_2_ipdz = ytw_zj_2_ipdz;
	}

	public String getYtw_zj_2_dk() {
		return ytw_zj_2_dk;
	}

	public void setYtw_zj_2_dk(String ytw_zj_2_dk) {
		this.ytw_zj_2_dk = ytw_zj_2_dk;
	}

	public String getPosbtl() {
		return posbtl;
	}

	public void setPosbtl(String posbtl) {
		this.posbtl = posbtl;
	}

	public String getJpzt() {
		return jpzt;
	}

	public void setJpzt(String jpzt) {
		this.jpzt = jpzt;
	}

	public String getMmjpzt() {
		return mmjpzt;
	}

	public void setMmjpzt(String mmjpzt) {
		this.mmjpzt = mmjpzt;
	}

	public String getTkqzt() {
		return tkqzt;
	}

	public void setTkqzt(String tkqzt) {
		this.tkqzt = tkqzt;
	}

	public String getDyjzt() {
		return dyjzt;
	}

	public void setDyjzt(String dyjzt) {
		this.dyjzt = dyjzt;
	}

	public String getXsqzt() {
		return xsqzt;
	}

	public void setXsqzt(String xsqzt) {
		this.xsqzt = xsqzt;
	}
}