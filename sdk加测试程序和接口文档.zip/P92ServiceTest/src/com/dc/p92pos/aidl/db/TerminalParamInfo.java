package com.dc.p92pos.aidl.db;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 卡数据bean
 * 
 * @author dynamicode
 * 默认值设置  1-是 0-否   1-新 0-旧
 */
public class TerminalParamInfo implements Parcelable {

	private String shbh = "123456789012345";     	//商户编号
	private String zdbh = "12345678";				//终端编号
	private String aqmm = "123456";					//安全密码
	private String shmc = "";						//商户名称
	private String dqnf = "2016";					//当前年份
	private String lsh = "000001";					//流水号
	private String pch = "000001";					//批次号
	private String zdthje = "10000.00";				//最大退货金额
	private String jsdymxsz = "0";					//结算打印明细设置
	private String ywsz = "1";						//英文设置
	private String qgdsz = "1";						//签购单设置
	private String qgdttxz = "1";					//签购单抬头选择
	private String qgdttsz = "银联POS";				//签购单抬头设置
	private String mrjysz = "1";					//默认交易设置   1-消费/0-预授权
	private String xfcxsfsk = "0";					//消费撤销是否刷卡
	private String xfcxsfsm = "0";					//消费撤销是否输密
	private String ysqwccxsfsk = "0";				//预授权完成撤销是否刷卡
	private String ysqwccxsfsm = "1";				//预授权完成撤销是否输密
	private String ysqcxsfsm = "1";					//预授权撤销是否输密
	private String ysqwcsfsm = "1";					//预授权完成（请求）是否输密
	private String sfqygm = "0";					//是否启用国密
	private String sfzcxeysq = "1";					//是否支持小额预授权

	public TerminalParamInfo(){}
	
	public TerminalParamInfo(Parcel source) {
		this.shbh = source.readString();
		this.zdbh = source.readString();
		this.aqmm = source.readString();
		this.shmc = source.readString();
		this.dqnf = source.readString();
		this.lsh = source.readString();
		this.pch = source.readString();
		this.zdthje = source.readString();
		this.jsdymxsz = source.readString();
		this.ywsz = source.readString();
		this.qgdsz = source.readString();
		this.qgdttsz = source.readString();
		this.mrjysz = source.readString();
		this.xfcxsfsk = source.readString();
		this.xfcxsfsm = source.readString();
		this.ysqwccxsfsk = source.readString();
		this.ysqwccxsfsm = source.readString();
		this.ysqcxsfsm = source.readString();
		this.ysqwcsfsm = source.readString();
		this.qgdttxz = source.readString();
		this.sfqygm = source.readString();
		this.sfzcxeysq = source.readString();
	}
	
	public TerminalParamInfo(String shbh, String zdbh, String aqmm,
			String shmc, String dqnf, String lsh, String pch, String zdthje,
			String jsdymxsz, String ywsz, String qgdsz, String qgdttsz,
			String mrjysz, String xfcxsfsk, String xfcxsfsm,
			String ysqwccxsfsk, String ysqwccxsfsm, String ysqcxsfsm,
			String ysqwcsfsm,String qgdttxz,String fjjytdkg,String sfqygm,String sfzcxeysq) {
		super();
		this.shbh = shbh;
		this.zdbh = zdbh;
		this.aqmm = aqmm;
		this.shmc = shmc;
		this.dqnf = dqnf;
		this.lsh = lsh;
		this.pch = pch;
		this.zdthje = zdthje;
		this.jsdymxsz = jsdymxsz;
		this.ywsz = ywsz;
		this.qgdsz = qgdsz;
		this.qgdttsz = qgdttsz;
		this.mrjysz = mrjysz;
		this.xfcxsfsk = xfcxsfsk;
		this.xfcxsfsm = xfcxsfsm;
		this.ysqwccxsfsk = ysqwccxsfsk;
		this.ysqwccxsfsm = ysqwccxsfsm;
		this.ysqcxsfsm = ysqcxsfsm;
		this.ysqwcsfsm = ysqwcsfsm;
		this.qgdttxz = qgdttxz;
		this.sfqygm = sfqygm;
		this.sfzcxeysq = sfzcxeysq;
	}


	public static Parcelable.Creator<TerminalParamInfo> getCreator() {
		return CREATOR;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.shbh);
		dest.writeString(this.zdbh);
		dest.writeString(this.aqmm);
		dest.writeString(this.shmc);
		dest.writeString(this.dqnf);
		dest.writeString(this.lsh);
		dest.writeString(this.pch);
		dest.writeString(this.zdthje);
		dest.writeString(this.jsdymxsz);
		dest.writeString(this.ywsz);
		dest.writeString(this.qgdsz);
		dest.writeString(this.qgdttsz);
		dest.writeString(this.mrjysz);
		dest.writeString(this.xfcxsfsk);
		dest.writeString(this.xfcxsfsm);
		dest.writeString(this.ysqwccxsfsk);
		dest.writeString(this.ysqwccxsfsm);
		dest.writeString(this.ysqcxsfsm);
		dest.writeString(this.ysqwcsfsm);
		dest.writeString(this.qgdttxz);
		dest.writeString(this.sfqygm);
		dest.writeString(this.sfzcxeysq);
	}
	
	public String getQgdttxz() {
		return qgdttxz;
	}

	public void setQgdttxz(String qgdttxz) {
		this.qgdttxz = qgdttxz;
	}

	public static final Parcelable.Creator<TerminalParamInfo> CREATOR = new Creator<TerminalParamInfo>() {
		@Override
		public TerminalParamInfo createFromParcel(Parcel source) {
			TerminalParamInfo userInfo = new TerminalParamInfo(source);
			return userInfo;
		}

		@Override
		public TerminalParamInfo[] newArray(int size) {
			return new TerminalParamInfo[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}

	public String getShbh() {
		return shbh;
	}

	public void setShbh(String shbh) {
		this.shbh = shbh;
	}

	public String getZdbh() {
		return zdbh;
	}

	public void setZdbh(String zdbh) {
		this.zdbh = zdbh;
	}

	public String getAqmm() {
		return aqmm;
	}

	public void setAqmm(String aqmm) {
		this.aqmm = aqmm;
	}

	public String getShmc() {
		return shmc;
	}

	public void setShmc(String shmc) {
		this.shmc = shmc;
	}

	public String getDqnf() {
		return dqnf;
	}

	public void setDqnf(String dqnf) {
		this.dqnf = dqnf;
	}

	public String getLsh() {
		return lsh;
	}

	public String getLsh_add() {
		int nLis = Integer.parseInt(lsh) + 1;
		if (nLis > 999999) {
			lsh = "000001";
		} else {
			lsh = String.format("%06d", nLis);
		}
		return lsh;
	}

	public void setLsh(String lsh) {
		this.lsh = lsh;
	}

	public String getPch() {
		return pch;
	}

	public String getPch_add() {
		int nPch = Integer.parseInt(pch) + 1;
		if (nPch > 999999) {
			pch = "000001";
		} else {
			pch = String.format("%06d", nPch);
		}
		return pch;
	}

	public void setPch(String pch) {
		this.pch = pch;
	}

	public String getZdthje() {
		return zdthje;
	}

	public void setZdthje(String zdthje) {
		this.zdthje = zdthje;
	}

	public String getJsdymxsz() {
		return jsdymxsz;
	}

	public void setJsdymxsz(String jsdymxsz) {
		this.jsdymxsz = jsdymxsz;
	}

	public String getYwsz() {
		return ywsz;
	}

	public void setYwsz(String ywsz) {
		this.ywsz = ywsz;
	}

	public String getQgdsz() {
		return qgdsz;
	}

	public void setQgdsz(String qgdsz) {
		this.qgdsz = qgdsz;
	}

	public String getQgdttsz() {
		return qgdttsz;
	}

	public void setQgdttsz(String qgdttsz) {
		this.qgdttsz = qgdttsz;
	}

	public String getMrjysz() {
		return mrjysz;
	}

	public void setMrjysz(String mrjysz) {
		this.mrjysz = mrjysz;
	}

	public String getXfcxsfsk() {
		return xfcxsfsk;
	}

	public void setXfcxsfsk(String xfcxsfsk) {
		this.xfcxsfsk = xfcxsfsk;
	}

	public String getXfcxsfsm() {
		return xfcxsfsm;
	}

	public void setXfcxsfsm(String xfcxsfsm) {
		this.xfcxsfsm = xfcxsfsm;
	}

	public String getYsqwccxsfsk() {
		return ysqwccxsfsk;
	}

	public void setYsqwccxsfsk(String ysqwccxsfsk) {
		this.ysqwccxsfsk = ysqwccxsfsk;
	}

	public String getYsqwccxsfsm() {
		return ysqwccxsfsm;
	}

	public void setYsqwccxsfsm(String ysqwccxsfsm) {
		this.ysqwccxsfsm = ysqwccxsfsm;
	}

	public String getYsqcxsfsm() {
		return ysqcxsfsm;
	}

	public void setYsqcxsfsm(String ysqcxsfsm) {
		this.ysqcxsfsm = ysqcxsfsm;
	}

	public String getYsqwcsfsm() {
		return ysqwcsfsm;
	}

	public void setYsqwcsfsm(String ysqwcsfsm) {
		this.ysqwcsfsm = ysqwcsfsm;
	}
	
	public String getSfqygm() {
		return sfqygm;
	}

	public void setSfqygm(String sfqygm) {
		this.sfqygm = sfqygm;
	}
	
	public String getSfzcxeysq() {
		return sfzcxeysq;
	}

	public void setSfzcxeysq(String sfzcxeysq) {
		this.sfzcxeysq = sfzcxeysq;
	}
}
