package com.dc.p92pos.aidl.db;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 终端非接业务参数信息
 * 
 * @author 
 * 默认值设置  1-是 0-否   1-新 0-旧
 */
public class RFParamInfo implements Parcelable {

	private String fjjytdkg = "1";					//非接交易通道开关
	private String skdbcsclsj = "10";				//闪卡当笔重刷处理时间
	private String skjlkclsj = "60";				//闪卡记录可处理时间
	private String skbczdbs = "3";					//闪卡保存最大笔数
	private String fjksywmmxe = "300.00";			//非接快速业务（QPS）免密限额
	private String fjksywbs = "0";					//非接快速业务标识
	private String binabs = "0";					//BIN表A标识
	private String binbbs = "0";					//BIN表B标识
	private String cdcvmbs = "0";					//CDCVM标识
	private String mqxe = "300.00";					//免签限额
	private String mqbs = "0";						//免签标识
	
	public RFParamInfo(){}
	
	public RFParamInfo(Parcel source) {
		this.fjjytdkg = source.readString();
		this.skdbcsclsj = source.readString();
		this.skjlkclsj = source.readString();
		this.fjksywmmxe = source.readString();
		this.fjksywbs = source.readString();
		this.binabs = source.readString();
		this.binbbs = source.readString();
		this.cdcvmbs = source.readString();
		this.mqxe = source.readString();
		this.mqbs = source.readString();
		this.skbczdbs = source.readString();
	}
	
	public String getSkbczdbs() {
		return skbczdbs;
	}

	public void setSkbczdbs(String skbczdbs) {
		this.skbczdbs = skbczdbs;
	}

	public RFParamInfo(String fjjytdkg,String skdbcsclsj,String skjlkclsj,String fjksywmmxe,
			String fjksywbs,String binabs,String binbbs,String cdcvmbs,String mqxe,String mqbs, String skbczdbs) {
		super();
		this.fjjytdkg = fjjytdkg;
		this.skdbcsclsj = skdbcsclsj;
		this.skjlkclsj = skjlkclsj;
		this.fjksywmmxe = fjksywmmxe;
		this.fjksywbs = fjksywbs;
		this.binabs = binabs;
		this.binbbs = binbbs;
		this.cdcvmbs = cdcvmbs;
		this.mqxe = mqxe;
		this.mqbs = mqbs;
		this.skbczdbs = skbczdbs;
	}

	public static Parcelable.Creator<RFParamInfo> getCreator() {
		return CREATOR;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.fjjytdkg);
		dest.writeString(this.skdbcsclsj);
		dest.writeString(this.skjlkclsj);
		dest.writeString(this.fjksywmmxe);
		dest.writeString(this.fjksywbs);
		dest.writeString(this.binabs);
		dest.writeString(this.binbbs);
		dest.writeString(this.cdcvmbs);
		dest.writeString(this.mqxe);
		dest.writeString(this.mqbs);
		dest.writeString(this.skbczdbs);
	}

	public static final Parcelable.Creator<RFParamInfo> CREATOR = new Creator<RFParamInfo>() {
		@Override
		public RFParamInfo createFromParcel(Parcel source) {
			RFParamInfo userInfo = new RFParamInfo(source);
			return userInfo;
		}

		@Override
		public RFParamInfo[] newArray(int size) {
			return new RFParamInfo[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}
	
	public String getFjjytdkg() {
		return fjjytdkg;
	}

	public void setFjjytdkg(String fjjytdkg) {
		this.fjjytdkg = fjjytdkg;
	}

	public String getSkdbcsclsj() {
		return skdbcsclsj;
	}

	public void setSkdbcsclsj(String skdbcsclsj) {
		this.skdbcsclsj = skdbcsclsj;
	}

	public String getSkjlkclsj() {
		return skjlkclsj;
	}

	public void setSkjlkclsj(String skjlkclsj) {
		this.skjlkclsj = skjlkclsj;
	}

	public String getFjksywmmxe() {
		return fjksywmmxe;
	}

	public void setFjksywmmxe(String fjksywmmxe) {
		this.fjksywmmxe = fjksywmmxe;
	}

	public String getFjksywbs() {
		return fjksywbs;
	}

	public void setFjksywbs(String fjksywbs) {
		this.fjksywbs = fjksywbs;
	}

	public String getBinabs() {
		return binabs;
	}

	public void setBinabs(String binabs) {
		this.binabs = binabs;
	}

	public String getBinbbs() {
		return binbbs;
	}

	public void setBinbbs(String binbbs) {
		this.binbbs = binbbs;
	}

	public String getCdcvmbs() {
		return cdcvmbs;
	}

	public void setCdcvmbs(String cdcvmbs) {
		this.cdcvmbs = cdcvmbs;
	}

	public String getMqxe() {
		return mqxe;
	}

	public void setMqxe(String mqxe) {
		this.mqxe = mqxe;
	}

	public String getMqbs() {
		return mqbs;
	}

	public void setMqbs(String mqbs) {
		this.mqbs = mqbs;
	}
}
