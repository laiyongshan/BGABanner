package com.dc.p92pos.aidl.db;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 交易类
 * 
 * @author 
 * 默认值设置  1-是 0-否   1-新 0-旧
 */
public class TradeParamInfo implements Parcelable {

	private String cx = "1";			//1、查询
	private String ysq = "1";			//2、预授权
	private String ysqcx = "1";			//3、预授权撤销
	private String ysqwcqq = "1";		//4、预授权完成请求
	private String ysqwccx = "1";		//5、预授权完成撤销
	private String xf = "1";     		//6、消费
	private String xfcx = "1";     		//7、消费撤销
	private String th = "1";			//8、退货
	private String lxjs = "1";			//9、离线结算
	private String jstz = "1";			//10、结算调整
	private String ysqwctz = "1";		//11、预授权完成通知
	private String jbcljgtz = "1";		//12、基于 PBOC 借/贷记标准 IC 卡脚本处理结果通知
	private String dzxjxf = "1";		//13、电子现金脱机消费
	private String dzqbqc = "1";		//15、基于 PBOC 电子钱包的圈存类交易/冲正
	private String fqfkjy = "1";		//16、分期付款交易/冲正
	private String fqfkjycx = "1";		//17、分期付款交易撤销/冲正
	private String jfxf = "1";			//18、积分消费
	private String jfxfcx = "1";		//19、积分消费撤销
	private String qcl = "1";			//20、基于 PBOC 借贷记的圈存类交易/冲正
	private String yyxf = "1";			//21、预约消费
	private String yyxfcx = "1";		//22、预约消费撤销
	private String dgxf = "1";			//23、订购消费
	private String dgxfcx = "1";		//24、订购消费撤销
	private String ctkxjcz = "1";		//25、磁条卡现金充值
	
	private String jshzdqt = "1";		//结算后自动签退
	private String cfcs = "3";			//重发次数
	private String dyzs = "1";			//打印张数
	private String zdjybs = "500";		//最大交易笔数
	private String zdmysy = "0";		//终端秘钥索引
	private String xgglymm = "";		//修改管理员密码
	private String xgaqmm = "";			//修改安全密码
	private String xcjyls = "1";		//消除交易流水
	private String csdy = "";			//参数打印
	private String kjsz = "";			//快捷设置
	
	private String sfzcxf = "0";        //是否支持小费
	private String xfbfb = "00";        //小费百分比
	private String sfzcsgsrkh = "1";    //是否支持手工输入卡号
	private String mzzdssbs = "10";     //满足自动上送的累计笔数
	
	public TradeParamInfo(){}
	
	public TradeParamInfo(Parcel source) {
		this.xfcx = source.readString();
		this.cx = source.readString();
		this.ysq = source.readString();
		this.lxjs = source.readString();
		this.jstz = source.readString();
		this.th = source.readString();
		this.ysqcx = source.readString();
		this.ysqwcqq = source.readString();
		this.ysqwccx = source.readString();
		this.qcl = source.readString();
		this.ysqwctz = source.readString();
		this.dzxjxf = source.readString();
		this.fqfkjy = source.readString();
		this.jfxf = source.readString();
		this.yyxf = source.readString();
		this.dgxf = source.readString();
		this.ctkxjcz = source.readString();
		this.jshzdqt = source.readString();
		this.cfcs = source.readString();
		this.dyzs = source.readString();
		this.zdjybs = source.readString();
		this.zdmysy = source.readString();
		this.xgglymm = source.readString();
		this.xgaqmm = source.readString();
		this.xcjyls = source.readString();
		this.csdy = source.readString();
		this.kjsz = source.readString();
		this.xf = source.readString();
		this.jbcljgtz = source.readString();
		this.dzqbqc = source.readString();
		this.fqfkjycx = source.readString();
		this.jfxfcx = source.readString();
		this.yyxfcx = source.readString();
		this.dgxfcx = source.readString();
		this.sfzcxf = source.readString();
		this.xfbfb = source.readString();
		this.sfzcsgsrkh = source.readString();		
		this.mzzdssbs = source.readString();
	}
	
	public static Parcelable.Creator<TradeParamInfo> getCreator() {
		return CREATOR;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.xfcx);
		dest.writeString(this.cx);
		dest.writeString(this.ysq);
		dest.writeString(this.lxjs);
		dest.writeString(this.jstz);
		dest.writeString(this.th);
		dest.writeString(this.ysqcx);
		dest.writeString(this.ysqwcqq);
		dest.writeString(this.ysqwccx);
		dest.writeString(this.qcl);
		dest.writeString(this.ysqwctz);
		dest.writeString(this.dzxjxf);
		dest.writeString(this.fqfkjy);
		dest.writeString(this.jfxf);
		dest.writeString(this.yyxf);
		dest.writeString(this.dgxf);
		dest.writeString(this.ctkxjcz);
		dest.writeString(this.jshzdqt);
		dest.writeString(this.cfcs);
		dest.writeString(this.dyzs);
		dest.writeString(this.zdjybs);
		dest.writeString(this.zdmysy);
		dest.writeString(this.xgglymm);
		dest.writeString(this.xgaqmm);
		dest.writeString(this.xcjyls);
		dest.writeString(this.csdy);
		dest.writeString(this.kjsz);
		dest.writeString(this.xf);
		dest.writeString(this.jbcljgtz);
		dest.writeString(this.dzqbqc);
		dest.writeString(this.fqfkjycx);
		dest.writeString(this.jfxfcx);
		dest.writeString(this.yyxfcx);
		dest.writeString(this.dgxfcx);
		dest.writeString(this.sfzcxf);
		dest.writeString(this.xfbfb);
		dest.writeString(this.sfzcsgsrkh);
		dest.writeString(this.mzzdssbs);
	}
	
	public static final Parcelable.Creator<TradeParamInfo> CREATOR = new Creator<TradeParamInfo>() {
		@Override
		public TradeParamInfo createFromParcel(Parcel source) {
			TradeParamInfo userInfo = new TradeParamInfo(source);
			return userInfo;
		}

		@Override
		public TradeParamInfo[] newArray(int size) {
			return new TradeParamInfo[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}

	public String getXfcx() {
		return xfcx;
	}

	public void setXfcx(String xfcx) {
		this.xfcx = xfcx;
	}

	public String getCx() {
		return cx;
	}

	public void setCx(String cx) {
		this.cx = cx;
	}

	public String getYsq() {
		return ysq;
	}

	public void setYsq(String ysq) {
		this.ysq = ysq;
	}

	public String getLxjs() {
		return lxjs;
	}

	public void setLxjs(String lxjs) {
		this.lxjs = lxjs;
	}

	public String getJstz() {
		return jstz;
	}

	public void setJstz(String jstz) {
		this.jstz = jstz;
	}

	public String getTh() {
		return th;
	}

	public void setTh(String th) {
		this.th = th;
	}

	public String getYsqcx() {
		return ysqcx;
	}

	public void setYsqcx(String ysqcx) {
		this.ysqcx = ysqcx;
	}

	public String getYsqwcqq() {
		return ysqwcqq;
	}

	public void setYsqwcqq(String ysqwcqq) {
		this.ysqwcqq = ysqwcqq;
	}

	public String getYsqwccx() {
		return ysqwccx;
	}

	public void setYsqwccx(String ysqwccx) {
		this.ysqwccx = ysqwccx;
	}

	public String getQcl() {
		return qcl;
	}

	public void setQcl(String qcl) {
		this.qcl = qcl;
	}

	public String getYsqwctz() {
		return ysqwctz;
	}

	public void setYsqwctz(String ysqwctz) {
		this.ysqwctz = ysqwctz;
	}

	public String getDzxjxf() {
		return dzxjxf;
	}

	public void setDzxjxf(String dzxjxf) {
		this.dzxjxf = dzxjxf;
	}

	public String getFqfkjy() {
		return fqfkjy;
	}

	public void setFqfkjy(String fqfkjy) {
		this.fqfkjy = fqfkjy;
	}

	public String getJfxf() {
		return jfxf;
	}

	public void setJfxf(String jfxf) {
		this.jfxf = jfxf;
	}

	public String getYyxf() {
		return yyxf;
	}

	public void setYyxf(String yyxf) {
		this.yyxf = yyxf;
	}

	public String getDgxf() {
		return dgxf;
	}

	public void setDgxf(String dgxf) {
		this.dgxf = dgxf;
	}

	public String getCtkxjcz() {
		return ctkxjcz;
	}

	public void setCtkxjcz(String ctkxjcz) {
		this.ctkxjcz = ctkxjcz;
	}

	public String getJshzdqt() {
		return jshzdqt;
	}

	public void setJshzdqt(String jshzdqt) {
		this.jshzdqt = jshzdqt;
	}

	public String getCfcs() {
		return cfcs;
	}

	public void setCfcs(String cfcs) {
		this.cfcs = cfcs;
	}

	public String getDyzs() {
		return dyzs;
	}

	public void setDyzs(String dyzs) {
		this.dyzs = dyzs;
	}

	public String getZdjybs() {
		return zdjybs;
	}

	public void setZdjybs(String zdjybs) {
		this.zdjybs = zdjybs;
	}

	public String getZdmysy() {
		return zdmysy;
	}

	public void setZdmysy(String zdmysy) {
		this.zdmysy = zdmysy;
	}

	public String getXgglymm() {
		return xgglymm;
	}

	public void setXgglymm(String xgglymm) {
		this.xgglymm = xgglymm;
	}

	public String getXgaqmm() {
		return xgaqmm;
	}

	public void setXgaqmm(String xgaqmm) {
		this.xgaqmm = xgaqmm;
	}

	public String getXcjyls() {
		return xcjyls;
	}

	public void setXcjyls(String xcjyls) {
		this.xcjyls = xcjyls;
	}

	public String getCsdy() {
		return csdy;
	}

	public void setCsdy(String csdy) {
		this.csdy = csdy;
	}

	public String getKjsz() {
		return kjsz;
	}

	public void setKjsz(String kjsz) {
		this.kjsz = kjsz;
	}

	public String getSfzcxf() {
		return sfzcxf;
	}

	public void setSfzcxf(String sfzcxf) {
		this.sfzcxf = sfzcxf;
	}

	public String getXfbfb() {
		return xfbfb;
	}

	public void setXfbfb(String xfbfb) {
		this.xfbfb = xfbfb;
	}

	public String getSfzcsgsrkh() {
		return sfzcsgsrkh;
	}

	public void setSfzcsgsrkh(String sfzcsgsrkh) {
		this.sfzcsgsrkh = sfzcsgsrkh;
	}

	public String getMzzdssbs() {
		return mzzdssbs;
	}

	public void setMzzdssbs(String mzzdssbs) {
		this.mzzdssbs = mzzdssbs;
	}

	public String getXf() {
		return xf;
	}

	public void setXf(String xf) {
		this.xf = xf;
	}

	public String getJbcljgtz() {
		return jbcljgtz;
	}

	public void setJbcljgtz(String jbcljgtz) {
		this.jbcljgtz = jbcljgtz;
	}

	public String getDzqbqc() {
		return dzqbqc;
	}

	public void setDzqbqc(String dzqbqc) {
		this.dzqbqc = dzqbqc;
	}

	public String getFqfkjycx() {
		return fqfkjycx;
	}

	public void setFqfkjycx(String fqfkjycx) {
		this.fqfkjycx = fqfkjycx;
	}

	public String getJfxfcx() {
		return jfxfcx;
	}

	public void setJfxfcx(String jfxfcx) {
		this.jfxfcx = jfxfcx;
	}

	public String getYyxfcx() {
		return yyxfcx;
	}

	public void setYyxfcx(String yyxfcx) {
		this.yyxfcx = yyxfcx;
	}

	public String getDgxfcx() {
		return dgxfcx;
	}

	public void setDgxfcx(String dgxfcx) {
		this.dgxfcx = dgxfcx;
	}
}
