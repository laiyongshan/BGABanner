package com.dc.p92pos.aidl.db;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 黑名单数据
 */
public class BinParams implements Parcelable {

	private String type = "";
	private String len = "";
	private String bin = "";
	
	public BinParams(Parcel source) {
		this.type = source.readString();
		this.len = source.readString();
		this.bin = source.readString();
	}
	
	public BinParams(String type, String len, String bin){
		this.type = type;
		this.len = len;
		this.bin = bin;
	}
	
	public static Parcelable.Creator<BinParams> getCreator() {
		return CREATOR;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.type);
		dest.writeString(this.len);
		dest.writeString(this.bin);
	}
	
	public static final Parcelable.Creator<BinParams> CREATOR = new Creator<BinParams>() {
		@Override
		public BinParams createFromParcel(Parcel source) {
			BinParams userInfo = new BinParams(source);
			return userInfo;
		}

		@Override
		public BinParams[] newArray(int size) {
			return new BinParams[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLen() {
		return len;
	}

	public void setLen(String len) {
		this.len = len;
	}

	public String getBin() {
		return bin;
	}

	public void setBin(String bin) {
		this.bin = bin;
	}

}