package com.dc.p92pos.aidl.emv;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 卡数据bean
 * 
 * @author dynamicode
 * 
 */
public class CardInfo implements Parcelable {

	private String cardno = null;
	private String currency1 = null;
	private String currency2 = null;
	private String strAid = null;
	private String cdcvm = null;

	public CardInfo(Parcel source) {
		this.cardno = source.readString();
		this.currency1 = source.readString();
		this.currency2 = source.readString();
		this.strAid = source.readString();
		this.cdcvm = source.readString();
	}
	
	public CardInfo(String cardno){
		this.cardno = cardno;
	}
	
	public CardInfo(String cardno, String currency1, String currency2, String aid, String cdcvm){
		this.cardno = cardno==null?"":cardno;
		this.currency1 = currency1==null?"":currency1;
		this.currency2 = currency2==null?"":currency2;
		this.strAid = aid==null?"":aid;
		this.cdcvm = cdcvm==null?"":cdcvm;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	public String getCardno() {
		return cardno;
	}

	public void setCardno(String cardno) {
		this.cardno = cardno;
	}

	public String getCurrency1() {
		return currency1;
	}

	public void setCurrency1(String currency1) {
		this.currency1 = currency1;
	}

	public String getCurrency2() {
		return currency2;
	}

	public void setCurrency2(String currency2) {
		this.currency2 = currency2;
	}

	public String getAid() {
		return strAid;
	}

	public void setAid(String aid) {
		this.strAid = aid;
	}
	
	public String getCdcvm() {
		return cdcvm;
	}

	public void setCdcvm(String cdcvm) {
		this.cdcvm = cdcvm;
	}

	public static Parcelable.Creator<CardInfo> getCreator() {
		return CREATOR;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.cardno);
		dest.writeString(this.currency1);
		dest.writeString(this.currency2);
		dest.writeString(this.strAid);
		dest.writeString(this.cdcvm);
	}

	public static final Parcelable.Creator<CardInfo> CREATOR = new Creator<CardInfo>() {

		@Override
		public CardInfo createFromParcel(Parcel source) {
			CardInfo cardno = new CardInfo(source);
			return cardno;
		}

		@Override
		public CardInfo[] newArray(int size) {
			return new CardInfo[size];
		}
	};
}
