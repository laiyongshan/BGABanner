package com.dc.p92pos.aidl.emv;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * IC卡交易日志
 * 
 * @author dynamicode
 * 
 */
public class PCardTradeLog implements Parcelable {
	/** 交易日期 */
	private String tradeDate;
	/**交易时间*/
	private String tradeTime;
	/** 授权金额 */
	private String amt;
	/** 其他金额 */
	private String otheramt;
	/** 国家代码 */
	private String countryCode;
	/** 货币代码 */
	private String moneyCode;
	/** 商户名称 */
	private String merchantName;
	/** 交易类型 */
	private int tradetype;
	/** 应用交易计数器 */
	private byte[] appTradeCount = new byte[2];

	public PCardTradeLog() {

	}
	
	public PCardTradeLog(String tradeDate, String tradeTime, String amt,
			String otheramt, String countryCode, String moneyCode,
			String merchantName, int tradetype, byte[] appTradeCount) {
		super();
		this.tradeDate = tradeDate;
		this.tradeTime = tradeTime;
		this.amt = amt;
		this.otheramt = otheramt;
		this.countryCode = countryCode;
		this.moneyCode = moneyCode;
		this.merchantName = merchantName;
		this.tradetype = tradetype;
		this.appTradeCount = appTradeCount;
	}




	private PCardTradeLog(Parcel source) {

		this.tradeDate = source.readString();
		this.tradeTime = source.readString();
		this.amt = source.readString();
		this.otheramt = source.readString();
		this.countryCode = source.readString();
		this.moneyCode = source.readString();
		this.merchantName = source.readString();
		this.tradetype = source.readInt();
		if (this.appTradeCount == null) {
			this.appTradeCount = new byte[2];
		}
		source.readByteArray(this.appTradeCount);

	}

	public static final Parcelable.Creator<PCardTradeLog> CREATOR = new Parcelable.Creator<PCardTradeLog>() {

		@Override
		public PCardTradeLog createFromParcel(Parcel source) {
			return new PCardTradeLog(source);
		}

		@Override
		public PCardTradeLog[] newArray(int size) {
			return new PCardTradeLog[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(tradeDate);
		dest.writeString(tradeTime);
		dest.writeString(amt);
		dest.writeString(otheramt);
		dest.writeString(countryCode);
		dest.writeString(moneyCode);
		dest.writeString(merchantName);
		dest.writeInt(tradetype);
		dest.writeByteArray(appTradeCount);

	}

	public String getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public String getOtheramt() {
		return otheramt;
	}

	public void setOtheramt(String otheramt) {
		this.otheramt = otheramt;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getMoneyCode() {
		return moneyCode;
	}

	public void setMoneyCode(String moneyCode) {
		this.moneyCode = moneyCode;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public int getTradetype() {
		return tradetype;
	}

	public void setTradetype(int tradetype) {
		this.tradetype = tradetype;
	}

	public byte[] getAppTradeCount() {
		return appTradeCount;
	}

	public void setAppTradeCount(byte[] appTradeCount) {
		this.appTradeCount = appTradeCount;
	}

	public String getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}

}
