package com.dc.p92pos.aidl.emv;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * EMV参数控制
 * 
 * @author dynamicode
 * 
 */
public class EmvTradeData implements Parcelable {
	private byte tradetype;
	private byte requestAmtPosition;
	private boolean isEcashEnable;
	private boolean isSmEnable;
	private boolean isForceOnline;
	private boolean isSimple;
	private boolean isRfTimeOper;
	private byte emvFlow;
	private byte slotType;
	private byte cardSn;
	private byte[] reserv;
	private String money;
	private boolean isShanKaOper;
	private byte shanKaProcessSelect;
	private boolean isSmallNotSignNotPwd;
	private boolean isAbleOnline;	//脱机退货，运行纯电子现金卡联机

	public EmvTradeData() {
		
	}

	public EmvTradeData(Parcel source) {
		this.tradetype = source.readByte();
		this.requestAmtPosition = source.readByte();
		this.isEcashEnable = (Boolean) source.readValue(Boolean.class.getClassLoader());
		this.isSmEnable = (Boolean) source.readValue(Boolean.class.getClassLoader());
		this.isForceOnline = (Boolean) source.readValue(Boolean.class.getClassLoader());
		this.isSimple = (Boolean) source.readValue(Boolean.class.getClassLoader());
		this.isRfTimeOper = (Boolean) source.readValue(Boolean.class.getClassLoader());
		this.emvFlow = source.readByte();
		this.slotType = source.readByte();
		this.cardSn = source.readByte();
		this.reserv = (byte[]) source.readValue(byte[].class.getClassLoader());
		this.money = source.readString();
		this.isShanKaOper = (Boolean) source.readValue(Boolean.class.getClassLoader());
		this.shanKaProcessSelect = source.readByte();
		this.isSmallNotSignNotPwd = (Boolean) source.readValue(Boolean.class.getClassLoader());
		this.isAbleOnline = (Boolean) source.readValue(Boolean.class.getClassLoader());
	}
	
	public EmvTradeData(byte tradetype, byte requestAmtPosition,
			boolean isEcashEnable, boolean isSmEnable, boolean isForceOnline, boolean isSimple, boolean isRfTimeOper,
			byte emvFlow, byte slotType, byte cardSn, byte[] reserv, String money, boolean isShanKaOper, 
			byte shanKaProcessSelect, boolean isSmallNotSignNotPwd, boolean isAbleOnline) {
		super();
		this.tradetype = tradetype;
		this.requestAmtPosition = requestAmtPosition;
		this.isEcashEnable = isEcashEnable;
		this.isSmEnable = isSmEnable;
		this.isForceOnline = isForceOnline;
		this.isSimple = isSimple;
		this.isRfTimeOper = isRfTimeOper;
		this.emvFlow = emvFlow;
		this.slotType = slotType;
		this.cardSn = cardSn;
		this.reserv = reserv;
		this.money = money;
		this.isShanKaOper = isShanKaOper;
		this.shanKaProcessSelect = shanKaProcessSelect;
		this.isSmallNotSignNotPwd = isSmallNotSignNotPwd;
		this.isAbleOnline = isAbleOnline;
	}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeByte(this.tradetype);
		dest.writeByte(this.requestAmtPosition);
		dest.writeValue(isEcashEnable);
		dest.writeValue(isSmEnable);
		dest.writeValue(isForceOnline);
		dest.writeValue(isSimple);
		dest.writeValue(isRfTimeOper);
		dest.writeByte(emvFlow);
		dest.writeByte(slotType);
		dest.writeByte(cardSn);
		dest.writeValue(reserv);
		dest.writeString(money);
		dest.writeValue(isShanKaOper);
		dest.writeByte(shanKaProcessSelect);
		dest.writeValue(isSmallNotSignNotPwd);
		dest.writeValue(isAbleOnline);
	}

	public static final Parcelable.Creator<EmvTradeData> CREATOR = new Creator<EmvTradeData>() {

		@Override
		public EmvTradeData createFromParcel(Parcel source) {
			EmvTradeData emvTradeData = new EmvTradeData(source);
			return emvTradeData;
		}

		@Override
		public EmvTradeData[] newArray(int size) {
			return null;
		}
	};

	public byte getTradetype() {
		return tradetype;
	}

	public void setTradetype(byte tradetype) {
		this.tradetype = tradetype;
	}

	public byte getRequestAmtPosition() {
		return requestAmtPosition;
	}

	public void setRequestAmtPosition(byte requestAmtPosition) {
		this.requestAmtPosition = requestAmtPosition;
	}

	public boolean isEcashEnable() {
		return isEcashEnable;
	}

	public void setEcashEnable(boolean isEcashEnable) {
		this.isEcashEnable = isEcashEnable;
	}

	public boolean isSmEnable() {
		return isSmEnable;
	}

	public void setSmEnable(boolean isSmEnable) {
		this.isSmEnable = isSmEnable;
	}

	public boolean isForceOnline() {
		return isForceOnline;
	}

	public void setForceOnline(boolean isForceOnline) {
		this.isForceOnline = isForceOnline;
	}

	public byte getEmvFlow() {
		return emvFlow;
	}

	public void setEmvFlow(byte emvFlow) {
		this.emvFlow = emvFlow;
	}

	public byte getSlotType() {
		return slotType;
	}

	public void setSlotType(byte slotType) {
		this.slotType = slotType;
	}

	public byte[] getReserv() {
		return reserv;
	}

	public void setReserv(byte[] reserv) {
		this.reserv = reserv;
	}
	
	public byte getCardSn() {
		return cardSn;
	}

	public void setCardSn(byte cardSn) {
		this.cardSn = cardSn;
	}
	
	public boolean isSimple() {
		return isSimple;
	}
	
	public void setEimple(boolean isSimple) {
		this.isSimple = isSimple;
	}

	public static Parcelable.Creator<EmvTradeData> getCreator() {
		return CREATOR;
	}

	public boolean isRfTimeOper() {
		return isRfTimeOper;
	}

	public void setRfTimeOper(boolean isRfTimeOper) {
		this.isRfTimeOper = isRfTimeOper;
	}

	public String getMoney() {
		return money;
	}

	public void setMoney(String money) {
		this.money = money;
	}

	public boolean isShanKaOper() {
		return isShanKaOper;
	}

	public void setShanKaOper(boolean isShanKaOper) {
		this.isShanKaOper = isShanKaOper;
	}

	public byte getShanKaProcessSelect() {
		return shanKaProcessSelect;
	}

	public void setShanKaProcessSelect(byte shanKaProcessSelect) {
		this.shanKaProcessSelect = shanKaProcessSelect;
	}
	
	public boolean isSmallNotSignNotPwd() {
		return isSmallNotSignNotPwd;
	}

	public void setSmallNotSignNotPwd(boolean isSmallNotSignNotPwd) {
		this.isSmallNotSignNotPwd = isSmallNotSignNotPwd;
	}

	public boolean isAbleOnline() {
		return isAbleOnline;
	}

	public void setAbleOnline(boolean isAbleOnline) {
		this.isAbleOnline = isAbleOnline;
	}
}

