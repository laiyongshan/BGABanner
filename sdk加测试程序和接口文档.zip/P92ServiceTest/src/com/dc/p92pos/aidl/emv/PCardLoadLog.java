package com.dc.p92pos.aidl.emv;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 圈存日志
 * 
 * @author dynamicode
 * 
 */
public class PCardLoadLog implements Parcelable {

	/** Put Data 命令的P1 值：1 字节 **/
	private String putdata_p1;

	/** Put Data 命令的P2 值:1 字节 **/
	private String putdata_p2;

	/** Put Data 修改前xxxx（9F79 或DF79）的值：6 字节 **/
	private String before_putdata;

	/** Put Data 修改后xxxx（9F79 或DF79）的值：6 字节 **/
	private String after_putdata;

	/** 交易日期 **/
	private String tradeDate;

	/** 交易时间 **/
	private String tradeTime;

	/** 国家代码 */
	private String countryCode;

	/** 商户名称 */
	private String merchantName;

	/** 应用交易计数器 */
	private String appTradeCount;

	public PCardLoadLog() {
	}
	
	

	public PCardLoadLog(String putdata_p1, String putdata_p2,
			String before_putdata, String after_putdata, String tradeDate,
			String tradeTime, String countryCode, String merchantName, String appTradeCount) {
		super();
		this.putdata_p1 = putdata_p1;
		this.putdata_p2 = putdata_p2;
		this.before_putdata = before_putdata;
		this.after_putdata = after_putdata;
		this.tradeDate = tradeDate;
		this.tradeTime = tradeTime;
		this.countryCode = countryCode;
		this.merchantName = merchantName;
		this.appTradeCount = appTradeCount;
	}

	private PCardLoadLog(Parcel source) {
		this.putdata_p1 = source.readString();
		this.putdata_p2 = source.readString();
		this.before_putdata = source.readString();
		this.after_putdata = source.readString();
		this.tradeDate = source.readString();
		this.tradeTime = source.readString();
		this.countryCode = source.readString();
		this.merchantName = source.readString();
		this.appTradeCount = source.readString();
	}

	public static final Parcelable.Creator<PCardLoadLog> CREATOR = new Parcelable.Creator<PCardLoadLog>() {

		@Override
		public PCardLoadLog createFromParcel(Parcel source) {
			return new PCardLoadLog(source);
		}

		@Override
		public PCardLoadLog[] newArray(int size) {
			return new PCardLoadLog[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(putdata_p1);
		dest.writeString(putdata_p2);
		dest.writeString(before_putdata);
		dest.writeString(after_putdata);
		dest.writeString(tradeDate);
		dest.writeString(tradeTime);
		dest.writeString(countryCode);
		dest.writeString(merchantName);
		dest.writeString(appTradeCount);

	}

	public String getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}

	public String getAppTradeCount() {
		return appTradeCount;
	}

	public void setAppTradeCount(String appTradeCount) {
		this.appTradeCount = appTradeCount;
	}

	public String getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getPutdata_p1() {
		return putdata_p1;
	}

	public void setPutdata_p1(String putdata_p1) {
		this.putdata_p1 = putdata_p1;
	}

	public String getPutdata_p2() {
		return putdata_p2;
	}

	public void setPutdata_p2(String putdata_p2) {
		this.putdata_p2 = putdata_p2;
	}

	public String getBefore_putdata() {
		return before_putdata;
	}

	public void setBefore_putdata(String before_putdata) {
		this.before_putdata = before_putdata;
	}

	public String getAfter_putdata() {
		return after_putdata;
	}

	public void setAfter_putdata(String after_putdata) {
		this.after_putdata = after_putdata;
	}



	public String getCountryCode() {
		return countryCode;
	}



	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}



	public String getMerchantName() {
		return merchantName;
	}



	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

}
