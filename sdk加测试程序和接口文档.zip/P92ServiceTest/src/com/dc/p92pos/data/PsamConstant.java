package com.dc.p92pos.data;

public class PsamConstant {
	/**
	 * PSAM卡1
	 */
	public static final int PSAM_DEV_ID_1 = 1;
	/**
	 * PSAM卡2
	 */
	public static final int PSAM_DEV_ID_2 = 2;
	/**
	 * PSAM卡3
	 */
	public static final int PSAM_DEV_ID_3 = 3;
}
