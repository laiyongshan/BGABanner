package com.dc.p92pos.data;

public class SerialportConstant {
	/**
	 * 串口1
	 */
	public static final int PORT_ONE = 1;
	/**
	 * 串口2
	 */
	public static final int PORT_TWO = 2;
}
