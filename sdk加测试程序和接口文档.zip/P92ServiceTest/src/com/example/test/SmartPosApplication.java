package com.example.test;

import android.app.Application;

public class SmartPosApplication extends Application {
	@Override
	public void onCreate() {
		super.onCreate();
	}

}
