package com.example.test;

import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.iccard.AidlICCard;
import com.example.util.HexUtil;
import com.dynamicode.p92servicetest.R;

/**
 * 密码键盘设备测试
 * 
 * @author Administrator
 * 
 */
public class ICCardActivity extends BaseTestActivity {

	private AidlICCard iccard = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.iccardtest);
		super.onCreate(savedInstanceState);
	}

	public void open(View v) {
		try {
			boolean flag = iccard.open();
			if (flag) {
				showMessage("打开IC卡设备成功");
			} else {
				showMessage("打开IC卡设备失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void close(View v) {
		try {
			boolean flag = iccard.close();
			if (flag) {
				showMessage("关闭IC卡设备成功");
			} else {
				showMessage("关闭IC卡设备失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void halt(View v) {
		try {
			int ret = iccard.halt();
			if (ret == 0x00) {
				showMessage("断开IC卡设备成功");
			} else {
				showMessage("断开IC卡设备失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void apduComm(View v) {
		byte[] apdu = HexUtil
				.hexStringToByte("00A404000E315041592E5359532E4444463031");
		try {
			byte[] data = iccard.apduComm(apdu);
			if (null != data) {
				showMessage("选择主目录结果" + HexUtil.bcd2str(data));
			} else {
				showMessage("APDU数据交互失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void cardReset(View v) {
		try {
			byte[] data = iccard.reset(0x00);
			if (null != data) {
				showMessage("卡片复位结果" + HexUtil.bcd2str(data));
			} else {
				showMessage("卡片复位失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void isExists(View v) {
		try {
			boolean flag = iccard.isExist();
			if (flag) {
				showMessage("卡片已插入");
			} else {
				showMessage("未检测到卡片");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		try {
			iccard = AidlICCard.Stub.asInterface(serviceManager
					.getInsertCardReader());
			if (iccard == null) {
				showMessage("IC卡驱动被禁用");
				return;
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
