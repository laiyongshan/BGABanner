package com.example.test;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;


import com.dynamicode.p92servicetest.R;

/**
 * 外设测试DEMO
 * 
 * @author Administrator
 * 
 */
public class MainActivity extends BaseActivity {
	private ListView operationList;
	private ArrayAdapter<String> adapter;

	private static final int ITEM1 = Menu.FIRST;
	
	private String[] listItem = new String[] { "磁条卡", "打印机", "密码键盘", "串口",
			"psam卡设备", "接触式IC卡", "非接触式IC卡", "系统接口", "EMV接口测试" };
	
	private List<String> item = new ArrayList<String>();
	@SuppressWarnings("rawtypes")
	private Class[] clsArray = new Class[] { SwipeCardActivity.class,
			PrintDevActivity.class, PinPadActivity.class,
			SerialportActivity.class, PsamActivity.class, ICCardActivity.class,
			RFCardActivity.class, SystemActivity.class, PbocActivity.class };
	@SuppressWarnings("rawtypes")
	private List<Class> cls = new ArrayList<Class>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_activity);

		operationList = (ListView) findViewById(R.id.main_list_view);
		initMenuList();
		
		adapter = new ArrayAdapter<String>(this, R.layout.show_item2, item);
		operationList.setAdapter(adapter);
		operationList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View view,
					int position, long arg3) {
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, cls.get(position));
				startActivity(intent);
			}
		});
	}

	private void initMenuList() {
		for (int i = 0; i < listItem.length; i++) {
			item.add(listItem[i]);
		}
		for (int i = 0; i < clsArray.length; i++) {
			cls.add(clsArray[i]);
		}
	}

	@Override
	// 点击菜单按钮响应的事件
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, ITEM1, 0, "系统设置");
		return true;
	}

	@Override
	// 菜单被选中时触发的事件
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case ITEM1: 
			Intent intent = new Intent(MainActivity.this, SettingActivity.class);
			startActivity(intent);
			break;

		default:
			break;
		}
		return true;
	}

	/**
	 * 刷卡设备
	 * 
	 * @return void
	 * @param v
	 * @createtor：Administrator
	 * @date:2014-1-15 下午1:38:00
	 */
	public void onMagCardDevClick(View v) {
		Intent intent = new Intent(MainActivity.this, SwipeCardActivity.class);
		startActivity(intent);
	}

	/**
	 * 打印机设备
	 * 
	 * @return void
	 * @param v
	 * @createtor：Administrator
	 * @date:2014-1-15 下午1:41:34
	 */
	public void onPrinterClick(View v) {
		Intent intent = new Intent(MainActivity.this, PrintDevActivity.class);
		startActivity(intent);
	}

	/**
	 * 密码键盘设备
	 * 
	 * @return void
	 * @param v
	 * @createtor：Administrator
	 * @date:2014-1-15 下午1:41:41
	 */
	public void onPinPadClick(View v) {
		Intent intent = new Intent(MainActivity.this, PinPadActivity.class);
		startActivity(intent);
	}

	public void onSerialPortClick(View v) {
		Intent intent = new Intent(MainActivity.this, SerialportActivity.class);
		startActivity(intent);
	}

	public void onPsamClick(View v) {
		Intent intent = new Intent(MainActivity.this, PsamActivity.class);
		startActivity(intent);
	}

	public void onICCardClick(View v) {
		Intent intent = new Intent(MainActivity.this, ICCardActivity.class);
		startActivity(intent);
	}

	public void onRFCardClick(View v) {
		Intent intent = new Intent(MainActivity.this, RFCardActivity.class);
		startActivity(intent);
	}

	public void onSystemClick(View v) {
		Intent intent = new Intent(MainActivity.this, SystemActivity.class);
		startActivity(intent);

	}

	public void testPboc(View v) {
		Intent intent = new Intent(MainActivity.this, PbocActivity.class);
		startActivity(intent);
	}
}
