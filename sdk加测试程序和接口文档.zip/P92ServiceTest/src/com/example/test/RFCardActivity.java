package com.example.test;

import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.rfcard.AidlRFCard;
import com.example.util.HexUtil;
import com.dynamicode.p92servicetest.R;

/**
 * 非接卡设备测试
 * @author dynamicode
 */
public class RFCardActivity extends BaseTestActivity {

	public AidlRFCard rfcard = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.rfcardtest);
		super.onCreate(savedInstanceState);
	}

	// 打开设备
	public void open(View v) {
		try {
			boolean flag = rfcard.open();
			if (flag) {
				showMessage("打开非接卡设备成功");
			} else {
				showMessage("打开非接卡设备失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 关闭设备
	public void close(View v) {
		try {
			boolean flag = rfcard.close();
			if (flag) {
				showMessage("关闭非接卡设备成功");
			} else {
				showMessage("关闭非接卡设备失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 检测是否为在位
	public void isExists(View v) {
		try {
			boolean flag = rfcard.isExist();
			if (flag) {
				showMessage("检测到卡片");
			} else {
				showMessage("未检测到卡片");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 上电复位
	public void reset(View v) {
		try {
			byte[] data = rfcard.reset(0x00);
			if (null != data) {
				showMessage("非接卡复位结果" + HexUtil.bcd2str(data));
			} else {
				showMessage("非接卡复位失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 断开
	public void halt(View v) {
		try {
			int ret = rfcard.halt();
			if (ret == 0x00) {
				showMessage("非接卡下电操作成功");
			} else {
				showMessage("非接卡下电操作失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 读取卡类型
	public void readCardType(View v) {
		try {
			int type = rfcard.getCardType();
			showMessage("卡类型读取成功" + type);
		} catch (RemoteException e) {
			e.printStackTrace();
			showMessage("卡类型读取失败");
		}
	}

	// apdu通讯
	public void apduComm(View v) {
		try {
			byte[] apdu = HexUtil.hexStringToByte("00A404000E315041592E5359532E4444463031");
			byte[] data = rfcard.apduComm(apdu);
			if (data != null) {
				showMessage("APDU通讯成功" + HexUtil.bcd2str(data));
			} else {
				showMessage("APDU通讯失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 认证
	public void auth(View v) {
		try {
			byte[] resetData = rfcard.reset(0x00);
			int retCode = rfcard.auth((byte) 0x00, (byte) 0x01, new byte[] {0x01, 0x02, 0x03, 0x04, 0x05, 0x06 }, resetData);
			showMessage("认证返回结果为" + retCode);
			if (0x00 == retCode) {
				showMessage("认证成功");
			} else {
				showMessage("认证失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 加值
	public void addValue(View v) {
		try {
			int retCode = rfcard.addValue((byte) 0x02, new byte[] { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 });
			showMessage("加值返回操作结果为" + retCode);
			if (retCode == 0x00) {
				showMessage("加值成功");
			} else {
				showMessage("加值失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 减值
	public void reduceValue(View v) {
		try {
			int retCode = rfcard.reduceValue((byte) 0x02, new byte[] { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 });
			showMessage("减值返回操作结果为" + retCode);
			if (retCode == 0x00) {
				showMessage("减值成功");
			} else {
				showMessage("减值失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// 读取块数据
	public void readBlockData(View v) {
		try {
			byte[] data = new byte[2048];
			int length = rfcard.readBlock((byte) 0x01, data);
			showMessage("读取块数据返回长度为" + length);
			if (length > 0x00) {
				showMessage("读取块数据成功" + HexUtil.bcd2str(data));
			} else {
				showMessage("读取块数据失败");
			}

		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 写块数据
	public void writeBlock(View v) {
		try {
			int retCode = rfcard.writeBlock((byte) 0x01, new byte[] {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 });
			showMessage("写块数据返回结果" + retCode);
			if (retCode == 0x00) {
				showMessage("写入块数据成功");
			} else {
				showMessage("写入快数据失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		try {
			rfcard = AidlRFCard.Stub.asInterface(serviceManager.getRFIDReader());
			if (rfcard == null) {
				showMessage("非接卡驱动被禁用");
				return;
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
}