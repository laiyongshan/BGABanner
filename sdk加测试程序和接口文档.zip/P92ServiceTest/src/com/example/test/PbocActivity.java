package com.example.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.RemoteException;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.emv.AidlCheckCardListener;
import com.dc.p92pos.aidl.emv.AidlPboc;
import com.dc.p92pos.aidl.emv.AidlPbocStartListener;
import com.dc.p92pos.aidl.emv.CardInfo;
import com.dc.p92pos.aidl.emv.EmvTradeData;
import com.dc.p92pos.aidl.emv.PCardLoadLog;
import com.dc.p92pos.aidl.emv.PCardTradeLog;
import com.dc.p92pos.aidl.magcard.TrackData;
import com.dc.p92pos.aidl.pinpad.AidlPinpad;
import com.dc.p92pos.aidl.pinpad.GetPinListener;
import com.dc.p92pos.aidl.system.AidlSystem;
import com.dc.p92pos.data.PinpadConstant;
import com.example.util.Debug;
import com.example.util.EMVTAGStr;
import com.example.util.HexUtil;
import com.example.util.CHexConver;
import com.dynamicode.p92servicetest.R;

/**
 * PBOC测试
 * 
 * @author dynamicode
 * 
 */
public class PbocActivity extends BaseTestActivity {

	private AidlPboc pboc = null;
	private AidlPinpad pinpad = null; // 密码键盘接口
	private AidlSystem systemInf = null;

	private PbocStartListener listener = null;
	private EmvTradeData emvTradeData = null;	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.pboctest);
		super.onCreate(savedInstanceState);
		
		emvTradeData = new EmvTradeData((byte)0x00, (byte)0x01, false, true, false, false, false, 
				(byte)0x01, (byte)0x00, (byte)0x00, new byte[] { 0x00, 0x00, 0x00 }, "", false, 
				(byte)0x00, false, false);
		listener = new PbocStartListener();
	}
	
	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		try {
			this.pinpad = AidlPinpad.Stub.asInterface(serviceManager.getPinPad(PinpadConstant.PinpadId.BUILTIN));
			this.pboc = AidlPboc.Stub.asInterface(serviceManager.getEMVL2());
			this.systemInf = AidlSystem.Stub.asInterface(serviceManager.getSystemService());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public void checkCard(View v) {
		if (null != pboc) {
			try {
				showMessage("开始检卡。。。");
				pboc.checkCard(true, true, true, 0, 60000, (byte)0x00, (byte)0x00, null, checkcardListener, null);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
	}

	public void cancelCheckCard(View v) {
		if (null != this.pboc) {
			try {
				showMessage("取消检卡");
				this.pboc.cancelCheckCard();
			} catch (RemoteException e) {
				e.printStackTrace();
				showMessage("取消刷卡操作异常");
			}
		}
	}

	// 圈存交易
	public void cardload(View v) {
		Builder dialog = new AlertDialog.Builder(PbocActivity.this);
		dialog.setTitle("圈存交易类型：");
		dialog.setIcon(android.R.drawable.ic_dialog_info);
		final String[] arrayItem_mc = new String[] { "圈存-非接", "圈存-接触" };

		dialog.setItems(arrayItem_mc, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
				case 0:
					showMessage("开始非接圈存。。。");
					emvTradeData.setEmvFlow((byte) 0x02); // 0x01 – PBOC 流程  0x02 -- qPBOC 流程
					emvTradeData.setSlotType((byte) 0x01); // 界面类型: 0x00——接触  0x01——非接
					emvTradeData.setTradetype((byte) 0x63);
					emvTradeData.setEcashEnable(true);
					emvTradeData.setRequestAmtPosition((byte) 0x01);
					break;
				case 1:
					showMessage("开始接触圈存。。。");
					emvTradeData.setEmvFlow((byte) 0x01); // 0x01 – PBOC 流程 0x02 -- qPBOC 流程
					emvTradeData.setSlotType((byte) 0x00); // 界面类型: 0x00——接触  0x01——非接
					emvTradeData.setTradetype((byte) 0x63);
					emvTradeData.setEcashEnable(true);
					emvTradeData.setRequestAmtPosition((byte) 0x01);
					break;

				default:
					break;
				}

				try {
					pboc.processPBOC(emvTradeData, listener);
				} catch (RemoteException e) {
					e.printStackTrace();
				}
			}
		});
		dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog.show();
	}

	public void readKernelData(View v) {
		byte[] data = new byte[2048];
		try {
			int retCode = pboc.readKernelData(EMVTAGStr.getgetF55Tag_CardInfo(),
					data);
			if (retCode > 0) {
				byte[] dataKernel = new byte[retCode];
				System.arraycopy(data, 0, dataKernel, 0, retCode);
				showMessage("内核数据读取成功" + HexUtil.bcd2str(dataKernel));

				String resString1 = this.pboc.parseTLV("5A", HexUtil.bcd2str(dataKernel));
				showMessage("TLV解析：5A - " + resString1);
				String resString2 = this.pboc.parseTLV("57", HexUtil.bcd2str(dataKernel));
				showMessage("TLV解析：57 - " + resString2);
				String resString3 = this.pboc.parseTLV("5F34", HexUtil.bcd2str(dataKernel));
				showMessage("TLV解析：5F34 - " + resString3);
			} else {
				showMessage("内核数据读取失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void abortPboc(View v) {
		try {
			showMessage("中断PBOC交易完成");
			this.pboc.abortPBOC();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public void endPboc(View v) {
		try {
			showMessage("结束PBOC交易完成");
			this.pboc.endPBOC();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public void setTlv(View v) {
		try {
			this.pboc.setTlv("5F2A", HexUtil.hexStringToByte("0156"));
			showMessage("设置终端参数成功");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public void readCardLoadLog(View v) {
		showMessage("正在读取卡片圈存日志。。。");

		emvTradeData.setTradetype((byte) 0xF4);
		try {
			pboc.processPBOC(emvTradeData, listener);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public void readCardTransLog(View v) {
		showMessage("正在读取卡片交易日志。。。");

		emvTradeData.setTradetype((byte) 0xF3);
		try {
			this.pboc.processPBOC(emvTradeData, listener);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public void clearTradeData(View v) {
		try {
			boolean flag = this.pboc.clearKernelICTradeLog();
			if (flag) {
				showMessage("清除交易日志成功");
			} else {
				showMessage("清除IC卡交易日志失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public void setMerchantName(View v) {
		final EditText inputServer = new EditText(PbocActivity.this);
		inputServer.setInputType(InputType.TYPE_CLASS_TEXT);
		inputServer.setText("");
		
		Builder dialog1 = new AlertDialog.Builder(PbocActivity.this);
		dialog1.setTitle("请输入商户名称：");
		dialog1.setIcon(android.R.drawable.ic_dialog_info);
		dialog1.setView(inputServer);
		dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						try {
							Log.e("MerchantName", inputServer.getText().toString());
							Bundle bundle = new Bundle();
							bundle.putString("MerchantName", inputServer.getText().toString());
							boolean flag = systemInf.SetEMVParams(bundle);
							if (flag) {
								showMessage("设置商户名称成功");
							} else {
								showMessage("设置商户名称失败");
							}
						} catch (RemoteException e) {
							e.printStackTrace();
						}
					}
				});
		dialog1.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});
		dialog1.show();
	}

	public void CaParamOperator(View v) {
		Builder dialog = new AlertDialog.Builder(PbocActivity.this);
		dialog.setTitle("公钥参数：");
		dialog.setIcon(android.R.drawable.ic_dialog_info);
		final String[] arrayItem = new String[] { "增加-拉卡拉", "增加-BCTC", "清空" };
		dialog.setItems(arrayItem, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
				case 0: {
					showMessage("正在增加公钥参数。。。");

					try {
						boolean updateResult = false;
						InputStream ins = getAssets().open("icparam/ic_param.txt");
						// 获取IC卡参数信息
						if (ins != null && ins.available() != 0x00) {
							BufferedReader br = new BufferedReader(new InputStreamReader(ins));
							String line = null;
							while ((line = br.readLine()) != null) { // 未到达文件末尾
								if (null != line) {
									if (line.startsWith("PUBLICKEY")) { // 更新RID
										updateResult = pboc.updateCAPK(0x01, line.split("=")[1]);
										Debug.d("加入公钥参数结果" + updateResult);
										showMessage("增加公钥参数" + updateResult);
										if (updateResult == false) {
											return;
										}
									}
								}
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
					break;
				case 1: {
					showMessage("正在增加公钥参数。。。");

					try {
						boolean updateResult = false;
						InputStream ins = getAssets().open("icparam/ic_param_bctc.txt");
						// 获取IC卡参数信息
						if (ins != null && ins.available() != 0x00) {
							BufferedReader br = new BufferedReader(new InputStreamReader(ins));
							String line = null;
							while ((line = br.readLine()) != null) { // 未到达文件末尾
								if (null != line) {
									if (line.startsWith("PUBLICKEY")) { // 更新RID
										updateResult = pboc.updateCAPK(0x01, line.split("=")[1]);
										Debug.d("加入公钥参数结果" + updateResult);
										showMessage("增加公钥参数" + updateResult);
										if (updateResult == false) {
											return;
										}
									}
								}
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
					break;
				case 2: {
					try {
						boolean flag = pboc.updateCAPK(0x03, null);
						if (flag) {
							showMessage("清空公钥参数成功");
						} else {
							showMessage("清空公钥参数失败");
						}
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
					break;

				default:
					break;
				}
			}
		});
		dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog.show();
	}

	public void AidOperator(View v) {
		Builder dialog = new AlertDialog.Builder(PbocActivity.this);
		dialog.setTitle("AID参数：");
		dialog.setIcon(android.R.drawable.ic_dialog_info);
		final String[] arrayItem = new String[] { "增加-拉卡拉", "增加-BCTC", "清空" };
		dialog.setItems(arrayItem, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
				case 0: {
					try {
						showMessage("正在增加AID参数。。。");
						// 读取assert下的IC卡参数配置文件，将相关参数加载到EMV内核

						boolean updateResult = false;
						InputStream ins = getAssets().open("icparam/ic_param.txt"); // 获取IC卡参数信息
						if (ins != null && ins.available() != 0x00) {
							BufferedReader br = new BufferedReader(new InputStreamReader(ins));
							String line = null;
							while ((line = br.readLine()) != null) { // 未到达文件末尾
								if (null != line) {
									if (line.startsWith("AID")) { // 更新AID
										updateResult = pboc.updateAID(0x01, line.split("=")[1]);
										Debug.d("加入AID" + line.split("=")[1] + "结果为" + updateResult);
										showMessage("增加AID参数" + updateResult);
										if (updateResult == false) {
											return;
										}
									}
								}
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
					break;
				case 1: {
					try {
						showMessage("正在增加AID参数。。。");
						// 读取assert下的IC卡参数配置文件，将相关参数加载到EMV内核

						boolean updateResult = false;
						InputStream ins = getAssets().open("icparam/ic_param_bctc.txt"); // 获取IC卡参数信息
						if (ins != null && ins.available() != 0x00) {
							BufferedReader br = new BufferedReader(new InputStreamReader(ins));
							String line = null;
							while ((line = br.readLine()) != null) { // 未到达文件末尾
								if (null != line) {
									if (line.startsWith("AID")) { // 更新AID
										updateResult = pboc.updateAID(0x01, line.split("=")[1]);
										Debug.d("加入AID" + line.split("=")[1] + "结果为" + updateResult);
										showMessage("增加AID参数" + updateResult);
										if (updateResult == false) {
											return;
										}
									}
								}
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
					break;
				case 2: {
					try {
						boolean flag = pboc.updateAID(0x03, null);
						if (flag) {
							showMessage("删除AID参数成功");
						} else {
							showMessage("删除AID参数失败");
						}
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
					break;

				default:
					break;
				}
			}
		});
		dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog.show();
	}
	
	public void BinOperator(View v) {
		Builder dialog = new AlertDialog.Builder(PbocActivity.this);
		dialog.setTitle("黑名单设置：");
		dialog.setIcon(android.R.drawable.ic_dialog_info);
		final String[] arrayItem = new String[] { "增加", "清空" };
		dialog.setItems(arrayItem, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
				case 0: {
					showMessage("正在设置黑名单。。。");
					
					final EditText editText = new EditText(PbocActivity.this);
					editText.setText("6222620110004833472");
					editText.setSelection(editText.getText().length());
					
					Builder dialog2 = new AlertDialog.Builder(PbocActivity.this);
					dialog2.setTitle("请输入");
					dialog2.setIcon(android.R.drawable.ic_dialog_info);  
					dialog2.setView(editText );
					dialog2.setPositiveButton("确定", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							try {
								String binString = editText.getText().toString();
								binString = HexUtil.byteToHex((byte)binString.length()) + HexUtil.showResult16Str(HexUtil.StringToByteArray(binString));
								
								boolean flag = pboc.updateBIN(0x01, binString);
								if (flag) {
									showMessage("增加黑名单成功");
								} else {
									showMessage("增加黑名单失败");
								}
							} catch (RemoteException e) {
								e.printStackTrace();
							}
						}
					});
					dialog2.setNegativeButton("取消", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.cancel();
						}
					});
					dialog2.show();
				}
					break;
				case 1: {
					try {
						boolean flag = pboc.updateBIN(0x03, null);
						if (flag) {
							showMessage("删除黑名单成功");
						} else {
							showMessage("删除黑名单失败");
						}
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
					break;

				default:
					break;
				}
			}
		});
		dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog.show();
	}
		
	// 检卡的监听器
	public AidlCheckCardListener.Stub checkcardListener = new AidlCheckCardListener.Stub() {
		@Override
		public void onFindMagCard(TrackData trackData)
				throws RemoteException {
			showMessage("检测到磁条卡");
			showMessage("卡号" + trackData.getCardno());
			showMessage("一磁道数据" + trackData.getFirstTrackData());
			showMessage("二磁道数据" + trackData.getSecondTrackData());
			showMessage("三磁道数据" + trackData.getThirdTrackData());
			showMessage("卡片服务码" + trackData.getServiceCode());
			showMessage("有效期" + trackData.getExpiryDate());
			showMessage("格式化磁道数据" + trackData.getFormatTrackData());
		}

		@Override
		public void onFindICCard() throws RemoteException {
			showMessage("检测到接触式IC卡");
		}

		@Override
		public void onFindRFCard() throws RemoteException {
			showMessage("检测到非接卡");
		}

		@Override
		public void onCanceled() throws RemoteException {
			showMessage("检卡被取消");
		}

		@Override
		public void onSwipeCardFail()
				throws RemoteException {
			showMessage("刷卡失败");
		}

		@Override
		public void onTimeout() throws RemoteException {
			showMessage("检卡超时");
		}

		@Override
		public void onError(int arg0)
				throws RemoteException {
			switch (arg0) {
			case 13:
				showMessage("检卡错误,错误码" + arg0);
				showMessage("请重新检卡，并插卡...");
				break;

			default:
				showMessage("错误码" + arg0);
				break;
			}
		}
	};

	private class PbocStartListener extends AidlPbocStartListener.Stub {
		@Override
		public void requestUserAuth(int certType, String certno)
				throws RemoteException {
			showMessage("请求账户类型确认");
			showMessage("账户类型" + certType);
			showMessage("账户号码" + certno);
			pboc.importUserAuthRes(true);
		}

		@Override
		public void requestTipsConfirm(String arg0) throws RemoteException {
			showMessage("请求提示信息");
			showMessage(arg0);
			pboc.importMsgConfirmRes(true);
		}

		/**
		 * 获取指定长度的*
		 * 
		 * @param len
		 * @return
		 * @createtor：Administrator
		 * @date:2015-8-4 下午9:13:40
		 */
		public String getStar(int len) {
			String str = "";
			while (len > 0) {
				str += "*";
				len--;
			}
			return str;
		}

		/**
		 * PIN输入监听器
		 * 
		 * @author dynamicode
		 * 
		 */
		private class MyGetPinListener extends GetPinListener.Stub {
			@Override
			public void onStopGetPin() throws RemoteException {
				showMessage("您取消了PIN输入");
			}

			@Override
			public void onInputKey(int arg0, String arg1)
					throws RemoteException {
				showMessage(getStar(arg0) + arg1 == null ? "" : arg1);
			}

			@Override
			public void onError(int arg0) throws RemoteException {
				showMessage("读取PIN输入错误，错误码" + arg0);
			}

			@Override
			public void onConfirmInput(byte[] arg0) throws RemoteException {
				showMessage("PIN输入成功" + (null == arg0 ? ",您输入了空密码" : ",PIN为" + HexUtil.bcd2str(arg0)));
				if (arg0 != null && arg0.length > 0) {
					pboc.importPin(3, HexUtil.bcd2str(arg0));
				}
			}

			@Override
			public void onCancelKeyPress() throws RemoteException {
				showMessage("您按下了取消键");
			}
		}

		/**
		 * 输入联机PIN
		 * 
		 * @param v
		 * @createtor：Administrator
		 * @date:2015-8-4 下午8:39:35
		 */
		public void inputPin() {
			final Bundle bundle = new Bundle();
			bundle.putInt("wkeyid", 0x00);
			bundle.putInt("keytype", 0x00);
			bundle.putByteArray("random", null);
			bundle.putInt("inputtimes", 1);
			bundle.putInt("minlength", 0);
			bundle.putInt("maxlength", 14);
			bundle.putString("pan", "0000000000000000");
			bundle.putString("tips", "RMB:2000.00");

			new Thread() {
				public void run() {
					try {
						pinpad.getPin(bundle, new MyGetPinListener());
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				};
			}.start();
		}

		@Override
		public void requestImportPin(int type, boolean lastFlag, String info)
				throws RemoteException {
			showMessage(info);
			inputPin();
		}

		@Override
		public void requestImportAmount(int arg0) throws RemoteException {
			showMessage("金额导入类型" + arg0);
			showMessage("导入交易金额：" + 0.01);
			boolean result = pboc.importAmount("" + 0.01);
			if (result == false) {
				showMessage("导入交易金额失败，请中断PBOC流程");
			}
		}

		@Override
		public void requestEcashTipsConfirm() throws RemoteException {
			showMessage("请求电子现金信息确认");
			pboc.importECashTipConfirmRes(emvTradeData.isEcashEnable());
		}

		@Override
		public void requestAidSelect(int times, String[] arg1)
				throws RemoteException {
			showMessage("请选择应用列表");
			String str = "";
			for (int i = 0; i < arg1.length; i++) {
				str += arg1[i];
			}
			showMessage("应用列表内容" + str);
			pboc.importAidSelectRes(0x01);
		}

		@Override
		public void onTradeResult(int arg0) throws RemoteException {
			showMessage("PBOC流程处理结果:" + arg0);
			switch (arg0) {
			case 0x01:
				showMessage("交易批准");
				break;
			case 0x02:
				showMessage("交易拒绝");
				break;
			case 0x03:
				showMessage("交易终止");
				break;
			case 0x04:
				showMessage("降级");
				break;
			case 0x05:
				showMessage("脱机余额不足，请求联机");
				break;
			case 0x06:
				showMessage("未知错误");
				break;
			case 0x07:
				showMessage("交易取消");
				break;
			case 0x08:
				showMessage("简易流程");
				break;
			case 0x09:
				showMessage("该卡被列入黑名单");
				break;
			default:
				showMessage("其他");
				break;
			}
		}

		@Override
		public void onRequestOnline() throws RemoteException {
			showMessage("请求联机，开始计算mac。。。");
			getMac();
		}

		public void getMac() {
			new Thread() {
				public void run() {
					try {
						Bundle bundle = new Bundle();
						bundle.putInt("wkeyid", 0x00);
						bundle.putByteArray(
								"data",
								HexUtil.hexStringToByte("02007024048020C0989519622700013096008915700000000000000000010000033010002200376227000130960089157D4208520970102000003132303031373931383232313231303037343230303035313536F2A22617F1DD0FAE2600000000000000001230643930313538313037393700063031303030300012303030303031303030303033"));
						bundle.putByteArray("random", null);
						bundle.putInt("type", 0x00);
						byte[] mac = new byte[8];

						int retCode = pinpad.getMac(bundle, mac);
						if (retCode != 0x00) {
							showMessage("mac计算失败，错误码为" + retCode);
						} else {
							showMessage("不含随机数，x919执行MAC计算成功，值为"
									+ HexUtil.bcd2str(mac));
						}
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				};
			}.start();
		}

		@Override
		public void onReadCardOffLineBalance(String arg0, String arg1, String arg2, String arg3) throws RemoteException {
			if (CHexConver.isEmpty(arg1) && CHexConver.isEmpty(arg3)) {
				showMessage("此卡无法查询余额");
			} else {
				showMessage("第一货币代码：" + arg0);
				showMessage("第一货币余额：" + arg1);
				showMessage("第二货币代码：" + arg2);
				showMessage("第二货币余额：" + arg3);
			}
		}

		@Override
		public void onReadCardTradeLog(PCardTradeLog[] logs) throws RemoteException {
			showMessage("读取卡片交易日志:");

			for (int i = 0; i < logs.length; i++) {
				showMessage((i + 1) + "、交易日期:" + logs[i].getTradeDate());
				showMessage("交易时间:" + logs[i].getTradeTime());
				showMessage("授权金额:" + logs[i].getAmt());
				showMessage("其他金额:" + logs[i].getOtheramt());
				showMessage("国家代码:" + logs[i].getCountryCode());
				showMessage("货币代码:" + logs[i].getMoneyCode());
				showMessage("商户名称:" + logs[i].getMerchantName());
				showMessage("交易类型:" + logs[i].getTradetype());
				showMessage("应用交易计数器:" + HexUtil.bytes2short(logs[i].getAppTradeCount()));
			}
		}

		@Override
		public void onReadCardLoadLog(String arg0, String arg1, PCardLoadLog[] arg2) throws RemoteException {
			showMessage("交易计数器" + arg0);
			showMessage("日志校验码" + arg1);

			for (int i = 0; i < arg2.length; i++) {
				showMessage((i + 1) + "、Put Data P1 值:" + arg2[i].getPutdata_p1());
				showMessage("Put Data P2 值:" + arg2[i].getPutdata_p2());
				showMessage("Put Data 修改前:" + arg2[i].getBefore_putdata());
				showMessage("Put Data 修改后:" + arg2[i].getAfter_putdata());
				showMessage("交易日期:" + arg2[i].getTradeDate());
				showMessage("交易时间:" + arg2[i].getTradeTime());
				showMessage("终端国家代码:" + arg2[i].getCountryCode());
				showMessage("商户名称:" + arg2[i].getMerchantName());
				showMessage("应用交易计数器:" + arg2[i].getAppTradeCount());
			}
		}

		@Override
		public void onError(int arg0) throws RemoteException {
			showMessage("PBOC处理出错" + arg0);
		}

		@Override
		public void onConfirmCardInfo(CardInfo arg0) throws RemoteException {
			showMessage("卡号信息：" + arg0.getCardno());
			pboc.importConfirmCardInfoRes(true);
		}

		@Override
		public void onCheckCard(int type) throws RemoteException {
			
		}
	}
}
