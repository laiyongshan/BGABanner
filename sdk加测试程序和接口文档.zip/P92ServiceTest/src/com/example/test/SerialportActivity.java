package com.example.test;

import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.serialport.AidlSerialport;
import com.dc.p92pos.data.SerialportConstant;
import com.dynamicode.p92servicetest.R;
import com.example.util.HexUtil;

/**
 * 串口设备测试
 * 
 * @author Administrator
 * 
 */
public class SerialportActivity extends BaseTestActivity {

	private AidlSerialport serialport = null; // 串口
	private AidlDeviceService deviceManager = null; // 服务管理类

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.serialporttest);
		super.onCreate(savedInstanceState);
	}

	/**
	 * 设置串口1
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-9 上午10:09:00
	 */
	public void setPortOne(View v) {
		try {
			serialport = AidlSerialport.Stub.asInterface(deviceManager.getSerialPort(SerialportConstant.PORT_ONE));
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 设置串口2
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-9 上午10:09:11
	 */
	public void setPortTwo(View v) {
		try {
			serialport = AidlSerialport.Stub.asInterface(deviceManager.getSerialPort(SerialportConstant.PORT_TWO));
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 打开串口
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-9 上午10:10:13
	 */
	public void open(View v) {
		try {
			serialport.open();
			showMessage("打开串口成功");
		} catch (RemoteException e) {
			e.printStackTrace();
			showMessage("打开串口失败");
		}
	}

	/**
	 * 初始化数据
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-9 上午10:10:23
	 */
	public void init(View v) {
		try {
			serialport.init(9600, (byte) 0x00, (byte) 0x08, (byte) 0x01);
			showMessage("初始化串口数据成功");
		} catch (RemoteException e) {
			e.printStackTrace();
			showMessage("初始化串口数据失败");
		}
	}

	/**
	 * 发送数据
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-9 上午10:10:32
	 */
	public void sendData(View v) {
		String str = "F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533F40379AB9E0EC533";
		try {
			boolean flag = serialport.sendData(HexUtil.hexStringToByte(str), 60000);
			if (flag) {
				showMessage("数据发送成功");
			} else {
				showMessage("数据发送失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 接收数据
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-9 上午10:10:41
	 */
	public void receiveData(View v) {
		try {
			byte[] data = serialport.readData(60000);
			if (null != data) {
				showMessage("数据读取成功，值为" + HexUtil.bcd2str(data));
			} else {
				showMessage("串口数据读取失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 关闭串口
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-9 上午10:10:57
	 */
	public void close(View v) {
		try {
			boolean flag = serialport.close();
			if (flag) {
				showMessage("串口关闭成功");
			} else {
				showMessage("串口关闭失败");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		try {
			deviceManager = serviceManager;
			serialport = AidlSerialport.Stub.asInterface(serviceManager.getSerialPort(SerialportConstant.PORT_ONE));
			if (serialport == null) {
				showMessage("串口驱动被禁用");
				return;
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		} // 默认串口1
	}
}