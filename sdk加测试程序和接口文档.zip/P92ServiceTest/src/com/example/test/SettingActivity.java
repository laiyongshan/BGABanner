package com.example.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.dynamicode.p92servicetest.R;
import com.example.util.HexUtil;
import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.system.AidlSystem;

public class SettingActivity extends BaseTestActivity {
	private ListView operationList;
	private ArrayAdapter<String> adapter;
	private AidlSystem isys = null;
	private ProgressDialog proDlg = null;
	private List<String> item = new ArrayList<String>();
	private String[] listItem = new String[] { "设置SN", "设置KSN", "设置字库", "验证字库", "恢复出厂设置" };

	protected static TabChangeReceiver receiver;
	private static final int SWITCH_TAB_RATE = 2547;
	private static final String fontPath_assets = "font";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting_activity);

		// 实例化
		proDlg = new ProgressDialog(this);
		proDlg.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		proDlg.setMessage("更新进度:");
		proDlg.setProgress(0);
		proDlg.setCancelable(false);

		receiver = new TabChangeReceiver();
		registerReceiver(receiver, new IntentFilter("main_pbar_view"), null,
				mHandler);
		
		operationList = (ListView) findViewById(R.id.main_list_view);
		initMenuList();
		
		adapter = new ArrayAdapter<String>(this, R.layout.show_item2, item);
		operationList.setAdapter(adapter);
		operationList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View view,
					int position, long arg3) {
				onListClick(position);
			}
		});
	}

	public class TabChangeReceiver extends android.content.BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent.getAction().equals("main_pbar_view")) {
				int intExtra = intent.getIntExtra("rate", 0);
				mHandler.sendMessage(mHandler.obtainMessage(SWITCH_TAB_RATE,
						intExtra, 0));
			}
		}
	}

	private void initMenuList() {
		// TODO Auto-generated method stub
		for (int i = 0; i < listItem.length; i++) {
			item.add(listItem[i]);
		}
	}
	
	private void onListClick(int index) {
		// TODO Auto-generated method stub
		switch (index) {
		case 0: {
			String terminalSn = "";
			try {
				terminalSn = isys.getSerialNo();
			} catch (RemoteException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			final EditText inputServer = new EditText(SettingActivity.this);
			inputServer.setInputType(InputType.TYPE_CLASS_TEXT);
			inputServer.setText(terminalSn);
			Builder dialog1 = new AlertDialog.Builder(SettingActivity.this);
			dialog1.setTitle("请输入SN：");
			dialog1.setIcon(android.R.drawable.ic_dialog_info);
			dialog1.setView(inputServer);
			dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							String sn = inputServer.getText().toString();

							if (sn == null || sn.length() != 14) {
								Toast.makeText(SettingActivity.this, "SN输入：有误", Toast.LENGTH_LONG).show();
							} else {
								Bundle bundle = new Bundle();
								bundle.putString("sn", sn);
								try {
									boolean flag = isys.SetDeviceParams(bundle);
									if (flag) {
										Toast.makeText(SettingActivity.this, "设置SN：成功", Toast.LENGTH_LONG).show();
									} else {
										Toast.makeText(SettingActivity.this, "设置SN：失败", Toast.LENGTH_LONG).show();
									}
								} catch (RemoteException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}
					});
			dialog1.setNegativeButton("取消",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
						}
					});
			dialog1.show();
		}
			break;
		case 1: {
			String terminalKsn = "";
			try {
				terminalKsn = isys.getKsn();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			final EditText inputServer = new EditText(SettingActivity.this);
			inputServer.setInputType(InputType.TYPE_CLASS_TEXT);
			inputServer.setText(terminalKsn);
			Builder dialog1 = new AlertDialog.Builder(SettingActivity.this);
			dialog1.setTitle("请输入KSN：");
			dialog1.setIcon(android.R.drawable.ic_dialog_info);
			dialog1.setView(inputServer);
			dialog1.setPositiveButton("确定",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							String ksn = inputServer.getText().toString();

							if (ksn == null || ksn.length() != 16) {
								Toast.makeText(SettingActivity.this, "KSN输入：有误", Toast.LENGTH_LONG).show();
							} else {
								Bundle bundle = new Bundle();
								bundle.putString("ksn", ksn);
								try {
									boolean flag = isys.SetDeviceParams(bundle);
									if (flag) {
										Toast.makeText(SettingActivity.this, "设置KSN：成功", Toast.LENGTH_LONG).show();
									} else {
										Toast.makeText(SettingActivity.this, "设置KSN：失败", Toast.LENGTH_LONG).show();
									}
								} catch (RemoteException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}
					});
			dialog1.setNegativeButton("取消",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
						}
					});
			dialog1.show();
		}
			break;
		case 2: {
			Vector<String> vecFile = GetAssetsFileName(fontPath_assets);

			if (vecFile.size() == 0) {
				Toast.makeText(SettingActivity.this, "字库未找到", Toast.LENGTH_LONG).show();
				return;
			}

			Builder dialog1 = new AlertDialog.Builder(SettingActivity.this);
			dialog1.setTitle("请选择设置的字库：");
			dialog1.setIcon(android.R.drawable.ic_dialog_info);

			final String[] arrayItem = new String[vecFile.size()];
			for (int i = 0; i < vecFile.size(); i++) {
				arrayItem[i] = vecFile.get(i);
			}

			dialog1.setItems(arrayItem, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					try {
						Log.e("", arrayItem[which]);

						int type = -1;
						if ("FontChar.fon".equalsIgnoreCase(arrayItem[which])) {
							type = 0;
						} else if ("Font16.fon".equalsIgnoreCase(arrayItem[which])) {
							type = 1;
						} else if ("Font24.fon".equalsIgnoreCase(arrayItem[which])) {
							type = 2;
						} else if ("BigFont16.fon".equalsIgnoreCase(arrayItem[which])) {
							type = 3;
						} else if ("BigFont24.fon".equalsIgnoreCase(arrayItem[which])) {
							type = 4;
						}

						byte[] data = null;
						try {
							data = readFileAssetsFile(fontPath_assets + "/"
									+ arrayItem[which]);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						if (data == null) {
							Toast.makeText(SettingActivity.this, "字库读取失败", Toast.LENGTH_LONG).show();
						} else {
							boolean flag = isys.SetFont(type, data);
							if (flag) {
								Toast.makeText(SettingActivity.this, "正在设置字库，请稍候", Toast.LENGTH_LONG).show();
							} else {
								Toast.makeText(SettingActivity.this, "字库设置：失败", Toast.LENGTH_LONG).show();
							}
						}
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
			dialog1.setNegativeButton("取消",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
						}
					});
			dialog1.show();
		}
			break;
		case 3: {
			LayoutInflater layoutInflater = LayoutInflater
					.from(SettingActivity.this);
			View input_key = layoutInflater.inflate(R.layout.input_three, null);

			final TextView text_first = (TextView) input_key
					.findViewById(R.id.text_first);
			text_first.setText("字库类型：");
			final EditText edit_first = (EditText) input_key
					.findViewById(R.id.edit_first);
			edit_first.setText("16");

			final TextView text_second = (TextView) input_key
					.findViewById(R.id.text_second);
			text_second.setText("读取地址：");
			final EditText edit_second = (EditText) input_key
					.findViewById(R.id.edit_second);
			edit_second.setText("9DBC0");

			final TextView text_three = (TextView) input_key
					.findViewById(R.id.text_third);
			text_three.setText("读取长度：");
			final EditText edit_third = (EditText) input_key
					.findViewById(R.id.edit_third);
			edit_third.setText("32");

			AlertDialog.Builder dialog1 = new AlertDialog.Builder(
					SettingActivity.this);
			dialog1.setTitle("验证字库：");
			dialog1.setIcon(android.R.drawable.ic_dialog_info);
			dialog1.setView(input_key);
			dialog1.setPositiveButton("确定",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							int type = Integer.parseInt(edit_first.getText().toString());
							byte[] addr = HexUtil.hexStringToByte(edit_second.getText().toString());
							int len = Integer.parseInt(edit_third.getText().toString());
							if (len > 0) {
								try {
									switch (type) {
									case 16:
										type = 1;
										break;
									case 24:
										type = 2;
										break;

									default:
										type = 0;
										break;
									}

									byte[] info = new byte[len];
									byte[] address = new byte[4];
									int j = 0;
									for (int i = addr.length - 1; i >= 0; i--) {
										address[j] = addr[i];
										j++;
									}

									boolean flag = isys.verifyFont(type, address, len, info);
									if (flag) {
										Builder dialog1 = new AlertDialog.Builder(
												SettingActivity.this);
										dialog1.setTitle("读取指定字库：");
										dialog1.setMessage(HexUtil.bcd2str(info));
										dialog1.setIcon(android.R.drawable.ic_dialog_info);
										dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
													public void onClick(
															DialogInterface dialog, int which) {
														dialog.cancel();
													}
												});
										dialog1.show();
									} else {
										Toast.makeText(SettingActivity.this, "字库读取：失败", Toast.LENGTH_LONG).show();
									}
								} catch (RemoteException e) {
									e.printStackTrace();
								}
							} else {
								Toast.makeText(SettingActivity.this, "请输入读取字库长度", Toast.LENGTH_LONG).show();
							}
						}
					});
			dialog1.setNegativeButton("取消",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
						}
					});
			dialog1.show();
		}
			break;
		case 4: {
			Builder dialog1 = new AlertDialog.Builder(SettingActivity.this);
			dialog1.setTitle("设置");
			dialog1.setMessage("确认是否恢复出厂设置？");
			dialog1.setIcon(android.R.drawable.ic_dialog_info);
			dialog1.setPositiveButton("确定",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							try {
								boolean flag = isys.restoreFactorySettings();
								if (flag) {
									Toast.makeText(SettingActivity.this, "恢复出厂设置：成功", Toast.LENGTH_LONG).show();
								} else {
									Toast.makeText(SettingActivity.this, "恢复出厂设置：失败", Toast.LENGTH_LONG).show();
								}
							} catch (RemoteException e) {
								e.printStackTrace();
							}
						}
					});
			dialog1.setNegativeButton("取消",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
						}
					});
			dialog1.show();
		}
			break;

		default:
			break;
		}
	}
	
	// 获取当前目录下所有的文件
	public Vector<String> GetAssetsFileName(String fileAbsolutePath) {
		Vector<String> vecFile = new Vector<String>();
		try {
			// 获取assets目录下的所有文件及目录名
			String fileNames[] = this.getAssets().list(fontPath_assets);
			if (fileNames.length > 0) {
				for (int i = 0; i < fileNames.length; i++) {
					if (fileNames[i].trim().toLowerCase().endsWith(".fon")) {
						vecFile.add(fileNames[i]);
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return vecFile;
	}

	// 读Assets中的文件
	public byte[] readFileAssetsFile(String fileName) throws IOException {
		byte[] buffer = null;
		try {
			InputStream des = this.getAssets().open(fileName);
			int fileLength = des.available();

			buffer = new byte[fileLength];
			des.read(buffer);
			des.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return buffer;
	}

	protected Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SWITCH_TAB_RATE:
				proDlg.setProgress(msg.arg1);
				if (msg.arg1 < 0) {
					if (proDlg.isShowing()) {
						proDlg.cancel();
					}
					Toast.makeText(SettingActivity.this, "更新失败", Toast.LENGTH_LONG)
							.show();
				} else if (msg.arg1 == 100) {
					if (proDlg.isShowing()) {
						proDlg.cancel();
						Toast.makeText(SettingActivity.this, "更新成功",
								Toast.LENGTH_LONG).show();
					}
				} else {
					if (!proDlg.isShowing()) {
						proDlg.show();
					}
				}
				break;
			default:
				break;
			}
		}
	};

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		// TODO Auto-generated method stub
		try {
			isys = AidlSystem.Stub.asInterface(serviceManager
					.getSystemService());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
