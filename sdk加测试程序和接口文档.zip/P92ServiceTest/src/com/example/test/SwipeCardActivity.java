package com.example.test;

import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.magcard.AidlMagCard;
import com.dc.p92pos.aidl.magcard.EncryptMagCardListener;
import com.dc.p92pos.aidl.magcard.MagCardListener;
import com.dc.p92pos.aidl.magcard.TrackData;
import com.dynamicode.p92servicetest.R;

public class SwipeCardActivity extends BaseTestActivity {

	private AidlMagCard magCardDev = null; // 磁条卡设备
	private int iTimeOut = 30000;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.swipecard);
		super.onCreate(savedInstanceState);
	}

	/**
	 * 服务绑定成功时
	 */
	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		try {
			magCardDev = AidlMagCard.Stub.asInterface(serviceManager.getMagCardReader());
			if (magCardDev == null) {
				showMessage("磁条卡驱动被禁用");
				return;
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 获取磁条卡数据
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午7:29:30
	 */
	public void getTrackData(View v) {
		if (magCardDev != null) {
			try {
				showMessage("请刷卡");
				magCardDev.searchCard(iTimeOut, new MagCardListener.Stub() {

					@Override
					public void onTimeout() throws RemoteException {
						showMessage("刷卡超时");
					}

					@Override
					public void onSuccess(TrackData trackData)
							throws RemoteException {
						showMessage("刷卡成功");
						showMessage("1磁道数据:" + trackData.getFirstTrackData());
						showMessage("2磁道数据:" + trackData.getSecondTrackData());
						showMessage("3磁道数据:" + trackData.getThirdTrackData());
						showMessage("卡号数据:" + trackData.getCardno());
						showMessage("卡片有效期:" + trackData.getExpiryDate());
						showMessage("格式化磁道数据:" + trackData.getFormatTrackData());
						showMessage("卡片服务码:" + trackData.getServiceCode());
						showMessage("------分隔------");
					}

					@Override
					public void onGetTrackFail() throws RemoteException {
						showMessage("刷卡失败");
					}

					@Override
					public void onError(int arg0) throws RemoteException {
						showMessage("错误码为：" + arg0);
					}

					@Override
					public void onCanceled() throws RemoteException {
						showMessage("明文刷卡被取消");
					}
				});
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * 获取密文磁道数据
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午7:29:40
	 */
	public void getEncryptTrackData(View v) {
		showMessage("请刷卡");
		try {
			if (null != magCardDev) {
				magCardDev.searchEncryptCard(iTimeOut, (byte) 0x00,
						(byte) 0x00, null, (byte) 0x00,
						new EncryptMagCardListener.Stub() {

							@Override
							public void onTimeout() throws RemoteException {
								showMessage("刷卡超时");
							}

							@Override
							public void onSuccess(String[] trackData)
									throws RemoteException {
								/*
								 * String[] trackData info.cardno,//0
								 * info.firstTrackData,//1
								 * info.secondTrackData,//2
								 * info.thirdTrackData,//3
								 * info.formatTrackData,//4 info.expiryDate,//5
								 * info.serviceCode//6
								 */
								// showMessage("加密二磁道数据" + trackData[2]);
								// showMessage("加密三磁道数据" + trackData[3]);
								// showMessage("卡号数据" + trackData[0]);
								// showMessage("------分隔------");
								showMessage("刷卡成功");
								showMessage("1磁道数据:" + trackData[1]);
								showMessage("2磁道数据:" + trackData[2]);
								showMessage("3磁道数据:" + trackData[3]);
								showMessage("加密格式化磁道数据" + trackData[4]);
								showMessage("卡号数据" + trackData[0]);
								showMessage("卡片有效期:" + trackData[5]);
								showMessage("卡片服务码:" + trackData[6]);
								showMessage("------分隔------");
							}

							@Override
							public void onGetTrackFail() throws RemoteException {
								showMessage("刷卡失败");
							}

							@Override
							public void onError(int arg0)
									throws RemoteException {
								showMessage("错误码为" + arg0);
							}

							@Override
							public void onCanceled() throws RemoteException {
								showMessage("密文刷卡被取消");
							}
						});
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 按照格式化磁道数据获取加密数据
	public void getEncryptFormatTrackData(View v) {
		showMessage("请刷卡");
		try {
			if (null != magCardDev) {
				magCardDev.searchEncryptCard(iTimeOut, (byte) 0x00,
						(byte) 0x01, null, (byte) 0x00,
						new EncryptMagCardListener.Stub() {

							@Override
							public void onTimeout() throws RemoteException {
								showMessage("刷卡超时");
							}

							@Override
							public void onSuccess(String[] trackData)
									throws RemoteException {
								/*
								 * String[] trackData info.cardno,//0
								 * info.firstTrackData,//1
								 * info.secondTrackData,//2
								 * info.thirdTrackData,//3
								 * info.formatTrackData,//4 info.expiryDate,//5
								 * info.serviceCode//6
								 */
								showMessage("刷卡成功");
								showMessage("1磁道数据:" + trackData[1]);// add
								showMessage("2磁道数据:" + trackData[2]);// add
								showMessage("3磁道数据:" + trackData[3]);// add
								showMessage("加密格式化磁道数据" + trackData[4]);
								showMessage("卡号数据" + trackData[0]);
								showMessage("卡片有效期:" + trackData[5]);// add
								showMessage("卡片服务码:" + trackData[6]);// add
								showMessage("------分隔------");

							}

							@Override
							public void onGetTrackFail() throws RemoteException {
								showMessage("刷卡失败");
							}

							@Override
							public void onError(int arg0)
									throws RemoteException {
								showMessage("错误码为" + arg0);
							}

							@Override
							public void onCanceled() throws RemoteException {
								showMessage("格式化刷卡被取消");
							}
						});
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 取消刷卡
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午7:29:49
	 */
	public void cancelSwipe(View v) {
		if (null != magCardDev) {
			try {
				magCardDev.stopSearch();
				showMessage("取消刷卡完成");
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				showMessage("取消刷卡操作异常");
			} // 中断刷卡
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		cancelSwipe(null); // 取消刷卡
	}

}
