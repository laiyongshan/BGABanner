package com.example.test;

import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.psam.AidlPsam;
import com.dc.p92pos.data.PsamConstant;
import com.example.util.HexUtil;
import com.dynamicode.p92servicetest.R;

/**
 * PSAM卡设备测试
 * 
 * @author Administrator
 * 
 */
public class PsamActivity extends BaseTestActivity {

	private AidlPsam psam = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.psamtest);
		super.onCreate(savedInstanceState);
	}

	// 打开PSAM卡
	public void open(View v) {
		try {
			boolean flag = psam.open();
			psam.setETU((byte) 0x02);
			if (flag) {
				showMessage("PSAM卡设备打开成功");
			} else {
				showMessage("PSAM卡设备打开失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// apdu交互测试
	public void apdutest(View v) {
		byte[] apdu = HexUtil
				.hexStringToByte("00A404000E315041592E5359532E4444463031");
		try {
			byte[] data = psam.apduComm(apdu);
			if (null != data) {
				showMessage("选择主目录返回结果为" + HexUtil.bcd2str(data));
			} else {
				showMessage("APDU交互失败");
			}

		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// PSAM卡复位
	public void psamreset(View v) {
		try {
			byte[] data = psam.reset(0x00);
			if (null != data) {
				showMessage("PSAM卡复位成功" + HexUtil.bcd2str(data));
			} else {
				showMessage("PSAM卡复位失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 关闭
	public void close(View v) {
		try {
			boolean flag = psam.close();
			if (flag) {
				showMessage("PSAM卡设备关闭成功");
			} else {
				showMessage("PSAM卡设备关闭失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		try {
			psam = AidlPsam.Stub.asInterface(serviceManager
					.getPSAMReader(PsamConstant.PSAM_DEV_ID_1));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
