package com.example.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Calendar;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.system.AidlSystem;
import com.dc.p92pos.aidl.system.InstallAppObserver;
import com.dynamicode.p92servicetest.R;

public class SystemActivity extends BaseTestActivity {
	public static final String UPDATE_MSG = "com.lakala.gtms.update";
	private static final int INSTALL_FINISH = 0xf;
	/**
	 * Installation return code<br/>
	 * install success.
	 */
	public static final int INSTALL_SUCCEEDED = 1;
	/**
	 * Installation return code<br/>
	 * the package is already installed.
	 */
	public static final int INSTALL_FAILED_ALREADY_EXISTS = -1;

	/**
	 * Installation return code<br/>
	 * the package archive file is invalid.
	 */
	public static final int INSTALL_FAILED_INVALID_APK = -2;

	/**
	 * Installation return code<br/>
	 * the URI passed in is invalid.
	 */
	public static final int INSTALL_FAILED_INVALID_URI = -3;

	/**
	 * Installation return code<br/>
	 * the package manager service found that the device didn't have enough
	 * storage space to install the app.
	 */
	public static final int INSTALL_FAILED_INSUFFICIENT_STORAGE = -4;

	/**
	 * Installation return code<br/>
	 * a package is already installed with the same name.
	 */
	public static final int INSTALL_FAILED_DUPLICATE_PACKAGE = -5;

	/**
	 * Installation return code<br/>
	 * the requested shared user does not exist.
	 */
	public static final int INSTALL_FAILED_NO_SHARED_USER = -6;

	/**
	 * Installation return code<br/>
	 * a previously installed package of the same name has a different signature
	 * than the new package (and the old package's data was not removed).
	 */
	public static final int INSTALL_FAILED_UPDATE_INCOMPATIBLE = -7;

	/**
	 * Installation return code<br/>
	 * the new package is requested a shared user which is already installed on
	 * the device and does not have matching signature.
	 */
	public static final int INSTALL_FAILED_SHARED_USER_INCOMPATIBLE = -8;

	/**
	 * Installation return code<br/>
	 * the new package uses a shared library that is not available.
	 */
	public static final int INSTALL_FAILED_MISSING_SHARED_LIBRARY = -9;

	/**
	 * Installation return code<br/>
	 * the new package uses a shared library that is not available.
	 */
	public static final int INSTALL_FAILED_REPLACE_COULDNT_DELETE = -10;

	/**
	 * Installation return code<br/>
	 * the new package failed while optimizing and validating its dex files,
	 * either because there was not enough storage or the validation failed.
	 */
	public static final int INSTALL_FAILED_DEXOPT = -11;

	/**
	 * Installation return code<br/>
	 * the new package failed because the current SDK version is older than that
	 * required by the package.
	 */
	public static final int INSTALL_FAILED_OLDER_SDK = -12;

	/**
	 * Installation return code<br/>
	 * the new package failed because it contains a content provider with the
	 * same authority as a provider already installed in the system.
	 */
	public static final int INSTALL_FAILED_CONFLICTING_PROVIDER = -13;

	/**
	 * Installation return code<br/>
	 * the new package failed because the current SDK version is newer than that
	 * required by the package.
	 */
	public static final int INSTALL_FAILED_NEWER_SDK = -14;

	/**
	 * Installation return code<br/>
	 * the new package failed because it has specified that it is a test-only
	 * package and the caller has not supplied the {@link #INSTALL_ALLOW_TEST}
	 * flag.
	 */
	public static final int INSTALL_FAILED_TEST_ONLY = -15;

	/**
	 * Installation return code<br/>
	 * the package being installed contains native code, but none that is
	 * compatible with the the device's CPU_ABI.
	 */
	public static final int INSTALL_FAILED_CPU_ABI_INCOMPATIBLE = -16;

	/**
	 * Installation return code<br/>
	 * the new package uses a feature that is not available.
	 */
	public static final int INSTALL_FAILED_MISSING_FEATURE = -17;

	/**
	 * Installation return code<br/>
	 * a secure container mount point couldn't be accessed on external media.
	 */
	public static final int INSTALL_FAILED_CONTAINER_ERROR = -18;

	/**
	 * Installation return code<br/>
	 * the new package couldn't be installed in the specified install location.
	 */
	public static final int INSTALL_FAILED_INVALID_INSTALL_LOCATION = -19;

	/**
	 * Installation return code<br/>
	 * the new package couldn't be installed in the specified install location
	 * because the media is not available.
	 */
	public static final int INSTALL_FAILED_MEDIA_UNAVAILABLE = -20;

	/**
	 * Installation return code<br/>
	 * the new package couldn't be installed because the verification timed out.
	 */
	public static final int INSTALL_FAILED_VERIFICATION_TIMEOUT = -21;

	/**
	 * Installation return code<br/>
	 * the new package couldn't be installed because the verification did not
	 * succeed.
	 */
	public static final int INSTALL_FAILED_VERIFICATION_FAILURE = -22;

	/**
	 * Installation return code<br/>
	 * the package changed from what the calling program expected.
	 */
	public static final int INSTALL_FAILED_PACKAGE_CHANGED = -23;

	/**
	 * Installation return code<br/>
	 * the new package is assigned a different UID than it previously held.
	 */
	public static final int INSTALL_FAILED_UID_CHANGED = -24;

	/**
	 * Installation return code<br/>
	 * if the parser was given a path that is not a file, or does not end with
	 * the expected '.apk' extension.
	 */
	public static final int INSTALL_PARSE_FAILED_NOT_APK = -100;

	/**
	 * Installation return code<br/>
	 * if the parser was unable to retrieve the AndroidManifest.xml file.
	 */
	public static final int INSTALL_PARSE_FAILED_BAD_MANIFEST = -101;

	/**
	 * Installation return code<br/>
	 * if the parser encountered an unexpected exception.
	 */
	public static final int INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION = -102;

	/**
	 * Installation return code<br/>
	 * if the parser did not find any certificates in the .apk.
	 */
	public static final int INSTALL_PARSE_FAILED_NO_CERTIFICATES = -103;

	/**
	 * Installation return code<br/>
	 * if the parser found inconsistent certificates on the files in the .apk.
	 */
	public static final int INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES = -104;

	/**
	 * Installation return code<br/>
	 * if the parser encountered a CertificateEncodingException in one of the
	 * files in the .apk.
	 */
	public static final int INSTALL_PARSE_FAILED_CERTIFICATE_ENCODING = -105;

	/**
	 * Installation return code<br/>
	 * if the parser encountered a bad or missing package name in the manifest.
	 */
	public static final int INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME = -106;

	/**
	 * Installation return code<br/>
	 * if the parser encountered a bad shared user id name in the manifest.
	 */
	public static final int INSTALL_PARSE_FAILED_BAD_SHARED_USER_ID = -107;

	/**
	 * Installation return code<br/>
	 * if the parser encountered some structural problem in the manifest.
	 */
	public static final int INSTALL_PARSE_FAILED_MANIFEST_MALFORMED = -108;

	/**
	 * Installation return code<br/>
	 * if the parser did not find any actionable tags (instrumentation or
	 * application) in the manifest.
	 */
	public static final int INSTALL_PARSE_FAILED_MANIFEST_EMPTY = -109;

	/**
	 * Installation return code<br/>
	 * if the system failed to install the package because of system issues.
	 */
	public static final int INSTALL_FAILED_INTERNAL_ERROR = -110;
	/**
	 * Installation return code<br/>
	 * other reason
	 */
	public static final int INSTALL_FAILED_OTHER = -1000000;

	private static final int SWITCH_TAB_RATE = 2547;

	private AidlSystem systemInf = null;
	protected static TabChangeReceiver receiver;
	private ProgressDialog proDlg = null;

	public static int DAT_SIGN = 0;
	public static int TIME_SIGN = 0;

	private String strCode = "";
	private static int total = 3;
	private static int current = 0;
	private final Calendar calendar = Calendar.getInstance();

	public class InstallBroadcastReceiver extends BroadcastReceiver {
		public void onReceive(Context context, Intent intent) {
			if (intent.getAction().equals(UPDATE_MSG)) {
				strCode = intent.getStringExtra("data");
				mHandler.sendEmptyMessage(INSTALL_FINISH);
			}
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.system_activity);
		super.onCreate(savedInstanceState);

		receiver = new TabChangeReceiver();
		registerReceiver(receiver, new IntentFilter("main_pbar_view"), null,
				mHandler);
		// installBr = new InstallBroadcastReceiver();
		// registerReceiver(installBr, new IntentFilter(UPDATE_MSG), null,
		// null);
		// 实例化
		proDlg = new ProgressDialog(this);
		proDlg.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		proDlg.setMessage("更新进度:");
		proDlg.setProgress(0);
		proDlg.setCancelable(false);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		// if(installBr != null){
		// unregisterReceiver(installBr);
		// }
		if (receiver != null) {
			unregisterReceiver(receiver);
		}
		super.onDestroy();
	}

	protected Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case SWITCH_TAB_RATE:
				if (msg.arg1 < 0) {
					if (proDlg.isShowing()) {
						proDlg.cancel();
					}
					showMessage("固件更新失败");
				} else if (msg.arg1 == 100) {
					if (proDlg.isShowing()) {
						proDlg.cancel();
						showMessage("固件更新成功");
					}
				} else {
					if (!proDlg.isShowing()) {
						proDlg.show();
					}
				}
				proDlg.setProgress(msg.arg1);
				break;
			case INSTALL_FINISH:
				showMessage(strCode);
				current++;
				if (current <= total) {
					updateAppBack(current);
				}
				break;
			default:
				break;
			}
		}
	};

	public class TabChangeReceiver extends android.content.BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent.getAction().equals("main_pbar_view")) {
				int intExtra = intent.getIntExtra("rate", 0);
				mHandler.sendMessage(mHandler.obtainMessage(SWITCH_TAB_RATE,
						intExtra, 0));
			}
		}
	}

	/**
	 * 读取终端序列号
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:16:41
	 */
	public void getTerminalSn(View v) {
		try {
			String terminalSn = systemInf.getSerialNo();
			showMessage("读取到的终端序列号为："
					+ (terminalSn == null ? "null" : terminalSn));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showMessage("读取终端序列号异常");
		}
	}

	/**
	 * 静默安装APP
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:19:18
	 */
	public void installAppBack(View v) {
		try {
			String path = systemInf.getStoragePath() + "/gtms118.apk";
			File f2 = new File(path);
			if (f2.exists()) {
				systemInf.installApp(path, new InstallAppObserver.Stub() {

					@Override
					public void onInstallFinished() throws RemoteException {
						showMessage("安装成功");
					}

					@Override
					public void onInstallError(int arg0) throws RemoteException {
						Log.d("SystemActivity", "errorid = " + arg0);
						showMessage("安装失败");
					}
				});
			} else {
				showMessage("文件不存在");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 静默升级APP
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:19:18
	 */
	public void updateAppBack(View v) {
		current = 1;
		try {
			String path = Environment.getExternalStorageDirectory().getPath()
					+ "/tmp/" + current + ".zip";
			String path2 = Environment.getExternalStorageDirectory().getPath()
					+ "/dcota/" + current + ".zip";
			File f2 = new File(path);
			if (f2.exists()) {
				copyFile(path, path2);
				systemInf.update(1);
			} else {
				showMessage("文件不存在");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void updateAppBack(int id) {
		try {
			String path = Environment.getExternalStorageDirectory().getPath()
					+ "/tmp/" + id + ".zip";
			String path2 = Environment.getExternalStorageDirectory().getPath()
					+ "/dcota/" + id + ".zip";
			File f2 = new File(path);
			if (f2.exists()) {
				copyFile(path, path2);
				systemInf.update(1);
			} else {
				showMessage("文件不存在");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 读取KSN号
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:20:01
	 */
	public void getKSN(View v) {
		try {
			String ksn = systemInf.getKsn();
			showMessage("读取到的KSN号为：" + (ksn == null ? "null" : ksn));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showMessage("读取KSN异常");
		}
	}

	/**
	 * 获取驱动版本信息
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:21:20
	 */
	public void getDriverVersion(View v) {
		try {
			String driverVesion = systemInf.getDriverVersion();
			showMessage("读取到的驱动版本信息为："
					+ (driverVesion == null ? "null" : driverVesion));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showMessage("读取驱动版本信息失败");
		}
	}
	
	/**
	 * 获取当前SDK版本信息
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:25:34
	 */
	public void getHtfskVersion(View v) {
		try {
			String curSdkVesion = systemInf.getHtfskVersion();
			String [] versionArray = curSdkVesion.split(",");
			showMessage("当前htfsk版本信息为：" + (curSdkVesion == null ? "null" : versionArray[0]));
			showMessage("当前libemvco.so版本信息为：" + (curSdkVesion == null ? "null" : versionArray[1]));
			showMessage("当前libmyserial-jni.so版本信息为：" + (curSdkVesion == null ? "null" : versionArray[2]));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showMessage("读取当前SDK版本信息失败");
		}
	}

	/**
	 * 获取当前SDK版本信息
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:25:34
	 */
	public void getCurrentSdkVersion(View v) {
		try {
			String curSdkVesion = systemInf.getCurSdkVersion();
			showMessage("当前SDK版本信息为："
					+ (curSdkVesion == null ? "null" : curSdkVesion));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showMessage("读取当前SDK版本信息失败");
		}
	}
	
	/**
	 * 更新系统时间
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:27:17
	 */
	public void updateSysTime(View v) {
		DAT_SIGN = 0;
		DatePickerDialog d = new DatePickerDialog(SystemActivity.this,
				mDateSetListener, calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH),
				calendar.get(Calendar.DAY_OF_MONTH));
		d.show();
	}

	private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int month, int day) {
			// TODO Auto-generated method stub
			if (DAT_SIGN == 0) {
				DAT_SIGN = -1;
				TIME_SIGN = 0;

				calendar.set(Calendar.YEAR, year);
				calendar.set(Calendar.MONTH, month);
				calendar.set(Calendar.DAY_OF_MONTH, day);

				TimePickerDialog t = new TimePickerDialog(SystemActivity.this,
						mTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY),
						calendar.get(Calendar.MINUTE), true);
				t.show();
			}
		}
	};

	private TimePickerDialog.OnTimeSetListener mTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
		@Override
		public void onTimeSet(TimePicker view, int hour, int minute) {
			// TODO Auto-generated method stub
			if (TIME_SIGN == 0) {
				TIME_SIGN = -1;

				calendar.set(Calendar.HOUR_OF_DAY, hour);
				calendar.set(Calendar.MINUTE, minute);

				try {
					String time = DateFormat.format("yyyyMMddHHmmss",
							calendar.getTimeInMillis()).toString();
					boolean flag = systemInf.updateSysTime(time);
					if (flag) {
						showMessage("系统时间更新成功");
					} else {
						showMessage("系统时间更新失败");
					}
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					showMessage("系统时间更新异常");
				}
			}
		}
	};

	/**
	 * 获取存储路径
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:28:52
	 */
	public void getStoragePath(View v) {
		try {
			String filePath = systemInf.getStoragePath();
			showMessage("获取到的文件存储信息为：" + filePath);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 更新终端驱动
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:30:13
	 */
	public void updateDriver(View v) {
		Builder dialog_mc = new AlertDialog.Builder(SystemActivity.this);
		dialog_mc.setTitle("更新终端驱动：");
		dialog_mc.setIcon(android.R.drawable.ic_dialog_info);
		final String[] arrayItem_mc = new String[] { "OS", "bin" };
		dialog_mc.setItems(arrayItem_mc, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {

				case 0:// OS
				{
					try {
						systemInf.update(0x00);
						showMessage("开启终端驱动OS升级操作");
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						showMessage("开启终端驱动升级失败");
					}
				}
					break;
				case 1:// bin
				{
					try {
						systemInf.update(0x01);
						showMessage("开启终端驱动bin升级操作");
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						showMessage("开启终端驱动升级失败");
					}
				}
					break;

				default:
					break;
				}
			}
		});
		dialog_mc.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});
		dialog_mc.show();
	}

	/**
	 * 读取终端IMSI
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:31:14
	 */
	public void getIMSI(View v) {
		try {
			String imsi = systemInf.getIMSI();
			showMessage("读取到的IMSI号为：" + imsi);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showMessage("读取IMSI号码失败");
		}
	}

	/**
	 * 读取IMEI号
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:32:22
	 */
	public void getIMEI(View v) {
		try {
			String imsi = systemInf.getIMEI();
			showMessage("读取到的IMEI号为：" + imsi);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showMessage("读取IMEI失败");
		}
	}

	/**
	 * 读取终端型号
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:33:26
	 */
	public void getModel(View v) {
		try {
			String model = systemInf.getModel();
			showMessage("终端型号为：" + model);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 读取硬件版本信息
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:40:15
	 */
	public void getHardwareInfo(View v) {
		try {
			String hardWareInfo = systemInf.getHardWireVersion();
			showMessage("读取到的硬件版本信息为：" + hardWareInfo);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 读取安全固件版本信息
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:47:31
	 */
	public void getSecurityDriverInfo(View v) {
		try {
			String securityDriverInfo = systemInf.getSecurityDriverVersion();
			showMessage("读取到的安全固件版本信息为：" + securityDriverInfo);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 读取终端厂商
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:48:21
	 */
	public void getManufactureName(View v) {
		try {
			String manuFacture = systemInf.getManufacture();
			showMessage("读取到的终端厂商信息为：" + manuFacture);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 读取操作系统版本信息
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:49:01
	 */
	public void getAndroidOsVersion(View v) {
		try {
			String androidOsVersion = systemInf.getAndroidOsVersion();
			showMessage("读取到的Android OS版本信息为：" + androidOsVersion);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 读取ROM版本信息
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:50:04
	 */
	public void getAndroidRomVersion(View v) {
		try {
			String romVersion = systemInf.getRomVersion();
			showMessage("读取到的Android ROM版本信息为：" + romVersion);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 重启终端
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:51:02
	 */
	public void reboot(View v) {
		try {
			systemInf.reboot();
			showMessage("重启终端成功");
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 读取终端内核版本信息
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:55:01
	 */
	public void getKernelVersionInfo(View v) {
		try {
			String kernelVersion = systemInf.getAndroidKernelVersion();
			showMessage("读取终端内核版本信息为：" + kernelVersion);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		try {
			systemInf = AidlSystem.Stub.asInterface(serviceManager.getSystemService());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 复制单个文件
	 * 
	 * @param oldPath
	 *            String 原文件路径 如：c:/fqf.txt
	 * @param newPath
	 *            String 复制后路径 如：f:/fqf.txt
	 * @return boolean
	 */
	@SuppressWarnings("resource")
	public void copyFile(String oldPath, String newPath) {
		try {
			int bytesum = 0;
			int byteread = 0;
			File oldfile = new File(oldPath);
			if (oldfile.exists()) { // 文件存在时
				InputStream inStream = new FileInputStream(oldPath); // 读入原文件
				FileOutputStream fs = new FileOutputStream(newPath);
				byte[] buffer = new byte[1444];
				while ((byteread = inStream.read(buffer)) != -1) {
					bytesum += byteread; // 字节数 文件大小
					System.out.println(bytesum);
					fs.write(buffer, 0, byteread);
				}
				inStream.close();
			}
		} catch (Exception e) {
			System.out.println("复制单个文件操作出错");
			e.printStackTrace();

		}

	}

	/**
	 * 复制整个文件夹内容
	 * 
	 * @param oldPath
	 *            String 原文件路径 如：c:/fqf
	 * @param newPath
	 *            String 复制后路径 如：f:/fqf/ff
	 * @return boolean
	 */
	public void copyFolder(String oldPath, String newPath) {

		try {
			(new File(newPath)).mkdirs(); // 如果文件夹不存在 则建立新文件夹
			File a = new File(oldPath);
			String[] file = a.list();
			File temp = null;
			for (int i = 0; i < file.length; i++) {
				if (oldPath.endsWith(File.separator)) {
					temp = new File(oldPath + file[i]);
				} else {
					temp = new File(oldPath + File.separator + file[i]);
				}

				if (temp.isFile()) {
					FileInputStream input = new FileInputStream(temp);
					FileOutputStream output = new FileOutputStream(newPath
							+ "/" + (temp.getName()).toString());
					byte[] b = new byte[1024 * 5];
					int len;
					while ((len = input.read(b)) != -1) {
						output.write(b, 0, len);
					}
					output.flush();
					output.close();
					input.close();
				}
				if (temp.isDirectory()) {// 如果是子文件夹
					copyFolder(oldPath + "/" + file[i], newPath + "/" + file[i]);
				}
			}
		} catch (Exception e) {
			System.out.println("复制整个文件夹内容操作出错");
			e.printStackTrace();

		}

	}
	
	/**
	 * 设置log级别
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 上午9:51:02
	 */
	public void setLogLeval(View v) {
		try {
			byte bLogParams = 0x03;
			boolean flag = systemInf.SetPrintLogAndLeval(bLogParams);
			
			showMessage(flag + "  设置成功");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

}
