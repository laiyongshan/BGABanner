package com.example.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.printer.AidlPrinter;
import com.dc.p92pos.aidl.printer.AidlPrinterListener;
import com.dc.p92pos.aidl.printer.PrintItemObj;
import com.dc.p92pos.aidl.printer.PrintItemObj.ALIGN;
import com.dynamicode.p92servicetest.R;

/**
 * 打印机测试工具类
 * @author dynamicode
 *
 */
/**
 * 打印机测试工具类
 * 
 * @author dynamicode
 * 
 */
public class PrintDevActivity extends BaseTestActivity {
	
	public final static int BARCODE_TYPE_UPCA = 65;

	public final static int BARCODE_TYPE_UPCE = 66;

	public final static int BARCODE_TYPE_JAN13 = 67;

	public final static int BARCODE_TYPE_JAN8 = 68;

	public final static int BARCODE_TYPE_CODE39 = 69;

	public final static int BARCODE_TYPE_ITF = 70;

	public final static int BARCODE_TYPE_CODEBAR = 71;

	public final static int BARCODE_TYPE_CODE93 = 72;

	public final static int BARCODE_TYPE_CODE128 = 73;

	private AidlPrinter printerDev = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.printdev);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		try {
			printerDev = AidlPrinter.Stub.asInterface(serviceManager.getPrinter());
			if (printerDev == null) {
				showMessage("打印机驱动被禁用");
				return;
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取打印机状态
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午2:18:47
	 */
	public void getPrintState(View v) {
		try {
			int printState = printerDev.getPrinterState();

			switch (printState) {
			case 0:
				showMessage("获取到的打印机状态为:正常");
				break;
			case 1:
				showMessage("获取到的打印机状态为:缺纸");
				break;
			case 2:
				showMessage("获取到的打印机状态为:高温");
				break;
			default:
				showMessage("获取到的打印机状态为:未知异常");
				break;
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 打印文本
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午2:19:28
	 */
	@SuppressWarnings("serial")
	public void printText(View v) {
		try {
			printerDev.printText(new ArrayList<PrintItemObj>() {
				{
					add(new PrintItemObj("默认打印数据测试"));
					add(new PrintItemObj("默认打印数据测试"));
					add(new PrintItemObj("默认打印数据测试"));
					add(new PrintItemObj("打印数据字体放大-16", 16));
					add(new PrintItemObj("打印数据字体放大-16", 16));
					add(new PrintItemObj("打印数据字体放大-16", 16));
					add(new PrintItemObj("打印数据字体放大-24", 24));
					add(new PrintItemObj("打印数据字体放大-24", 24));
					add(new PrintItemObj("打印数据字体放大-24", 24));
					add(new PrintItemObj("打印数据字体放大-32", 32));
					add(new PrintItemObj("打印数据字体放大-32", 32));
					add(new PrintItemObj("打印数据字体放大-32", 32));
					add(new PrintItemObj("打印数据字体放大-48", 48));
					add(new PrintItemObj("打印数据字体放大-48", 48));
					add(new PrintItemObj("打印数据字体放大-48", 48));
					add(new PrintItemObj("打印数据加粗", 8, true));
					add(new PrintItemObj("打印数据加粗", 8, true));
					add(new PrintItemObj("打印数据加粗", 8, true));
					add(new PrintItemObj("打印数据左对齐测试", 8, false, ALIGN.LEFT));
					add(new PrintItemObj("打印数据左对齐测试", 8, false, ALIGN.LEFT));
					add(new PrintItemObj("打印数据左对齐测试", 8, false, ALIGN.LEFT));
					add(new PrintItemObj("放大加粗居中对齐测试", 16, true, ALIGN.CENTER));
					add(new PrintItemObj("打印数据居中对齐测试", 8, false, ALIGN.CENTER));
					add(new PrintItemObj("打印数据居中对齐测试", 8, false, ALIGN.CENTER));
					add(new PrintItemObj("打印数据居中对齐测试", 8, false, ALIGN.CENTER));
					add(new PrintItemObj("打印数据右对齐测试", 8, false, ALIGN.RIGHT));
					add(new PrintItemObj("打印数据右对齐测试", 8, false, ALIGN.RIGHT));
					add(new PrintItemObj("打印数据右对齐测试", 8, false, ALIGN.RIGHT));
					add(new PrintItemObj("打印数据下划线", 8, false, ALIGN.LEFT, true));
					add(new PrintItemObj("打印数据下划线", 8, false, ALIGN.LEFT, true));
					add(new PrintItemObj("打印数据下划线", 8, false, ALIGN.LEFT, true));
					add(new PrintItemObj("打印数据不换行测试", 8, false, ALIGN.LEFT, false, false));
					add(new PrintItemObj("打印数据不换行测试", 8, false, ALIGN.LEFT, false, false));
					add(new PrintItemObj("打印数据不换行测试", 8, false, ALIGN.LEFT, false, false));
					add(new PrintItemObj("打印数据行间距测试", 8, false, ALIGN.LEFT, false, true, 40));
					add(new PrintItemObj("打印数据行间距测试", 8, false, ALIGN.LEFT, false, true, 40));
					add(new PrintItemObj("打印数据行间距测试", 8, false, ALIGN.LEFT, false, true, 40));
					add(new PrintItemObj("打印数据字符间距测试", 8, false, ALIGN.LEFT, false, true, 29, 25));
					add(new PrintItemObj("打印数据字符间距测试", 8, false, ALIGN.LEFT, false, true, 29, 25));
					add(new PrintItemObj("打印数据字符间距测试", 8, false, ALIGN.LEFT, false, true, 29, 25));
					add(new PrintItemObj("打印数据左边距测试", 8, false, ALIGN.LEFT, false, true, 29, 0, 40));
					add(new PrintItemObj("打印数据左边距测试", 8, false, ALIGN.LEFT, false, true, 29, 0, 40));
					add(new PrintItemObj("打印数据左边距测试", 8, false, ALIGN.LEFT, false, true, 29, 0, 40));
					add(new PrintItemObj(" "));
					add(new PrintItemObj(" "));
					add(new PrintItemObj(" "));
				}
			}, new AidlPrinterListener.Stub() {

				@Override
				public void onPrintFinish() throws RemoteException {
					showMessage("打印完成");
				}

				@Override
				public void onError(int arg0, String arg1) throws RemoteException {
					showMessage("打印位图失败:" + arg1);
				}
			});
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 打印繁体文本
	 * @param v
	 */
	@SuppressWarnings("serial")
	public void printTraditionalText(View v) {
		try {
			printerDev.printText_Traditional(new ArrayList<PrintItemObj>() {
				{
					add(new PrintItemObj("默認打印數據測試"));
					add(new PrintItemObj("默認打印數據測試"));
					add(new PrintItemObj("默認打印數據測試"));
					add(new PrintItemObj("默認打印數據測試-16", 16));
					add(new PrintItemObj("默認打印數據測試-16", 16));
					add(new PrintItemObj("默認打印數據測試-16", 16));
					add(new PrintItemObj("默認打印數據測試-24", 24));
					add(new PrintItemObj("默認打印數據測試-24", 24));
					add(new PrintItemObj("默認打印數據測試-24", 24));
					add(new PrintItemObj("默認打印數據測試-32", 32));
					add(new PrintItemObj("默認打印數據測試-32", 32));
					add(new PrintItemObj("默認打印數據測試-32", 32));
					add(new PrintItemObj("默認打印數據測試-48", 48));
					add(new PrintItemObj("默認打印數據測試-48", 48));
					add(new PrintItemObj("默認打印數據測試-48", 48));
					add(new PrintItemObj("打印數據加粗", 8, true));
					add(new PrintItemObj("打印數據加粗", 8, true));
					add(new PrintItemObj("打印數據加粗", 8, true));
					add(new PrintItemObj("打印數據左對齊測試", 8, false, ALIGN.LEFT));
					add(new PrintItemObj("打印數據左對齊測試", 8, false, ALIGN.LEFT));
					add(new PrintItemObj("打印數據左對齊測試", 8, false, ALIGN.LEFT));
					add(new PrintItemObj("放大加粗居中對齊測試", 16, true, ALIGN.CENTER));
					add(new PrintItemObj("打印數據居中對齊測試", 8, false, ALIGN.CENTER));
					add(new PrintItemObj("打印數據居中對齊測試", 8, false, ALIGN.CENTER));
					add(new PrintItemObj("打印數據居中對齊測試", 8, false, ALIGN.CENTER));
					add(new PrintItemObj("打印數據右對齊測試", 8, false, ALIGN.RIGHT));
					add(new PrintItemObj("打印數據右對齊測試", 8, false, ALIGN.RIGHT));
					add(new PrintItemObj("打印數據右對齊測試", 8, false, ALIGN.RIGHT));
					add(new PrintItemObj("打印數據下劃線", 8, false, ALIGN.LEFT, true));
					add(new PrintItemObj("打印數據下劃線", 8, false, ALIGN.LEFT, true));
					add(new PrintItemObj("打印數據下劃線", 8, false, ALIGN.LEFT, true));
					add(new PrintItemObj("打印數據不換行測試", 8, false, ALIGN.LEFT, false, false));
					add(new PrintItemObj("打印數據不換行測試", 8, false, ALIGN.LEFT, false, false));
					add(new PrintItemObj("打印數據不換行測試", 8, false, ALIGN.LEFT, false, false));
					add(new PrintItemObj("打印數據行間距測試", 8, false, ALIGN.LEFT, false, true, 40));
					add(new PrintItemObj("打印數據行間距測試", 8, false, ALIGN.LEFT, false, true, 40));
					add(new PrintItemObj("打印數據行間距測試", 8, false, ALIGN.LEFT, false, true, 40));
					add(new PrintItemObj("打印數據字符間距測試", 8, false, ALIGN.LEFT, false, true, 29, 25));
					add(new PrintItemObj("打印數據字符間距測試", 8, false, ALIGN.LEFT, false, true, 29, 25));
					add(new PrintItemObj("打印數據字符間距測試", 8, false, ALIGN.LEFT, false, true, 29, 25));
					add(new PrintItemObj("打印數據字符間距測試", 8, false, ALIGN.LEFT, false, true, 29, 0, 40));
					add(new PrintItemObj("打印數據左邊距測試", 8, false, ALIGN.LEFT, false, true, 29, 0, 40));
					add(new PrintItemObj("打印數據左邊距測試", 8, false, ALIGN.LEFT, false, true, 29, 0, 40));
					add(new PrintItemObj(" "));
					add(new PrintItemObj(" "));
					add(new PrintItemObj(" "));
				}
			}, new AidlPrinterListener.Stub() {

				@Override
				public void onPrintFinish() throws RemoteException {
					showMessage("打印完成");
				}

				@Override
				public void onError(int arg0, String arg1) throws RemoteException {
					showMessage("打印位图失败:" + arg1);
				}
			});
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 打印位图
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午2:39:33
	 */
	public void printBitmap(View v) {
		try {
			InputStream ins = this.getAssets().open("bmp/canvas.bmp");
			Bitmap bmp = BitmapFactory.decodeStream(ins);
			this.printerDev.printBmp(0, bmp.getWidth(), bmp.getHeight(), bmp,
					new AidlPrinterListener.Stub() {

						@Override
						public void onPrintFinish() throws RemoteException {
							showMessage("打印位图成功");
						}

						@Override
						public void onError(int arg0, String arg1) throws RemoteException {
							showMessage("打印位图失败:" + arg1);
						}
					});
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private class PrintStateChangeListener extends AidlPrinterListener.Stub {

		@Override
		public void onError(int arg0, String arg1) throws RemoteException {
			showMessage("打印位图失败:" + arg1);
		}

		@Override
		public void onPrintFinish() throws RemoteException {
			showMessage("数据打印成功");
		}

	}

	/**
	 * 打印条码
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午3:02:21
	 */
	public void printBarCode(View v) {
		try {
			this.printerDev.printBarCode(-1, 162, 18, 65, "123456789",
					new PrintStateChangeListener());
			// this.printerDev.printBarCode(-1, 162, 18, 66, "123456789", new
			// PrintStateChangeListener());
			// this.printerDev.printBarCode(-1, 162, 18, 67, "123456789", new
			// PrintStateChangeListener());
			// this.printerDev.printBarCode(-1, 162, 18, 68, "123456789", new
			// PrintStateChangeListener());
			// this.printerDev.printBarCode(-1, 162, 18, 69, "123456789", new
			// PrintStateChangeListener());
			// this.printerDev.printBarCode(-1, 162, 18, 70, "123456789", new
			// PrintStateChangeListener());
			// this.printerDev.printBarCode(-1, 162, 18, 71, "123456789", new
			// PrintStateChangeListener());
			// this.printerDev.printBarCode(-1, 162, 18, 72, "123456789", new
			// PrintStateChangeListener());
			// this.printerDev.printBarCode(-1, 162, 18, 73, "123456789", new
			// PrintStateChangeListener());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 设置打印灰度
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午3:02:27
	 */
	private int gray = 1;

	public void setPrintGray(View v) {
		try {
			showMessage("打印灰度设置为:" + gray);
			this.printerDev.setPrinterGray(gray);
			gray++;
			if (gray == 5) {
				gray = 1;
			}
			// printText(null);
			// showMessage("打印灰度设置为1打印");
			// this.printerDev.setPrinterGray(0x01);
			// printText(null);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

}
