package com.example.test;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dc.p92pos.aidl.pinpad.AidlPinpad;
import com.dc.p92pos.aidl.pinpad.GetPinListener;
import com.dc.p92pos.data.PinpadConstant;
import com.example.util.Debug;
import com.example.util.HexUtil;
import com.dynamicode.p92servicetest.R;

/**
 * 密码键盘设备测试
 * 
 * @author Administrator
 * 
 */
public class PinPadActivity extends BaseTestActivity {

	private AidlPinpad pinpad = null; // 密码键盘接口
	private Context context;

	@SuppressLint("HandlerLeak")
	private Handler pinHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			Debug.d("msg.obj = " + msg.obj);
			if (msg.obj != null) {
				showMessage(msg.obj.toString());
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.pinpadtest);
		super.onCreate(savedInstanceState);

		context = PinPadActivity.this;
	}

	/**
	 * PIN输入监听器
	 * 
	 * @author dynamicode
	 * 
	 */
	private class MyGetPinListener extends GetPinListener.Stub {
		@Override
		public void onStopGetPin() throws RemoteException {
			// showMessage("您取消了PIN输入");
			pinHandler.obtainMessage(0x00, "您取消了PIN输入").sendToTarget();
		}

		@Override
		public void onInputKey(int arg0, String arg1) throws RemoteException {
			Debug.d("arg0 = " + arg0);
			pinHandler.obtainMessage(0x00,
					getStar(arg0) + (arg1 == null ? "" : arg1)).sendToTarget();
		}

		@Override
		public void onError(int arg0) throws RemoteException {
			pinHandler.obtainMessage(0x00, "读取PIN输入错误，错误码" + arg0)
					.sendToTarget();
		}

		@Override
		public void onConfirmInput(byte[] arg0) throws RemoteException {
			pinHandler.obtainMessage(
					0x00,
					"PIN输入成功"
							+ (null == arg0 ? ",您输入了空密码" : ",PIN为"
									+ HexUtil.bcd2str(arg0))).sendToTarget();
		}

		@Override
		public void onCancelKeyPress() throws RemoteException {
			// showMessage("您按下了取消键");
			pinHandler.obtainMessage(0x00, "您取消了PIN输入").sendToTarget();
		}
	}

	/**
	 * 乱序键盘 PIN
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午8:39:35
	 */
	public void inputPin(View v) {
		final Bundle bundle = new Bundle();
		bundle.putInt("wkeyid", 0x00);
		bundle.putInt("keytype", 0x00);
		bundle.putByteArray("random", null);
		bundle.putInt("inputtimes", 1);
		bundle.putInt("minlength", 0);
		bundle.putInt("maxlength", 14);
		bundle.putString("pan", "0000000000000000");
		bundle.putString("tips", "RMB:2000.00");
		bundle.putInt("keyorder", 0);

		new Thread() {
			public void run() {
				try {
					pinpad.getPin(bundle, new MyGetPinListener());
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			};
		}.start();
	}

	/**
	 * 顺序键盘 PIN
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午8:39:35
	 */
	public void inputPin2(View v) {
		final Bundle bundle = new Bundle();
		bundle.putInt("wkeyid", 0x00);
		bundle.putInt("keytype", 0x00);
		bundle.putByteArray("random", null);
		bundle.putInt("inputtimes", 1);
		bundle.putInt("minlength", 0);
		bundle.putInt("maxlength", 14);
		bundle.putString("pan", "0000000000000000");
		bundle.putString("tips", "RMB:2000.00");
		bundle.putInt("keyorder", 1);

		new Thread() {
			public void run() {
				try {
					pinpad.getPin(bundle, new MyGetPinListener());
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			};
		}.start();
	}

	/**
	 * 注入PIK
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午9:33:29
	 */
	public void injectPIK(View v) {
		loadWorkKey(PinpadConstant.WKeyType.WKEY_TYPE_PIK, 0, 0,
				"7BB878C51F2875B17BB878C51F2875B1", "");
	}

	/**
	 * 注入TDK
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午9:38:18
	 */
	public void injectTDK(View v) {
		loadWorkKey(PinpadConstant.WKeyType.WKEY_TYPE_TDK, 0, 0,
				"7BB878C51F2875B17BB878C51F2875B2", "");
	}

	/**
	 * 注入MAK
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午9:38:25
	 */
	public void injectMAK(View v) {
		loadWorkKey(PinpadConstant.WKeyType.WKEY_TYPE_MAK, 0, 0,
				"7BB878C51F2875B17BB878C51F2875B3", "");
	}

	public void loadWorkKey(final int keyType, int masterKeyId, int wkeyid,
			String keyvalue, String checkvalue) {
		LayoutInflater layoutInflater = LayoutInflater.from(context);
		View input_mak = layoutInflater.inflate(R.layout.input_four, null);

		final TextView text_first = (TextView) input_mak
				.findViewById(R.id.text_first);
		text_first.setText("主密钥索引：");
		final EditText edit_first = (EditText) input_mak
				.findViewById(R.id.edit_first);
		edit_first.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		edit_first.setText("" + masterKeyId);
		final TextView text_second = (TextView) input_mak
				.findViewById(R.id.text_second);
		text_second.setText("工作密钥索引：");
		final EditText edit_second = (EditText) input_mak
				.findViewById(R.id.edit_second);
		edit_second.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		edit_second.setText("" + wkeyid);
		final TextView text_third = (TextView) input_mak
				.findViewById(R.id.text_third);
		text_third.setText("密钥值：");
		final EditText edit_third = (EditText) input_mak
				.findViewById(R.id.edit_third);
		edit_third.setText(keyvalue);
		final TextView text_forth = (TextView) input_mak
				.findViewById(R.id.text_forth);
		text_forth.setText("校验值：");
		final EditText edit_forth = (EditText) input_mak
				.findViewById(R.id.edit_forth);
		edit_forth.setText(checkvalue);

		AlertDialog.Builder dialog1 = new AlertDialog.Builder(context);

		switch (keyType) {
		case 1:
			dialog1.setTitle("注入PIK：");
			break;
		case 2:
			dialog1.setTitle("注入TDK：");
			break;
		case 3:
			dialog1.setTitle("注入MAK：");
			break;

		default:
			break;
		}

		dialog1.setIcon(android.R.drawable.ic_dialog_info);
		dialog1.setView(input_mak);
		dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				try {
					if (edit_first.getText().length() == 0
							|| edit_first.getText().length() > 2) {
						showMessage("主密钥索引有误");
					} else if (edit_second.getText().length() == 0
							|| edit_second.getText().length() > 2) {
						showMessage("工作密钥索引有误");
					} else {
						boolean flag = pinpad.loadWorkKey(
								keyType,
								Integer.parseInt(edit_first.getText()
										.toString()),
								Integer.parseInt(edit_second.getText()
										.toString()),
								HexUtil.hexStringToByte(edit_third.getText()
										.toString()),
								(edit_forth.getText().toString().length() == 0 ? null
										: HexUtil.hexStringToByte(edit_forth
												.getText().toString())));

						String msg = "";
						switch (keyType) {
						case 1:
							msg = "PIK ";
							break;
						case 2:
							msg = "TDK ";
							break;
						case 3:
							msg = "MAK ";
							break;

						default:
							break;
						}
						if (flag) {
							showMessage(msg + "注入成功");
						} else {
							showMessage(msg + "注入失败");
						}
					}
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					showMessage("注入出错");
				}
			}
		});
		dialog1.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog1.show();
	}

	/**
	 * 执行MAC计算
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午9:48:33
	 */
	public void getMac(View v) {
		LayoutInflater layoutInflater = LayoutInflater.from(context);
		View input_mak = layoutInflater.inflate(R.layout.input_three, null);

		final TextView text_first = (TextView) input_mak
				.findViewById(R.id.text_first);
		text_first.setText("MAK索引：");
		final EditText edit_first = (EditText) input_mak
				.findViewById(R.id.edit_first);
		edit_first.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		edit_first.setText("0");
		final TextView text_second = (TextView) input_mak
				.findViewById(R.id.text_second);
		text_second.setText("待计算MAC的数据：");
		final EditText edit_second = (EditText) input_mak
				.findViewById(R.id.edit_second);
		edit_second
				.setText("02007024048020C0989519622700013096008915700000000000000000010000033010002200376227000130960089157D4208520970102000003132303031373931383232313231303037343230303035313536F2A22617F1DD0FAE2600000000000000001230643930313538313037393700063031303030300012303030303031303030303033");
		final TextView text_third = (TextView) input_mak
				.findViewById(R.id.text_third);
		text_third.setText("随机数：");
		final EditText edit_third = (EditText) input_mak
				.findViewById(R.id.edit_third);
		edit_third.setText("0001020304050607");

		AlertDialog.Builder dialog1 = new AlertDialog.Builder(context);
		dialog1.setTitle("执行MAC计算：");
		dialog1.setIcon(android.R.drawable.ic_dialog_info);
		dialog1.setView(input_mak);
		dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

				if (edit_first.getText().length() == 0
						|| edit_first.getText().length() > 2) {
					showMessage("MAK索引有误");
					return;
				}
				int retCode = -1;
				byte[] random = (edit_third.getText().toString().length() == 0 ? null
						: HexUtil.hexStringToByte(edit_third.getText()
								.toString()));

				Bundle bundle = new Bundle();
				bundle.putInt("wkeyid",
						Integer.parseInt(edit_first.getText().toString()));
				bundle.putByteArray("data", HexUtil.hexStringToByte(edit_second
						.getText().toString()));
				bundle.putByteArray("random", null);
				bundle.putInt("type", 0x00);
				byte[] mac = new byte[8];
				try {
					retCode = pinpad.getMac(bundle, mac);
					if (retCode != 0x00) {
						showMessage("mac计算失败，错误码为" + retCode);
					} else {
						showMessage("不含随机数，x919执行MAC计算成功，值为"
								+ HexUtil.bcd2str(mac));
					}
					bundle.putInt("type", 0x01);
					retCode = pinpad.getMac(bundle, mac);
					if (retCode != 0x00) {
						showMessage("mac计算失败，错误码为" + retCode);
					} else {
						showMessage("不含随机数，银联ECB执行MAC计算成功，值为"
								+ HexUtil.bcd2str(mac));
					}

					bundle.putInt("type", 0x00);
					bundle.putByteArray("random", random);
					retCode = pinpad.getMac(bundle, mac);
					if (retCode != 0x00) {
						showMessage("mac计算失败，错误码为" + retCode);
					} else {
						showMessage("含随机数,x919执行MAC计算成功，值为"
								+ HexUtil.bcd2str(mac));
					}
					bundle.putInt("type", 0x01);
					retCode = pinpad.getMac(bundle, mac);
					if (retCode != 0x00) {
						showMessage("mac计算失败，错误码为" + retCode);
					} else {
						showMessage("含随机数,银联ECB执行MAC计算成功，值为"
								+ HexUtil.bcd2str(mac));
					}
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		dialog1.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog1.show();
	}

	/**
	 * 磁道数据加密
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午9:48:54
	 */
	public void encryptData(View v) {
		LayoutInflater layoutInflater = LayoutInflater.from(context);
		View input_four = layoutInflater.inflate(R.layout.input_four, null);

		final TextView text_first = (TextView) input_four
				.findViewById(R.id.text_first);
		text_first.setText("秘钥索引：");
		final EditText edit_first = (EditText) input_four
				.findViewById(R.id.edit_first);
		edit_first.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		edit_first.setText("0");
		final TextView text_second = (TextView) input_four
				.findViewById(R.id.text_second);
		text_second.setText("mode（0：ECB，1：CBC）：");
		final EditText edit_second = (EditText) input_four
				.findViewById(R.id.edit_second);
		edit_second.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		edit_second.setText("0");
		final TextView text_third = (TextView) input_four
				.findViewById(R.id.text_third);
		text_third.setText("随机数：");
		final EditText edit_third = (EditText) input_four
				.findViewById(R.id.edit_third);
		edit_third.setText("B3DB4EC577B4886D");
		final TextView text_forth = (TextView) input_four
				.findViewById(R.id.text_forth);
		text_forth.setText("待加密数据：");
		final EditText edit_forth = (EditText) input_four
				.findViewById(R.id.edit_forth);
		edit_forth.setText("246222600110029125619D49121209010776570090000000");

		AlertDialog.Builder dialog1 = new AlertDialog.Builder(context);
		dialog1.setTitle("磁道数据加密：");
		dialog1.setIcon(android.R.drawable.ic_dialog_info);
		dialog1.setView(input_four);
		dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

				if (edit_first.getText().length() == 0
						|| edit_first.getText().length() > 2) {
					showMessage("密钥索引有误");
				} else if (edit_second.getText().length() != 1
						|| !(edit_second.getText().toString().equals("0") || edit_second
								.getText().toString().equals("1"))) {
					showMessage("mode有误");
				} else {
					byte[] result = new byte[120];
					byte[] random = (edit_third.getText().toString().length() == 0 ? null
							: HexUtil.hexStringToByte(edit_third.getText()
									.toString()));
					try {
						int retCode = pinpad.encryptByTdk(Integer
								.parseInt(edit_first.getText().toString()),
								(byte) Integer.parseInt(edit_second.getText()
										.toString()), random, HexUtil
										.hexStringToByte(edit_forth.getText()
												.toString()), result);
						if (retCode == 0x00) {
							showMessage("数据加密成功，值为" + HexUtil.bcd2str(result));
						} else {
							showMessage("数据加密失败,错误码为" + retCode);
						}
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		dialog1.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog1.show();
	}

	/**
	 * 注入主密钥明文
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午10:03:25
	 */
	public void injectKEK(View v) {
		LayoutInflater layoutInflater = LayoutInflater.from(context);
		View input_key = layoutInflater.inflate(R.layout.input_two, null);

		final TextView text_first = (TextView) input_key
				.findViewById(R.id.text_first);
		text_first.setText("秘钥索引：");
		final EditText edit_first = (EditText) input_key
				.findViewById(R.id.edit_first);
		edit_first.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		edit_first.setText("0");
		final TextView text_second = (TextView) input_key
				.findViewById(R.id.text_second);
		text_second.setText("主秘钥：");
		final EditText edit_second = (EditText) input_key
				.findViewById(R.id.edit_second);
		edit_second.setText("12345678123456781234567812345678");

		AlertDialog.Builder dialog1 = new AlertDialog.Builder(context);
		dialog1.setTitle("注入主密钥：");
		dialog1.setIcon(android.R.drawable.ic_dialog_info);
		dialog1.setView(input_key);
		dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

				if (edit_first.getText().length() == 0
						|| edit_first.getText().length() > 2) {
					showMessage("秘钥索引有误");
					return;
				}
				boolean flag;
				try {
					flag = pinpad.loadMainkey(Integer.parseInt(edit_first
							.getText().toString()), HexUtil
							.hexStringToByte(edit_second.getText().toString()),
							null);
					if (flag) {
						showMessage("主密钥灌装成功");
					} else {
						showMessage("主密钥灌装失败");
					}
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		dialog1.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog1.show();
	}

	/**
	 * 主密钥密文注入
	 * 
	 * @param view
	 */
	public void injectKEKEncode(View view) {
		LayoutInflater layoutInflater = LayoutInflater.from(context);
		View input_key = layoutInflater.inflate(R.layout.input_two, null);

		final TextView text_first = (TextView) input_key
				.findViewById(R.id.text_first);
		text_first.setText("秘钥索引：");
		final EditText edit_first = (EditText) input_key
				.findViewById(R.id.edit_first);
		edit_first.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		edit_first.setText("0");
		final TextView text_second = (TextView) input_key
				.findViewById(R.id.text_second);
		text_second.setText("主秘钥：");
		final EditText edit_second = (EditText) input_key
				.findViewById(R.id.edit_second);
		edit_second.setText("950973182317F80B950973182317F80B");

		AlertDialog.Builder dialog1 = new AlertDialog.Builder(context);
		dialog1.setTitle("注入主密钥：");
		dialog1.setIcon(android.R.drawable.ic_dialog_info);
		dialog1.setView(input_key);
		dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

				if (edit_first.getText().length() == 0
						|| edit_first.getText().length() > 2) {
					showMessage("秘钥索引有误");
					return;
				}
				boolean flag;
				try {
					int mode = 0x00;
					flag = pinpad.loadEncryptMainkey(0, Integer.parseInt(edit_first.getText().toString()), 
							mode, HexUtil.hexStringToByte(edit_second.getText().toString()),
							null);
					if (flag) {
						showMessage("主密钥灌装成功");
					} else {
						showMessage("主密钥灌装失败");
					}
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		dialog1.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog1.show();
	}

	/**
	 * TEK密钥明文注入
	 * 
	 * @param view
	 */
	public void injectTEK(View view) {
		LayoutInflater layoutInflater = LayoutInflater.from(context);
		View input_key = layoutInflater.inflate(R.layout.input_two, null);

		final TextView text_first = (TextView) input_key
				.findViewById(R.id.text_first);
		text_first.setText("秘钥索引：");
		final EditText edit_first = (EditText) input_key
				.findViewById(R.id.edit_first);
		edit_first.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
		edit_first.setText("0");
		final TextView text_second = (TextView) input_key
				.findViewById(R.id.text_second);
		text_second.setText("TEK秘钥：");
		final EditText edit_second = (EditText) input_key
				.findViewById(R.id.edit_second);
		edit_second.setText("11111111111111111111111111111111");

		AlertDialog.Builder dialog1 = new AlertDialog.Builder(context);
		dialog1.setTitle("注入TEK秘钥：");
		dialog1.setIcon(android.R.drawable.ic_dialog_info);
		dialog1.setView(input_key);
		dialog1.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

				if (edit_first.getText().length() == 0
						|| edit_first.getText().length() > 2) {
					showMessage("秘钥索引有误");
					return;
				}
				boolean flag;
				try {
					flag = pinpad.loadTEK(Integer.parseInt(edit_first.getText()
							.toString()), HexUtil.hexStringToByte(edit_second
							.getText().toString()), null);
					if (flag) {
						showMessage("TEK秘钥灌装成功");
					} else {
						showMessage("TEK秘钥灌装失败");
					}
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		dialog1.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		dialog1.show();
	}

	/**
	 * 获取随机数
	 * 
	 * @param v
	 * @createtor：Administrator
	 * @date:2015-8-4 下午10:01:26
	 */
	public void getRandom(View v) {
		try {
			byte[] data = pinpad.getRandom();
			if (null != data) {
				showMessage("获取随机数成功" + HexUtil.bcd2str(data));
			} else {
				showMessage("获取随机数失败");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		if (null != serviceManager) {
			try {
				pinpad = AidlPinpad.Stub.asInterface(serviceManager
						.getPinPad(PinpadConstant.PinpadId.BUILTIN)); // 默认内置密码键盘
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * 获取指定长度的*
	 * 
	 * @param len
	 * @return
	 * @createtor：Administrator
	 * @date:2015-8-4 下午9:13:40
	 */
	public String getStar(int len) {
		String str = "";
		while (len > 0) {
			str += "*";
			len--;
		}
		return str;
	}

}
