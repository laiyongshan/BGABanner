package com.example.test;

import java.math.RoundingMode;
import java.text.DecimalFormat;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dc.p92pos.aidl.AidlDeviceService;
import com.dynamicode.p92servicetest.R;

/**
 * 输入金额键盘
 * 
 * @author Administrator
 * 
 */
public class SetMoneyActivity extends BaseTestActivity {

	public static final String TAG = "DigitPasswordKeyPad";
	private int length = 9;
	private LinearLayout llBlank;
	private Button digitkeypad_1;
	private Button digitkeypad_2;
	private Button digitkeypad_3;
	private Button digitkeypad_4;
	private Button digitkeypad_5;
	private Button digitkeypad_6;
	private Button digitkeypad_7;
	private Button digitkeypad_8;
	private Button digitkeypad_9;
	private Button digitkeypad_0;
	private Button digitkeypad_ok;
	private Button digitkeypad_cancel;
	private ImageButton digitkeypad_del;
	private TextView textMoney;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.setContentView(R.layout.input_keyboard);
		super.onCreate(savedInstanceState);

		textMoney = (TextView) findViewById(R.id.textview_money);

		// 初始化 对象
		digitkeypad_1 = (Button) findViewById(R.id.digitkeypad_1);
		digitkeypad_2 = (Button) findViewById(R.id.digitkeypad_2);
		digitkeypad_3 = (Button) findViewById(R.id.digitkeypad_3);
		digitkeypad_4 = (Button) findViewById(R.id.digitkeypad_4);
		digitkeypad_5 = (Button) findViewById(R.id.digitkeypad_5);
		digitkeypad_6 = (Button) findViewById(R.id.digitkeypad_6);
		digitkeypad_7 = (Button) findViewById(R.id.digitkeypad_7);
		digitkeypad_8 = (Button) findViewById(R.id.digitkeypad_8);
		digitkeypad_9 = (Button) findViewById(R.id.digitkeypad_9);
		digitkeypad_0 = (Button) findViewById(R.id.digitkeypad_0);
		digitkeypad_ok = (Button) findViewById(R.id.digitkeypad_ok);
		digitkeypad_cancel = (Button) findViewById(R.id.digitkeypad_cancel);
		digitkeypad_del = (ImageButton) findViewById(R.id.digitkeypad_del);
		llBlank = (LinearLayout) findViewById(R.id.ll_blank);

		// 添加点击事件
		DigitPasswordKeypadOnClickListener dkol = new DigitPasswordKeypadOnClickListener();
		digitkeypad_1.setOnClickListener(dkol);
		digitkeypad_2.setOnClickListener(dkol);
		digitkeypad_3.setOnClickListener(dkol);
		digitkeypad_4.setOnClickListener(dkol);
		digitkeypad_5.setOnClickListener(dkol);
		digitkeypad_6.setOnClickListener(dkol);
		digitkeypad_7.setOnClickListener(dkol);
		digitkeypad_8.setOnClickListener(dkol);
		digitkeypad_9.setOnClickListener(dkol);
		digitkeypad_0.setOnClickListener(dkol);
		digitkeypad_del
				.setOnClickListener(new DigitPasswordKeypadFinshOnClikcListener());
		digitkeypad_ok
				.setOnClickListener(new DigitPasswordKeypadFinshOnClikcListener());
		digitkeypad_cancel
				.setOnClickListener(new DigitPasswordKeypadFinshOnClikcListener());
		llBlank.setOnClickListener(new DigitPasswordKeypadFinshOnClikcListener());
	}

	private class DigitPasswordKeypadFinshOnClikcListener implements
			OnClickListener {

		@Override
		public void onClick(View v) {
			int viewId = v.getId();

			String moneyString = textMoney.getText().toString();

			if (viewId == R.id.digitkeypad_ok) {
				Intent intent = new Intent(SetMoneyActivity.this, PbocActivity.class);
				intent.putExtra("money", moneyString);
				SetMoneyActivity.this.setResult(RESULT_OK, intent);
				SetMoneyActivity.this.finish();
			} else if (viewId == R.id.digitkeypad_cancel) {
				SetMoneyActivity.this.finish();
			} else if (viewId == R.id.digitkeypad_del) {
				double money = Double.parseDouble(moneyString);
				money = money / 10.0;
				money = getMoney(money);
				textMoney.setText(new DecimalFormat("0.00").format(money));
			}
		}
	}

	private double getMoney(double data) {
		DecimalFormat formater = new DecimalFormat();
		formater.setMaximumFractionDigits(2);
		formater.setGroupingSize(0);
		formater.setRoundingMode(RoundingMode.FLOOR);
		return Double.parseDouble(formater.format(data));
	}

	private void btn_Click(String strKey) {
		String moneyString = textMoney.getText().toString();
		Log.e("btn_Click", "textMoney = " + moneyString + " strKey = " + strKey);

		if (moneyString.length() < length) {
			double money = Double.parseDouble(moneyString);
			money = money * 10.00 + Integer.parseInt(strKey) * 0.01;
			money = getMoney(money);
			textMoney.setText(new DecimalFormat("0.00").format(money));
		}
	}

	private class DigitPasswordKeypadOnClickListener implements OnClickListener {

		@Override
		public void onClick(View v) {
			int viewId = v.getId();

			switch (viewId) {
			case R.id.digitkeypad_1:
				btn_Click(digitkeypad_1.getText().toString());
				break;
			case R.id.digitkeypad_2:
				btn_Click(digitkeypad_2.getText().toString());
				break;
			case R.id.digitkeypad_3:
				btn_Click(digitkeypad_3.getText().toString());
				break;
			case R.id.digitkeypad_4:
				btn_Click(digitkeypad_4.getText().toString());
				break;
			case R.id.digitkeypad_5:
				btn_Click(digitkeypad_5.getText().toString());
				break;
			case R.id.digitkeypad_6:
				btn_Click(digitkeypad_6.getText().toString());
				break;
			case R.id.digitkeypad_7:
				btn_Click(digitkeypad_7.getText().toString());
				break;
			case R.id.digitkeypad_8:
				btn_Click(digitkeypad_8.getText().toString());
				break;
			case R.id.digitkeypad_9:
				btn_Click(digitkeypad_9.getText().toString());
				break;
			case R.id.digitkeypad_0:
				btn_Click(digitkeypad_0.getText().toString());
				break;
			}
		}
	}

	@Override
	public void onDeviceConnected(AidlDeviceService serviceManager) {
		// TODO Auto-generated method stub

	}
}
