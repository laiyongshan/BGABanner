package com.example.util;

import android.util.Log;

public class Debug
{

  public static void d(String msg)
  {
    Log.d("Debug", msg);
  }
  
  public static void v(String msg)
  {
    Log.v("Debug", msg);
  }
  
  public static void i(String msg)
  {
    Log.i("Debug", msg);
  }
  
  public static void e(String msg)
  {
    Log.e("Debug", msg);
  }
  
  public static void w(String msg)
  {
    Log.w("Debug", msg);
  }
}