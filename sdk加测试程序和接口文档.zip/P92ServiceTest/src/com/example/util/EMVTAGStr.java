package com.example.util;

public class EMVTAGStr {
	
    public static final String EMVTAG_APP_PAN = combine(0x5A);
    public static final String EMVTAG_APP_PAN_SN = combine(0x5F,0x34);
    public static final String EMVTAG_TRACK2 = combine(0x57);
    public static final String EMVTAG_AC = combine(0x9F,0x26);
    public static final String EMVTAG_CID = combine(0x9F,0x27);
    public static final String EMVTAG_IAD  = combine(0x9F,0x10);        //Issuer Application Data
    public static final String EMVTAG_RND_NUM  = combine(0x9F,0x37);        //Random Number
    public static final String EMVTAG_ATC  = combine(0x9F,0x36);
    public static final String EMVTAG_TVR  = combine(0x95);
    public static final String EMVTAG_TXN_DATE  = combine(0x9A);
    public static final String EMVTAG_TXN_TYPE  = combine(0x9C);
    public static final String EMVTAG_AMOUNT = combine(0x9F,0x02);
    public static final String EMVTAG_CURRENCY  = combine(0x5F,0x2A);
    public static final String EMVTAG_AIP  = combine(0x82);
    public static final String EMVTAG_COUNTRY_CODE  = combine(0x9F,0x1A);
    public static final String EMVTAG_OTHER_AMOUNT  = combine(0x9F,0x03);
    public static final String EMVTAG_TERM_CAP    = combine(0x9F,0x33);
    public static final String EMVTAG_CVM  = combine(0x9F,0x34);
    public static final String EMVTAG_TERM_TYPE = combine(0x9F,0x35);
    public static final String EMVTAG_IFD  = combine(0x9F,0x1E);
    public static final String EMVTAG_DF      = combine(0x84);
    public static final String EMVTAG_APP_VER  = combine(0x9F,0x09);
    public static final String EMVTAG_TXN_SN      = combine(0x9F,0x41);
    public static final String EMVTAG_CARD_ID  = combine(0x9F,0x63);
    public static final String EMVTAG_AID  = combine(0x4F);
    public static final String EMVTAG_SCRIPT_RESULT  = combine(0xDF,0x31);
    public static final String EMVTAG_ARC  = combine(0x8A);
    public static final String EMVTAG_ISS_COUNTRY_CODE = combine(0x5F,0x28);
    public static final String EMVTAG_EC_AUTH_CODE  = combine(0x9F,0x74);
    public static final String EMVTAG_EC_BALANCE = combine(0x9F,0x79);
    public static final String EMVTAG_TSI = combine(0x9B);
    public static final String EMVTAG_APP_LABEL = combine(0x50);
    public static final String EMVTAG_APP_NAME = combine(0x9F,0x12);
    public static final String EMVTAG_CONTACT_NAME = combine(0x9F,0x4E); // 商户名称
    
    private static String combine(int...bytes) {
        String tag = "";
        for(int i = 0;i < bytes.length;i++)
        {
            tag += HexUtil.byteToHex((byte)bytes[i]);
        }
        return tag;
    }
    
    /**
     * 读取卡信息
     * @return
     * @throws Exception
     */
    public static String[] getgetF55Tag_CardInfo() throws Exception{
        String[] tags={            
        combine(0x5A),
        combine(0x57),
        combine(0x5F,0x24),
        combine(0x5F,0x34),
        combine(0x9F,0x06),
        combine(0x9F,0x79),
        combine(0x98),
        combine(0x9B)
        };
        return tags;       
    }
    
    /**
     * 读取55域Tag信息
     * @return
     * @throws Exception
     */
//    public static String[] getF55Tag() throws Exception{
//    	
//    	if (TransType.TransType_Currect == TransType.BalanceQuery 
//    			|| TransType.TransType_Currect == TransType.Trans 
//    			|| TransType.TransType_Currect == TransType.PreAuth 
//    			|| TransType.TransType_Currect == TransType.E_Cash_CashCharge
//    			|| TransType.TransType_Currect == TransType.E_Cash_SpecifiedAccountQuancun
//    			|| TransType.TransType_Currect == TransType.E_Cash_NonSpecifiedAccountQuancun
//				|| TransType.TransType_Currect == TransType.E_Cash_CashChargeRevoke) {
//    		return getF55Tag_One();
//		} else if (TransType.TransType_Currect == TransType.TransCorrect 
//				|| TransType.TransType_Currect == TransType.PreAuthCorrect
//				|| TransType.TransType_Currect == TransType.E_Cash_CashChargeRevokeCorrect) {
//			return getF55Tag_Two();
//		} else if (TransType.TransType_Currect >= TransType.MOBILE_Trans
//				&& TransType.TransType_Currect <= TransType.MOBILE_TransRevoke_Correct) {
//			return getF55Tag_Three();
//		} else if (TransType.TransType_Currect == TransType.E_Cash_QuickTrans
//				|| TransType.TransType_Currect == TransType.E_Cash_OrdinaryTrans) {
//			return getF55Tag_Four();
//		} else {
//			return new String[] { };
//		}
//    }
    
    /**
     * 通知上送报文中F55
     * @return
     * @throws Exception
     */
    public static String[] getF55Tag_Four() throws Exception{
        String[] tags = {                
	        combine(0x9F,0x26),
	        combine(0x9F,0x27),
	        combine(0x9F,0x10),
	        combine(0x9F,0x37),
	        combine(0x9F,0x36),
	        combine(0x95),
	        combine(0x9A),
	        combine(0x9C),
	        combine(0x9F,0x02),
	        combine(0x5F,0x2A),
	        combine(0x82),
	        combine(0x9F,0x1A),
	        combine(0x9F,0x03),
	        combine(0x9F,0x33),
	        combine(0x9F,0x34),
	        combine(0x9F,0x35),
	        combine(0x9F,0x1E),
	        combine(0x84),
	        combine(0x9F,0x09),
	        combine(0x9F,0x41),
	        combine(0x9F,0x63),
	        combine(0x9F,0x74),
	        combine(0x8A)
	    };
        return tags;       
    }
    
    /**
     * 通知上送报文中F55
     * @return
     * @throws Exception
     */
    public static String[] getF55Tag_One() throws Exception{
        String[] tags = {                
	        combine(0x9F,0x26),
	        combine(0x9F,0x27),
	        combine(0x9F,0x10),
	        combine(0x9F,0x37),
	        combine(0x9F,0x36),
	        combine(0x95),
	        combine(0x9A),
	        combine(0x9C),
	        combine(0x9F,0x02),
	        combine(0x5F,0x2A),
	        combine(0x82),
	        combine(0x9F,0x1A),
	        combine(0x9F,0x03),
	        combine(0x9F,0x33),
	        combine(0x9F,0x34),
	        combine(0x9F,0x35),
	        combine(0x9F,0x1E),
	        combine(0x84),
	        combine(0x9F,0x09),
	        combine(0x9F,0x41),
	        combine(0x9F,0x63)
	    };
        return tags;       
    }
    
    /**
     * 通知上送报文F55
     * @return
     * @throws Exception
     */
    public static String[] getF55Tag_Two() throws Exception{
        String[] tags={    
	        combine(0x95),
	        combine(0x9F,0x1E),
	        combine(0x9F,0x10),
	        combine(0x9F,0x36),
	        combine(0xDF,0x31)
	    };
        return tags;       
    }
    
    /**
     * 通知上送报文F55
     * @return
     * @throws Exception
     */
    public static String[] getF55Tag_Three() throws Exception{
    	String[] tags={
	        combine(0xDF,0x32),
	        combine(0xDF,0x33),
	        combine(0xDF,0x34)
	    };
        return tags;       
    }
}