package com.example.util;

import java.io.UnsupportedEncodingException;
import java.util.Locale;

import android.annotation.SuppressLint;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class CHexConver {

	private final static char[] mChars = "0123456789ABCDEF".toCharArray();
	private final static String mHexStr = "0123456789ABCDEF";

	/**
     * 检测是否为空
     * 
     * @param st
     * @return
     */
    public static boolean isEmpty(String st) {
        return st == null || st.length() == 0;
    }
    
    public static boolean isEmpty(byte[] by) {
        return by == null || by.length == 0;
    }
    
	/**
     * 字符转ASC
     * @param st
     * @return
     */
    public static int getAsc(String st) {
        byte[] gc = st.getBytes();
        int ascNum = (int) gc[0];
        return ascNum;
    }

    /**
     * ASC转字符
     * @param backnum
     * @return
     */
    public static char backchar(int backnum) {
    	char strChar = (char) backnum;
        return strChar;
    }
    
    /**
     * String转ascii
     * @param st
     * @return
     */
    public static String parseAscii(String str){
        StringBuilder sb=new StringBuilder();
        byte[] bs=str.getBytes();
        for(int i=0;i<bs.length;i++)
            sb.append(toHex(bs[i]));
        return sb.toString();
    }
    
    private static String toHex(int n){
        StringBuilder sb=new StringBuilder();
        if(n/16==0){
            return toHexUtil(n);
        }else{
            String t=toHex(n/16);
            int nn=n%16;
            sb.append(t).append(toHexUtil(nn));
        }
        return sb.toString();
    }
    
    private static String toHexUtil(int n){
        String rt="";
        switch(n){
        case 10:rt+="A";break;
        case 11:rt+="B";break;
        case 12:rt+="C";break;
        case 13:rt+="D";break;
        case 14:rt+="E";break;
        case 15:rt+="F";break;
        default:
            rt+=n;
        }
        return rt;
    }
    
	/**
	 * 检查16进制字符串是否有效
	 * @param String sHex 16进制字符串
	 * @return boolean
	 */
	@SuppressLint("DefaultLocale")
	public static boolean checkHexStr(String sHex) {
		String sTmp = sHex.toString().trim().replace(" ", "").toUpperCase(Locale.US);
		int sLen = sTmp.length();
		if (sLen > 1 && sLen % 2 == 0) {
			for (int i = 0; i < sLen; i++)
				if (!mHexStr.contains(sTmp.substring(i, i + 1)))
					return false;
			return true;
		} else
			return false;
	}

	/**
	 * 字符串转换成十六进制字符串
	 * @param String str 待转换的ASCII字符串
	 * @return String 每个Byte之间空格分隔，如: [61 6C 6B]
	 */
	public static String str2HexStr(String str) {
		StringBuilder sb = new StringBuilder("");
		byte[] bs = str.getBytes();
		int bit;
		for (int i = 0; i < bs.length; i++) {
			bit = (bs[i] & 0x0f0) >> 4;
			sb.append(mChars[bit]);
			bit = bs[i] & 0x0f;
			sb.append(mChars[bit]);
		}
		return sb.toString().trim();
	}

	/**
	 * 十六进制字符串转换成 ASCII字符串
	 * @param String str Byte字符串
	 * @return String 对应的字符串
	 */
	public static String hexStr2Str(String hexStr) {
		hexStr = hexStr.toString().trim().replace(" ", "").toUpperCase(Locale.US);
		char[] hexs = hexStr.toCharArray();
		byte[] bytes = new byte[hexStr.length() / 2];
		int n;
		for (int i = 0; i < bytes.length; i++) {
			n = mHexStr.indexOf(hexs[2 * i]) * 16;
			n += mHexStr.indexOf(hexs[2 * i + 1]);
			bytes[i] = (byte) (n & 0xff);
		}
		return new String(bytes);
	}

	/**
	 * bytes转换成十六进制字符串
	 * @param byte[] b byte数组
	 * @param int iLen 取前N位处理 N=iLen
	 * @return String 每个Byte值之间空格分隔
	 * @throws Exception
	 */
	public static String byte2HexStr(byte[] b) throws Exception {
		String ret = new String(b, "GBK");
		return ret;
	}

	/**
	 * 获取数字字符串
	 * @param byte[] b byte数组
	 * @return String
	 * @throws Exception
	 */
	public static String getNumber(byte[] b) throws Exception {
		String number = "";
		for (int i = 0; i < b.length; i++) {
			if(b[i]==11){
				number+=".";
			}else{
				number += b[i];
			}
		}
		return number;
	}
	
	/**
	 * @param str 需要补齐的字符串
	 * @param length 补齐后的字符串长度
	 * @param addValue 需要补上的内容
	 * @param way 补齐方式，左对齐 left 右对齐 right  默认右补齐
	 * @return
	 */
	public static String endAddSpaceOrZore(String str, int length, String addValue, String way){
		if(str.length() == length){
			return str;
		}
		while(str.length() < length){
			if("right".equals(way)){
				str += addValue;
			}else if("left".equals(way)){
				str = addValue + str;
			}else {
				str += addValue;
			}
		}
		return str;
	}

	private static byte asc_to_bcd(byte asc) {
		byte bcd;
		if ((asc >= '0') && (asc <= '9'))
			bcd = (byte) (asc - '0');
		else if ((asc >= 'A') && (asc <= 'F'))
			bcd = (byte) (asc - 'A' + 10);
		else if ((asc >= 'a') && (asc <= 'f'))
			bcd = (byte) (asc - 'a' + 10);
		else
			bcd = (byte) (asc - 48);
		return bcd;
	}

	/**
	 * bytes转换成十六进制字符串 ,2个byte转一个字符，类似BCD
	 * @param String str Byte字符串
	 * @return String 对应的字符串
	 */
	public static String Bytes2ToHexStr(byte[] b) throws Exception {
		byte[] bytes = new byte[b.length / 2];
		int n;
		for (int i = 0; i < bytes.length; i++) {
			n = asc_to_bcd(b[2 * i]) * 16;
			n += asc_to_bcd(b[2 * i + 1]);
			bytes[i] = (byte) (n & 0xff);
		}
		return byte2HexStr(bytes);
	}

	/**
	 * bytes字符串转换为Byte值
	 * @param String src Byte字符串，每个Byte之间没有分隔符(字符范围:0-9 A-F)
	 * @return byte[]
	 */
	public static byte[] hexStr2Bytes(String src) {
		/* 对输入值进行规范化整理 */
		src = src.trim().replace(" ", "").toUpperCase(Locale.US);
		// 处理值初始化
		int m = 0, n = 0;
		int l = src.length() / 2; // 计算长度
		byte[] ret = new byte[l]; // 分配存储空间
		for (int i = 0; i < l; i++) {
			m = i * 2 + 1;
			n = m + 1;
			ret[i] = (byte) (Integer.decode("0x" + src.substring(i * 2, m) + src.substring(m, n)) & 0xFF);
		}
		return ret;
	}

	/**
	 * String的字符串转换成unicode的String
	 * @param String strText 全角字符串
	 * @return String 每个unicode之间无分隔符
	 * @throws Exception
	 */
	public static String strToUnicode(String strText) throws Exception {
		char c;
		StringBuilder str = new StringBuilder();
		int intAsc;
		String strHex;
		for (int i = 0; i < strText.length(); i++) {
			c = strText.charAt(i);
			intAsc = c;
			strHex = Integer.toHexString(intAsc);
			if (intAsc > 128)
				str.append("\\u" + strHex);
			else
				// 低位在前面补00
				str.append("\\u00" + strHex);
		}
		return str.toString();
	}

	/**
	 * unicode的String转换成String的字符串
	 * @param String hex 16进制值字符串 （一个unicode为2byte）
	 * @return String 全角字符串
	 */
	public static String unicodeToString(String hex) {
		int t = hex.length() / 6;
		StringBuilder str = new StringBuilder();
		for (int i = 0; i < t; i++) {
			String s = hex.substring(i * 6, (i + 1) * 6);
			// 高位需要补上00再转
			String s1 = s.substring(2, 4) + "00";
			// 低位直接转
			String s2 = s.substring(4);
			// 将16进制的string转为int
			int n = Integer.valueOf(s1, 16) + Integer.valueOf(s2, 16);
			// 将int转换为字符
			char[] chars = Character.toChars(n);
			str.append(new String(chars));
		}
		return str.toString();
	}
	
	/**
	 * Byte ascii转成int
	 * @param b byte 值
	 * @return int值
	 */
	public static int byteToInt(byte[] b) {
		int mask = 0xff;
		int temp = 0;
		int n = 0;
		for (int i = 0; i < b.length; i++) {
			byte vByte = asc_to_bcd(b[i]);
			n <<= 8;
			temp = vByte & mask;
			n |= temp;
		}
		return n;
	}
	
	/**
	 * Byte 转成int
	 * @param b byte 值
	 * @return int值
	 */
	public static int byteToInt2(byte[] b) {
		int mask = 0xff;
		int temp = 0;
		int n = 0;
		for (int i = 0; i < b.length; i++) {
			n <<= 8;
			temp = b[i] & mask;
			n |= temp;
		}
		return n;
	}

	public static int byteToInt2(byte[] b, int Offset, int Len) {
		int mask = 0xff;
		int temp = 0;
		int n = 0;
		for (int i = Offset; i < Offset + Len; i++) {
			n <<= 8;
			temp = b[i] & mask;
			n |= temp;
		}
		return n;
	}

	/**
     * 数字字符串转ASCII码字符串
     * @param String 字符串
     * @return ASCII字符串
     */
    public static String byteToAsciiString(byte[] bytearray) {
    	String result = "";
        char temp;
        int length = bytearray.length;
        for (int i = 0; i < length; i++) {
            temp = (char) bytearray[i];
            result += temp;
        }
        return result;
    }

	/**
	 * byte流打印String
	 * @param bArray byte
	 * @return
	 */
	@SuppressLint("DefaultLocale")
	public static final String bytesToHexString(byte[] bArray) {
		if(bArray == null){
			return "";
		}
		StringBuffer sb = new StringBuffer(bArray.length);
		String sTemp;
		for (int i = 0; i < bArray.length; i++) {
			sTemp = Integer.toHexString(0xFF & bArray[i]);
			if (sTemp.length() < 2)
				sb.append(0);
			sb.append(sTemp.toUpperCase());
		}
		return sb.toString();
	}

	/**
	 * byte流打印String
	 * @param bArray byte
	 * @return
	 */
	@SuppressLint("DefaultLocale")
	public static final String bytesToHexStringSpace(byte[] bArray) {
		if(bArray == null){
			return "";
		}
		StringBuffer sb = new StringBuffer(bArray.length);
		String sTemp;
		for (int i = 0; i < bArray.length; i++) {
			sTemp = Integer.toHexString(0xFF & bArray[i]);
			if (sTemp.length() < 2)
				sb.append(0);
			sb.append(sTemp.toUpperCase());
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * byte流打印String
	 * @param bArray byte
	 * @return
	 */
	@SuppressLint("DefaultLocale")
	public static final String bytesTo2String(byte[] bArray) {
		StringBuffer sb = new StringBuffer(bArray.length);
		String sTemp;
		for (int i = 0; i < bArray.length; i++) {
			sTemp = Integer.toBinaryString(0x000001 & bArray[i]);
			if (sTemp.length() < 7)
				sb.append(0);
			sb.append(sTemp.toUpperCase());
		}
		return sb.toString();
	}

	public static final String ByteArrayToBinaryString(byte[] byteArray) {
		int capacity = byteArray.length * 8;
		StringBuilder sb = new StringBuilder(capacity);
		Log.i("INFO", "签名数据长度" + byteArray.length);
		for (int i = 0; i < byteArray.length; i++) {
			int a = Integer.toBinaryString(byteArray[i]).length();
			Log.i("INFO", "第" + i + "个域长度---" + i + "个域数据---" + Integer.toBinaryString(byteArray[i]));
			for (int ii = 0; ii <= 8 - a; ii++) {
				sb.append(0);
			}
			sb.append(Integer.toBinaryString(byteArray[i]));
		}
		return sb.toString();
	}

	/**
	 * 字符转byte[]
	 * @param str 值
	 * @param charEncode “GBK”
	 * @return
	 */
	public static byte[] StringToByte(String str, String charEncode) {
		byte[] destObj = null;
		try {
			if (null == str || str.equals("")) {
				destObj = new byte[0];
				return destObj;
			} else {
				destObj = str.getBytes(charEncode);
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return destObj;
	}

	/**
	 * 字符转byte[]
	 * @param str 值
	 * @param charEncode “GBK”
	 * @return
	 */
	public static byte[] StringToByteAmount(String str, String charEncode) {
		byte[] destObj = null;
		try {
			if (null == str || str.trim().equals("")) {
				destObj = new byte[0];
				return destObj;
			} else {
				str = str.replace(".", "");
				destObj = str.getBytes(charEncode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return destObj;
	}
}